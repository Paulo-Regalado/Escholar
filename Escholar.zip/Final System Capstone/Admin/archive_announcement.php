<?php
session_start();
include_once '../php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['account_number'], $_SESSION['isAdmin'])) {
    header("Location: http://localhost:8081/Escholar/User/login.php");
    exit();
} else {
    // Security: Regenerate session ID
    session_regenerate_id(true);


    // Check if the logged-in user is an admin
    if (!$_SESSION['isAdmin']) {
        // header("Location: unauthorized.php");
        header("Location: http://localhost:8081/Escholar/User/login.php");
        exit();
    }

    // For example, you can fetch admin-specific data using the account_number
    $accountNumber = $_SESSION['account_number'];

    // Security: Use prepared statement to prevent SQL injection
    $queryAdmin = $conn->prepare("SELECT * FROM admin_account WHERE account_number = ?");
    $queryAdmin->bind_param("s", $accountNumber);
    $queryAdmin->execute();
    $resultAdmin = $queryAdmin->get_result();

    if ($resultAdmin->num_rows == 0) {
        // Admin account not found, handle accordingly
        // header("Location: unauthorized.php");
        header("Location: ../User/login.php");
        exit();
    }

    $resultAdmin->close();

    // Get admin session data
    $adminData = array(
        'account_number' => $_SESSION['account_number'],
        'last_name' => $_SESSION['last_name'],
        'first_name' => $_SESSION['first_name'],
        'middle_name' => $_SESSION['middle_name'],
    );
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archived Announcement</title>
    <link rel="stylesheet" href="../css/style.css" />

    <!-- Add the favicon link here -->
    <link rel="icon" type="image/png" href="../img/Logo2.png">

    <!-- Email Library -->
    <script src="https://smtpjs.com/v3/smtp.js"></script>

    <!-- ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- BOOTSTRAP -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <link href="../css/bootstrap.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- JS -->
    

    <!-- DATATABLES -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

</head>

<body>

    <nav class="navbar bg-body-tertiary fixed-top  ">
        <div class="container-fluid d-flex justify-content-start">

            <div>
                <a class="navbar-brand d-flex align-items-center" href="#">
                    <div class="me-2 h-25 logo">

                        <img src="../img/Logo2.png" class="logo" alt="logo">
                    </div>
                    <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULSU Office of the Student
                        Financial
                        Assistance and Scholarships</h5>
                </a>
            </div>
        </div>
    </nav>

    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="success-restore-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    Successfully Restored.
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>

        <div id="success-restore-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    Successfully Restored Announcement.
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
        <div id="success-delete-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    Successfully Deleted Announcement.
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>

        <div id="failed-delete-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    Failed to delete Announcement.
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>

    </div>



    <div class="sidebar close">
        <ul class="nav-links">
            <li>
                <a href="dashboard.php">
                    <i class="bi bi-house"></i>
                    <span class="link_name">Dashboard</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="dashboard.php">Dashboard</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-book"></i>
                        <span class="link_name">Scholars</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Scholars</a></li>
                    <li><a href="listMasterlist.php">Masterlist</a></li>
                    <li><a href="Listpending.php">Pending</a></li>
                    <li><a href="list_approve.php">Approved</a></li>
                </ul>
            </li>
            <li>
                <a href="benefactor.php">
                    <i class="bi bi-people"></i>
                    <span class="link_name">Benefactors</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="benefactor.php">Benefactors</a></li>
                </ul>
            </li>
            <li>
                <a href="listgraduates.php">
                    <i class="bi bi-award"></i>
                    <span class="link_name">Graduates</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="listgraduates.php">Graduates</a></li>
                </ul>
            </li>
            <li>
                <a href="announcement.php">
                    <i class="bi bi-megaphone"></i>
                    <span class="link_name">Announcement</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="account.php">
                    <i class="bi bi-person"></i>
                    <span class="link_name">Accounts</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="account.php">Accounts</a></li>
                </ul>
            </li>
            <li>
                <a href="activitylogs.php">
                    <i class="bi bi-list-check"></i>
                    <span class="link_name">Activity Logs</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="activitylogs.php">Activity Logs</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-archive"></i>
                        <span class="link_name">Archive</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Archives</a></li>
                    <li><a href="archive_masterlist.php">Masterlist</a></li>
                    <li><a href="archive_benefactor.php">Benefactor</a></li>
                    <li><a href="archive_announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="reports.php">
                    <i class="bi bi-bar-chart"></i>
                    <span class="link_name">Reports</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="reports.php">Charts & Reports</a></li>
                </ul>
            </li>

            <li>
                <div class="profile-details">
                    <div class="profile-content">
                    </div>
                    <div class="name-job">
                        <div class="profile_name">
                            <?php echo $adminData['first_name']; ?>
                        </div>
                        <div class="job">Admin</div>
                    </div>
                    <a href="#" role="button" class=" p-0 text-decoration-none text-black" data-bs-toggle="dropdown" aria-expanded="false"><i style="font-size: 14px;" class="bi bi-chevron-up"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="setting.php">Setting</a></li>
                        <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>



    <section class="home-section">
        <div class="banner d-flex justify-content-start align-items-center ps-1">

            <i class="btn btn-outline-light bi bi-arrow-right sidebar-menu" id="icon"></i>
        </div>




        <nav class="ms-2 mt-2">
            <ol class="breadcrumb fs-6">
                <li class="breadcrumb-item"><a href="" class="text-decoration-none text-secondary"><i class="bi bi-archive me-1"></i>Archives</a></li>
                <li class="breadcrumb-item"><a href="" class="text-decoration-none text-secondary">Announcement</a></li>
            </ol>
        </nav>

        <div class="ms-2 mb-5">
            <h2><span class="border-5 border-start border-success me-2"></span>
                Archived Announcement
            </h2>
        </div>

        <div class="container-fluid">
            <div class="dito-toast">

                <div class="toast-container position-fixed bottom-0 end-0 p-3">

                    <div id="success-approve-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="d-flex">
                            <div class="toast-body">
                                Successfully Approved.
                            </div>
                            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                    </div>
                    <div id="reject-toast" class="toast align-items-center text-bg-danger border-0" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="d-flex">
                            <div class="toast-body">
                                Rejected.
                            </div>
                            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                    </div>

                </div>


            </div>


            <div class="table-responsive">
                <table id="announcement-table" class="table table-hover text-center">
                    <thead class="table-secondary">
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">URL</th>
                            <th scope="col">Date Created</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody id="announcement-table-body">

                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            actLogs('<?php echo $adminData['first_name'] ?>', '<?php echo $adminData['last_name'] ?>');

        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get the icon element
            var icon = document.getElementById('icon');

            // Add a click event listener
            icon.addEventListener('click', function() {
                // Toggle the class to switch the icon
                icon.classList.toggle('bi-arrow-left');
                icon.classList.toggle('bi-arrow-right');
            });
        });
    </script>
    <script type="text/javascript" src="../js/archived_announcement.js"></script>
    <!-- eto ginawa ko kaya nawala ung error sa console at naguupdate na realtime sa import at add-->
    <!-- Include jQuery library first -->
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>

    <!-- Include Bootstrap and DataTables scripts -->
    <script type="text/javascript" src="../js/bootstrap.js"></script>
    <script defer src="../js/datatable.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Other script tags and your custom scripts -->
    <script type="text/javascript" src="../js/sidebar.js"></script>

    <!-- DATA TABLE -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="../js/datatable.js"></script>


</body>

</html>
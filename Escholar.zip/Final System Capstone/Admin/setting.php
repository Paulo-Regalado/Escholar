<?php
session_start();
include_once '../php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['account_number'], $_SESSION['isAdmin'])) {
    header("Location: http://escholar.eyjeyesdiar.com/");
    exit();
} else {
    // Security: Regenerate session ID
    session_regenerate_id(true);

    // Check if the logged-in user is an admin
    if (!$_SESSION['isAdmin']) {
        // header("Location: unauthorized.php");
        header("Location: http://escholar.eyjeyesdiar.com/");
        exit();
    }

    // For example, you can fetch admin-specific data using the account_number
    $accountNumber = $_SESSION['account_number'];

    // Security: Use prepared statement to prevent SQL injection
    $queryAdmin = $conn->prepare("SELECT * FROM admin_account WHERE account_number = ?");
    $queryAdmin->bind_param("s", $accountNumber);
    $queryAdmin->execute();
    $resultAdmin = $queryAdmin->get_result();

    if ($resultAdmin->num_rows == 0) {
        // Admin account not found, handle accordingly
        // header("Location: unauthorized.php");
        header("Location: ../User/login.php");
        exit();
    }

    $resultAdmin->close();

    // Get admin session data
    $adminData = array(
        'account_number' => $_SESSION['account_number'],
        'last_name' => $_SESSION['last_name'],
        'first_name' => $_SESSION['first_name'],
        'middle_name' => $_SESSION['middle_name'],
    );
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="stylesheet" href="../css/style.css" />
    <!-- Add the favicon link here -->
    <link rel="icon" type="image/png" href="../img/Logo2.png">

    <!-- ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- BOOTSTRAP -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/custom.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- HIGHCHARTS -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="https://code.highcharts.com/modules/drilldown.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>
</head>

<body>

    <nav class="navbar bg-body-tertiary fixed-top  ">
        <div class="container-fluid d-flex justify-content-start">

            <div>
                <a class="navbar-brand d-flex align-items-center" href="#">
                    <div class="me-2 h-25 logo">
                        <img src="../img/Logo2.png" class="logo" alt="logo">
                    </div>
                    <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULSU Office of the Student
                        Financial
                        Assistance and Scholarships</h5>
                </a>
            </div>
        </div>
    </nav>


    <div class="sidebar close">
        <ul class="nav-links">
            <li>
                <a href="dashboard.php">
                    <i class="bi bi-house"></i>
                    <span class="link_name">Dashboard</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="dashboard.php">Dashboard</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-book"></i>
                        <span class="link_name">Scholars</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Scholars</a></li>
                    <li><a href="listMasterlist.php">Masterlist</a></li>
                    <li><a href="Listpending.php">Pending</a></li>
                    <li><a href="list_approve.php">Approved</a></li>
                </ul>
            </li>
            <li>
                <a href="benefactor.php">
                    <i class="bi bi-people"></i>
                    <span class="link_name">Benefactors</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="benefactor.php">Benefactors</a></li>
                </ul>
            </li>
            <li>
                <a href="listgraduates.php">
                    <i class="bi bi-award"></i>
                    <span class="link_name">Graduates</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="listgraduates.php">Graduates</a></li>
                </ul>
            </li>
            <li>
                <a href="announcement.php">
                    <i class="bi bi-megaphone"></i>
                    <span class="link_name">Announcement</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="account.php">
                    <i class="bi bi-person"></i>
                    <span class="link_name">Accounts</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="account.php">Accounts</a></li>
                </ul>
            </li>
            <li>
                <a href="activitylogs.php">
                    <i class="bi bi-list-check"></i>
                    <span class="link_name">Activity Logs</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="activitylogs.php">Activity Logs</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-archive"></i>
                        <span class="link_name">Archive</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Archives</a></li>
                    <li><a href="archive_masterlist.php">Masterlist</a></li>
                    <li><a href="archive_benefactor.php">Benefactor</a></li>
                    <li><a href="archive_announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="reports.php">
                    <i class="bi bi-bar-chart"></i>
                    <span class="link_name">Reports</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="reports.php">Charts & Reports</a></li>
                </ul>
            </li>

            <li>
                <div class="profile-details">
                    <div class="profile-content">
                    </div>
                    <div class="name-job">
                        <div class="profile_name">
                            <?php echo $adminData['first_name']; ?>
                        </div>
                        <div class="job">Admin</div>
                    </div>
                    <a href="#" role="button" class=" p-0 text-decoration-none text-black" data-bs-toggle="dropdown" aria-expanded="false"><i style="font-size: 14px;" class="bi bi-chevron-up"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="setting.php">Setting</a></li>
                        <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>

    <section class="home-section ">
        <div class="banner d-flex justify-content-start align-items-center ps-1">

            <i class="btn btn-outline-light bi bi-arrow-right sidebar-menu" id="icon"></i>
        </div>

        <div class="ms-2 mt-4">
            <h2><span class="border-5 border-start border-success me-2"></span>Settings</h2>
        </div>

        <form id="passwordForm" action="../php/toChangeAdminPass.php" method="post" onsubmit="validateForm(event)">

            <div class="px-4">
                <div style="max-width: 500px;" class="text-black">
                    <div class="alert alert-danger col-12" role="alert" id="password-error" style="display: none;">
                        Your error here
                    </div>
                    <input type="hidden" name="account_number" id="password_form_account_number" value="<?php echo $accountNumber; ?>" readonly>
                    <div class="mb-2">
                        <label for="current-password" class="form-label">Current Password</label>
                        <input type="password" class="form-control" id="current-password" name="current-pass" required>
                    </div>
                    <div class="mb-2">
                        <label for="new-pass" class="form-label">New Password</label>
                        <input type="password" class="form-control" id="new-pass" name="new-pass" required>
                    </div>
                    <div class="mb-2">
                        <label for="re-pass" class="form-label">Re-type Password</label>
                        <input type="password" class="form-control" id="re-pass" required>
                    </div>
                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-start mt-3">
                    <button type="button" class="btn btn-secondary" onclick="redirectToDashboard()">Cancel</button>
                    <button type="submit" class="btn btn-save">Change Password</button>
                </div>
            </div>
        </form>





    </section>
    <script type="text/javascript" src="../js/sidebar.js"></script>
    <script type="text/javascript" src="../js/bootstrap.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get the icon element
            var icon = document.getElementById('icon');

            // Add a click event listener
            icon.addEventListener('click', function() {
                // Toggle the class to switch the icon
                icon.classList.toggle('bi-arrow-left');
                icon.classList.toggle('bi-arrow-right');
            });
        });

        function redirectToDashboard() {
            window.location.href = 'dashboard.php';
        }


        function validatePasswordComplexity(password) {
            // Check if password contains at least one capital letter and one symbol
            return /[A-Z]/.test(password) && /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(password);
        }

        function validatePass() {
            const validationError = document.getElementById("password-error");
            const pass = document.getElementById("new-pass");

            if (pass.value.length < 8) {
                validationError.textContent = 'Password must be a minimum of 8 characters and include at least one capital letter and one symbol.';
                validationError.style.display = 'block';
                return false; // Prevent form submission
            } else {
                return true;
            }
        }

        function validateSamePass() {
            const validationError = document.getElementById("password-error");
            const pass = document.getElementById("new-pass");
            const rePass = document.getElementById("re-pass");

            if (pass.value === rePass.value) {
                return true; // Prevent form submission
            } else {
                validationError.textContent = 'Passwords do not match.';
                validationError.style.display = 'block';
                return false; // Prevent form submission
            }
        }

        async function checkCurrentPassword(accountType) {
            const validationError = document.getElementById("password-error");
            const currentPass = document.getElementById("current-password").value;
            const accountNumber = document.getElementById("password_form_account_number").value;

            var formData = new FormData();
            formData.append('student-number', accountNumber);
            formData.append('type', accountType);
            formData.append('current-password', currentPass);


            try {
                const response = await fetch('../User/php/toValidateCurrentPassword.php', {
                    method: 'POST',
                    body: formData
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok. Status: ' + response.status);
                }

                const data = await response.json();

                if (data && data.hasOwnProperty('valid')) {
                    if (data.valid) {
                        // Password is valid, allow form submission
                        return true;
                    } else {
                        validationError.textContent = 'The Current password is incorrect.';
                        validationError.style.display = 'block';
                        // Password is invalid, prevent form submission
                        return false;
                    }
                } else {
                    console.error('Unexpected response format:', data);
                    // Unexpected response format, prevent form submission
                    return false;
                }
            } catch (error) {
                console.error('Error validating current password:', error.message);
                // Error in validation, prevent form submission
                return false;
            }
        }

        async function validateForm(event) {
            // Prevent the default form submission behavior
            event.preventDefault();

            const validationError = document.getElementById("password-error");
            const isSamePass = validateSamePass();
            const isPassValid = validatePass();
            const isCurrentPassValid = await checkCurrentPassword('admin');

            if (isSamePass && isPassValid && isCurrentPassValid) {
                // All validations passed, allow form submission
                document.getElementById("passwordForm").submit();
            }
        }
    </script>
</body>

</html>
<?php
session_start();
include_once '../php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['account_number'], $_SESSION['isAdmin'])) {
  header("Location: http://escholar.eyjeyesdiar.com/");
  exit();
} else {
  // Security: Regenerate session ID
  session_regenerate_id(true);

  // Check if the logged-in user is an admin
  if (!$_SESSION['isAdmin']) {
    // header("Location: unauthorized.php");
    header("Location: http://escholar.eyjeyesdiar.com/");
    exit();
  }

  // For example, you can fetch admin-specific data using the account_number
  $accountNumber = $_SESSION['account_number'];

  // Security: Use prepared statement to prevent SQL injection
  $queryAdmin = $conn->prepare("SELECT * FROM admin_account WHERE account_number = ?");
  $queryAdmin->bind_param("s", $accountNumber);
  $queryAdmin->execute();
  $resultAdmin = $queryAdmin->get_result();

  if ($resultAdmin->num_rows == 0) {
    // Admin account not found, handle accordingly
    // header("Location: unauthorized.php");
    header("Location: ../User/login.php");
    exit();
  }

  $resultAdmin->close();

  // Get admin session data
  $adminData = array(
    'account_number' => $_SESSION['account_number'],
    'last_name' => $_SESSION['last_name'],
    'first_name' => $_SESSION['first_name'],
    'middle_name' => $_SESSION['middle_name'],
  );
}

if (isset($_GET['id'])) {
  $id = $_GET['id'];
} else {
  header("Location: Listpending.php");
  exit();
}

$query = "SELECT * FROM benefactor WHERE id=?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id); // "i" indicates an integer, adjust as needed
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $particular = $row["particular"];
    $semester = $row["semester"];
    $benefactor_name = $row["name"];
    $slot = $row["slot"];
    $amount = $row["amount"];
    $table_name = $row["table_name"];
  }
}

// $stmt->close(); // Close the prepared statement

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pending Scholars</title>
  <link rel="stylesheet" href="../css/style.css" />
  <link rel="stylesheet" href="../css/admin_pending.css" />
  <link rel="stylesheet" href="../css/custom.css" />

  <!-- Add the favicon link here -->
  <link rel="icon" type="image/png" href="../img/Logo2.png">

  <!-- Email Library -->
  <script src="https://smtpjs.com/v3/smtp.js"></script>

  <!-- ICON -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <!-- BOOTSTRAP -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
  <link href="../css/bootstrap.css" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

  <!-- DATATABLES -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

  <style>
    /* Center align DataTables header and content */
    #pending-table.dataTable thead th,
    #pending-table.dataTable tbody td {
      text-align: center;
    }

    /* Ensure proper alignment for DataTables wrapper */
    #pending-table_wrapper {
      text-align: center;
    }

    /* Left-align length data and info data in DataTables */
    #pending-table_info,
    #pending-table_length {
      text-align: left;
    }
  </style>

</head>

<body>

  <!-- Reject modal -->
  <div class="modal fade" id="rejectReasonModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">State the reason</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="form-floating">
            <textarea class="form-control" placeholder=" " id="reason-input" style="height: 100px"></textarea>
            <label for="reason-input">Enter a reason</label>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-del" onclick='getReason()'>Reject</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Reject modal -->

  <!-- Modal Alert for Confirmation -->
  <div class="modal fade" id="confirmationModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Confirmation</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center">
          <p>Are you sure you want to approve this scholar?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-save" id="approveButton" onclick='toApprove()'>OK</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal Alert for Confirmation -->

  <nav class="navbar bg-body-tertiary fixed-top  ">
    <div class="container-fluid d-flex justify-content-start">

      <div>
        <a class="navbar-brand d-flex align-items-center" href="#">
          <div class="me-2 h-25 logo">

            <img src="../img/Logo2.png" class="logo" alt="logo">
          </div>
          <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULSU Office of the Student
            Financial
            Assistance and Scholarships</h5>
        </a>
      </div>
    </div>
  </nav>



  <div class="sidebar close">
    <ul class="nav-links">
      <li>
        <a href="dashboard.php">
          <i class="bi bi-house"></i>
          <span class="link_name">Dashboard</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="dashboard.php">Dashboard</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="">
            <i class="bi bi-book"></i>
            <span class="link_name">Scholars</span>
          </a>

          <i class="bi bi-caret-down arrow"></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href="">Scholars</a></li>
          <li><a href="listMasterlist.php">Masterlist</a></li>
          <li><a href="Listpending.php">Pending</a></li>
          <li><a href="list_approve.php">Approved</a></li>
        </ul>
      </li>
      <li>
        <a href="benefactor.php">
          <i class="bi bi-people"></i>
          <span class="link_name">Benefactors</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="benefactor.php">Benefactors</a></li>
        </ul>
      </li>
      <li>
        <a href="listgraduates.php">
          <i class="bi bi-award"></i>
          <span class="link_name">Graduates</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="listgraduates.php">Graduates</a></li>
        </ul>
      </li>
      <li>
        <a href="announcement.php">
          <i class="bi bi-megaphone"></i>
          <span class="link_name">Announcement</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="announcement.php">Announcement</a></li>
        </ul>
      </li>
      <li>
        <a href="account.php">
          <i class="bi bi-person"></i>
          <span class="link_name">Accounts</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="account.php">Accounts</a></li>
        </ul>
      </li>
      <li>
        <a href="activitylogs.php">
          <i class="bi bi-list-check"></i>
          <span class="link_name">Activity Logs</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="activitylogs.php">Activity Logs</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="">
            <i class="bi bi-archive"></i>
            <span class="link_name">Archive</span>
          </a>

          <i class="bi bi-caret-down arrow"></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href="">Archives</a></li>
          <li><a href="archive_masterlist.php">Masterlist</a></li>
          <li><a href="archive_benefactor.php">Benefactor</a></li>
          <li><a href="archive_announcement.php">Announcement</a></li>
        </ul>
      </li>
      <li>
        <a href="reports.php">
          <i class="bi bi-bar-chart"></i>
          <span class="link_name">Reports</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="reports.php">Charts & Reports</a></li>
        </ul>
      </li>

      <li>
        <div class="profile-details">
          <div class="profile-content">
          </div>
          <div class="name-job">
            <div class="profile_name">
              <?php echo $adminData['first_name']; ?>
            </div>
            <div class="job">Admin</div>
          </div>
          <a href="#" role="button" class=" p-0 text-decoration-none text-black" data-bs-toggle="dropdown" aria-expanded="false"><i style="font-size: 14px;" class="bi bi-chevron-up"></i></a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="setting.php">Setting</a></li>
            <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
          </ul>
        </div>
      </li>
    </ul>
  </div>



  <section class="home-section">
    <div class="banner d-flex justify-content-start align-items-center ps-1">

      <i class="btn btn-outline-light bi bi-arrow-right sidebar-menu" id="icon"></i>
    </div>





    <nav class="ms-2 mt-2">
      <ol class="breadcrumb fs-6">
        <li class="breadcrumb-item"><a href="" class="text-decoration-none text-secondary">Scholars</a></li>
        <li class="breadcrumb-item"><a href="Listpending.php" class="text-decoration-none text-secondary">Pending
            Scholars</a></li>
        </li>
        <li class="breadcrumb-item active" aria-current="page">
          <?php echo $benefactor_name; ?>
        </li>
      </ol>
    </nav>

    <div class="ms-2">
      <h2><span class="border-5 border-start border-success me-2"></span>
        <?php echo $benefactor_name; ?>
      </h2>
    </div>

    <div class="container-fluid">
      <div class="d-flex justify-content-end mb-2">
        <button class="btn btn-tool btn-sm me-1 rounded" type="button" onclick="fetchPendingScholars('<?php echo $table_name; ?>')">
          <i class="bi bi-arrow-clockwise me-1"></i>Refresh
        </button>
      </div>
      <div class="dito-toast">

        <div class="toast-container position-fixed bottom-0 end-0 p-3">

          <div id="success-approve-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Successfully Approved.
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
          </div>
          <div id="reject-toast" class="toast align-items-center text-bg-danger border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Rejected.
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
          </div>

        </div>


      </div>


      <div>
        <div class="table-responsive mt-2 ">
          <table id="pending-table" class="table table-hover" style="width:100%">
            <thead class="table-secondary">
              <tr>
                <th scope="col" nowrap>Student No.</th>
                <th scope="col">Surname</th>
                <th scope="col">Firstname</th>
                <th scope="col">Middlename</th>
                <th scope="col">Email</th>
                <th scope="col">Contact</th>
                <th scope="col">Campus</th>
                <th scope="col">College</th>
                <th scope="col">Course</th>
                <th scope="col">Year</th>
                <th scope="col">GWA</th>
                <th scope="col">Units</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody id="pending-table-body">

            </tbody>
          </table>
        </div>
        <div id="modal-container">

        </div>

      </div>
  </section>

  <script type="text/javascript">
    document.addEventListener("DOMContentLoaded", () => {
      fetchPendingScholars("<?php echo $table_name; ?>");
      actLogs('<?php echo $adminData['first_name'] ?>', '<?php echo $adminData['last_name'] ?>');

    });
  </script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Get the icon element
      var icon = document.getElementById('icon');

      // Add a click event listener
      icon.addEventListener('click', function() {
        // Toggle the class to switch the icon
        icon.classList.toggle('bi-arrow-left');
        icon.classList.toggle('bi-arrow-right');
      });
    });
  </script>
  <!-- eto ginawa ko kaya nawala ung error sa console at naguupdate na realtime sa import at add-->
  <!-- Include jQuery library first -->
  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>

  <!-- Include Bootstrap and DataTables scripts -->
  <script type="text/javascript" src="../js/bootstrap.js"></script>
  <script defer src="../js/datatable.js"></script>

  <!-- Other script tags and your custom scripts -->
  <script type="text/javascript" src="../js/sidebar.js"></script>
  <script type="text/javascript" src="../js/admin_pending.js"></script>

  <!-- DATA TABLE -->
  <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
  <script src="../js/datatable.js"></script>


</body>

</html>
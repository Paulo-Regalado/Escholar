<?php
session_start();
include_once '../php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['account_number'], $_SESSION['isAdmin'])) {
    header("Location: http://escholar.eyjeyesdiar.com/");
    exit();
} else {
    // Security: Regenerate session ID
    session_regenerate_id(true);

    // Check if the logged-in user is an admin
    if (!$_SESSION['isAdmin']) {
        // header("Location: unauthorized.php");
        header("Location: http://escholar.eyjeyesdiar.com/");
        exit();
    }


    // For example, you can fetch admin-specific data using the account_number
    $accountNumber = $_SESSION['account_number'];

    // Security: Use prepared statement to prevent SQL injection
    $queryAdmin = $conn->prepare("SELECT * FROM admin_account WHERE account_number = ?");
    $queryAdmin->bind_param("s", $accountNumber);
    $queryAdmin->execute();
    $resultAdmin = $queryAdmin->get_result();

    if ($resultAdmin->num_rows == 0) {
        // Admin account not found, handle accordingly
        // header("Location: unauthorized.php");
        header("Location: ../User/login.php");
        exit();
    }

    $resultAdmin->close();

    // Get admin session data
    $adminData = array(
        'account_number' => $_SESSION['account_number'],
        'last_name' => $_SESSION['last_name'],
        'first_name' => $_SESSION['first_name'],
        'middle_name' => $_SESSION['middle_name'],
    );
}

if (isset($_GET['id'])) {
    $year_graduated = $_GET['id'];
} else {
    header("Location: listgraduates.php");
    exit();
}

$query = "SELECT * FROM graduate_information WHERE year_graduated=?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $year_graduated); // "i" indicates an integer, adjust as needed
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $grad_pic = $row["grad_pic"];
        $student_number = $row["student_number"];
        $full_name = $row['complete_name'];
        $birthday = $row['birthday'];
        $gender = $row['gender'];
        $civil_status = $row['civil_status'];
        $current_address = $row['current_address'];
        $contact = $row['contact'];
        $email = $row['email'];
        $course = $row['course'];
        $year_graduated = $row['year_graduated'];
        $benefactor = $row['benefactor'];
        $campus = $row['campus'];
        $employment = $row['employment'];
        $org_type = $row['org_type'];
        $company_name = $row['company_name'];
        $comp_address = $row['company_address'];
        $position = $row['position'];
        $year_in_company = $row['year_in_company'];
        $reasons = $row['reasons'];
    }
}

// $stmt->close(); // Close the prepared statement

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Graduates</title>
    <link rel="stylesheet" href="../css/style.css" />

    <!-- Add the favicon link here -->
    <link rel="icon" type="image/png" href="../img/Logo2.png">

    <!-- ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- BOOTSTRAP -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <link href="../css/bootstrap.css" rel="stylesheet">

    <!-- DATATABLES -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="YearPicker/jquery.min.js"></script>
</head>

<body>

    <nav class="navbar bg-body-tertiary fixed-top  ">
        <div class="container-fluid d-flex justify-content-start">

            <div>
                <a class="navbar-brand d-flex align-items-center" href="#">
                    <div class="me-2 h-25 logo">
                        <img src="../img/Logo2.png" class="logo" alt="logo">
                    </div>
                    <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULSU Office of the Student
                        Financial
                        Assistance and Scholarships</h5>
                </a>
            </div>
        </div>
    </nav>


    <div class="sidebar close">
        <ul class="nav-links">
            <li>
                <a href="dashboard.php">
                    <i class="bi bi-house"></i>
                    <span class="link_name">Dashboard</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="dashboard.php">Dashboard</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-book"></i>
                        <span class="link_name">Scholars</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Scholars</a></li>
                    <li><a href="listMasterlist.php">Masterlist</a></li>
                    <li><a href="Listpending.php">Pending</a></li>
                    <li><a href="list_approve.php">Approved</a></li>
                </ul>
            </li>
            <li>
                <a href="benefactor.php">
                    <i class="bi bi-people"></i>
                    <span class="link_name">Benefactors</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="benefactor.php">Benefactors</a></li>
                </ul>
            </li>
            <li>
                <a href="listgraduates.php">
                    <i class="bi bi-award"></i>
                    <span class="link_name">Graduates</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="listgraduates.php">Graduates</a></li>
                </ul>
            </li>
            <li>
                <a href="announcement.php">
                    <i class="bi bi-megaphone"></i>
                    <span class="link_name">Announcement</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="account.php">
                    <i class="bi bi-person"></i>
                    <span class="link_name">Accounts</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="account.php">Accounts</a></li>
                </ul>
            </li>
            <li>
                <a href="activitylogs.php">
                    <i class="bi bi-list-check"></i>
                    <span class="link_name">Activity Logs</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="activitylogs.php">Activity Logs</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-archive"></i>
                        <span class="link_name">Archive</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Archives</a></li>
                    <li><a href="archive_masterlist.php">Masterlist</a></li>
                    <li><a href="archive_benefactor.php">Benefactor</a></li>
                    <li><a href="archive_announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="reports.php">
                    <i class="bi bi-bar-chart"></i>
                    <span class="link_name">Reports</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="reports.php">Charts & Reports</a></li>
                </ul>
            </li>

            <li>
                <div class="profile-details">
                    <div class="profile-content">
                    </div>
                    <div class="name-job">
                        <div class="profile_name">
                            <?php echo $adminData['first_name']; ?>
                        </div>
                        <div class="job">Admin</div>
                    </div>
                    <a href="#" role="button" class=" p-0 text-decoration-none text-black" data-bs-toggle="dropdown" aria-expanded="false"><i style="font-size: 14px;" class="bi bi-chevron-up"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="setting.php">Setting</a></li>
                        <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>

    <section class="home-section">
        <div class="banner d-flex justify-content-start align-items-center ps-1">

            <i class="btn btn-outline-light bi bi-arrow-right sidebar-menu" id="icon"></i>
        </div>
        <nav class="ms-2 mt-2 ">
            <ol class="breadcrumb fs-6">
                <li class="breadcrumb-item"><a href="listgraduates.php" class="text-decoration-none text-secondary">List
                        of Graduates</a></li>
                <li class="breadcrumb-item"><a href="" class="text-decoration-none text-secondary">Batch
                        <?php echo $year_graduated ?>
                    </a>

                </li>
            </ol>
        </nav>

        <?php
        if ($result->num_rows > 0) {
            // Display batch information (assuming it's unique for the batch)
        ?>
            <div class="ms-2 mb-5">
                <h2><span class="border-5 border-start border-success me-2"></span>
                    Batch
                    <?php echo $year_graduated; ?>
                </h2>
            </div>

            <div class="container">
                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 ms-2">
                    <!-- Added Bootstrap classes for column layout -->
                    <?php
                    // Reset the result pointer back to the beginning
                    $result->data_seek(0);

                    // Display individual cards for each graduate
                    while ($row = $result->fetch_assoc()) {
                        $grad_pic = $row["grad_pic"];
                        $student_number = $row["student_number"];
                        $student_number = $row['student_number'];
                        $full_name = $row['complete_name'];
                        $birthday = $row['birthday'];
                        $gender = $row['gender'];
                        $civil_status = $row['civil_status'];
                        $current_address = $row['current_address'];
                        $contact = $row['contact'];
                        $email = $row['email'];
                        $course = $row['course'];
                        $year_graduated = $row['year_graduated'];
                        $benefactor = $row['benefactor'];
                        $campus = $row['campus'];
                        $employment = $row['employment'];
                        $org_type = $row['org_type'];
                        $company_name = $row['company_name'];
                        $comp_address = $row['company_address'];
                        $position = $row['position'];
                        $year_in_company = $row['year_in_company'];
                        $reasons = $row['reasons'];

                    ?>
                        <div class="col mb-3">
                            <a href="#" data-bs-toggle="modal" data-bs-target="#graduateModal<?php echo $student_number; ?>" class="text-decoration-none text-dark">
                                <div class="card mb-3">
                                    <div class="d-flex flex-column align-items-center">
                                        <img src="../User/Graduate_Pic/<?php echo $grad_pic; ?>" class="card-img-top img-fluid rounded-circle mt-3" alt="Graduate Image" style="width: 200px; height: 200px; object-fit: cover;">
                                        <div class="card-body text-center">
                                            <h5 class="card-title">
                                                <!-- Make the graduate's name clickable -->

                                                <b>
                                                    <?php echo $full_name; ?>
                                                </b>

                                            </h5>
                                            <p class="mb-0">
                                                <?php echo $benefactor; ?> Batch
                                                <?php echo $year_graduated; ?>
                                            </p>
                                            <p>
                                                <?php echo $course; ?>
                                            </p>
                                            <div class="card-group">
                                                <p class="card-text mb-1"><b>Student Number:</b>
                                                    <?php echo $student_number; ?>
                                                </p>
                                                <p class="card-text mb-1"><b>Company:</b>
                                                    <?php echo $company_name; ?>
                                                </p>
                                                <p class="card-text mb-1"><b>Position:</b>
                                                    <?php echo $position; ?>
                                                </p>
                                                <p class="card-text mb-1"><b>Status:</b>
                                                    <?php echo $employment; ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>

                        </div>

                        <!-- Add a modal for each graduate -->
                        <div class="modal fade" id="graduateModal<?php echo $student_number; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel"> Graduate's Details</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="d-flex flex-column align-items-center">
                                            <img src="../User/Graduate_Pic/<?php echo $grad_pic; ?>" class="card-img-top img-fluid rounded-circle mt-3" alt="Graduate Image" style="width: 200px; height: 200px; object-fit: cover;">
                                            <div class="text-center">
                                                <h4 class="h4 mt-1 mb-0">
                                                    <?php echo $full_name; ?>
                                                </h4>
                                                <p id="student-number" class="m-0">
                                                    <?php echo $student_number; ?>
                                                </p>
                                                <p id="student-scholar" class="m-0">
                                                    <?php echo $benefactor; ?>
                                                </p>
                                            </div>
                                        </div>

                                        <hr>

                                        <div class="title text-center">
                                            <h5>Personal Information</h5>
                                        </div>

                                        <div class="container-fluid">
                                            <div class="row  text-start p-3">

                                                <div class="col-12 col-lg-6 mb-1 d-flex flex-column justify-content-center text-left ps-5">
                                                    <div class="items ps-5">
                                                        <span class="item-title">Full Name:
                                                            <?php echo $full_name; ?>
                                                        </span>

                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Date of Birth:
                                                            <?php echo $birthday; ?>
                                                        </span>
                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Gender:
                                                            <?php echo $gender; ?>
                                                        </span>
                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Civil Status:
                                                            <?php echo $civil_status; ?>
                                                        </span>
                                                    </div>
                                                </div>

                                                <div class="col-12 col-lg-6 mb-1 d-flex flex-column justify-content-center text-left ps-5">
                                                    <div class="items ps-5">
                                                        <span class="item-title">Current Address:
                                                            <?php echo $current_address; ?>
                                                        </span>
                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Active Contact No:
                                                            <?php echo $contact; ?>
                                                        </span>
                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Email:
                                                            <?php echo $email; ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <hr>

                                        <div class="title text-center">
                                            <h5>Scholarship Information</h5>
                                        </div>

                                        <div class="container-fluid">
                                            <div class="row  text-start p-3">

                                                <div class="col-12 col-lg-6 mb-1 d-flex flex-column justify-content-center text-left ps-5">
                                                    <div class="items ps-5">
                                                        <span class="item-title">Course Completed:
                                                            <?php echo $course; ?>
                                                        </span>
                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Year Graduated:
                                                            <?php echo $year_graduated; ?>
                                                        </span>
                                                    </div>
                                                </div>

                                                <div class="col-12 col-lg-6 mb-1 d-flex flex-column justify-content-center text-left ps-5">
                                                    <div class="items ps-5">
                                                        <span class="item-title">Scholar Benefactor:
                                                            <?php echo $benefactor; ?>
                                                        </span>
                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Campus:
                                                            <?php echo $campus; ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <hr>

                                        <div class="title text-center">
                                            <h5>Current Employment Information</h5>
                                        </div>

                                        <div class="container-fluid">
                                            <div class="row  text-start p-3">

                                                <div class="col-12 col-lg-6 mb-1 d-flex flex-column justify-content-center text-left ps-5">
                                                    <div class="items ps-5">
                                                        <span class="item-title">Status:
                                                            <?php echo $employment; ?>
                                                        </span>
                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Type of Organization:
                                                            <?php echo $org_type; ?>
                                                        </span>
                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Name of Company:
                                                            <?php echo $company_name; ?>
                                                        </span>
                                                    </div>
                                                </div>

                                                <div class="col-12 col-lg-6 mb-1 d-flex flex-column justify-content-center text-left ps-5">
                                                    <div class="items ps-5">
                                                        <span class="item-title">Address of Company:
                                                            <?php echo $comp_address; ?>
                                                        </span>
                                                    </div>
                                                    <div class="items ps-5">
                                                        <span class="item-title">Number of years in the company:
                                                            <?php echo $year_in_company; ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>





                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        <?php
        } else {
            echo "<p>No records found</p>";
        }
        ?>
    </section>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get the icon element
            var icon = document.getElementById('icon');

            // Add a click event listener
            icon.addEventListener('click', function() {
                // Toggle the class to switch the icon
                icon.classList.toggle('bi-arrow-left');
                icon.classList.toggle('bi-arrow-right');
            });
        });
    </script>



    <!-- DATATABLES -->
    <!-- <script  src="https://code.jquery.com/jquery-3.7.0.js"></script> -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="../js/datatable.js"></script>

    <script type="text/javascript" src="../js/sidebar.js"></script>
    <script type="text/javascript" src="../js/bootstrap.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>



</body>

</html>
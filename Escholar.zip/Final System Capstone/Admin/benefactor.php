<?php
session_start();
include_once '../php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['account_number'], $_SESSION['isAdmin'])) {
    header("Location: http://escholar.eyjeyesdiar.com/");
    exit();
} else {
    // Security: Regenerate session ID
    session_regenerate_id(true);

    // Check if the logged-in user is an admin
    if (!$_SESSION['isAdmin']) {
        // header("Location: unauthorized.php");
        header("Location: http://escholar.eyjeyesdiar.com/");
        exit();
    }


    // For example, you can fetch admin-specific data using the account_number
    $accountNumber = $_SESSION['account_number'];

    // Security: Use prepared statement to prevent SQL injection
    $queryAdmin = $conn->prepare("SELECT * FROM admin_account WHERE account_number = ?");
    $queryAdmin->bind_param("s", $accountNumber);
    $queryAdmin->execute();
    $resultAdmin = $queryAdmin->get_result();

    if ($resultAdmin->num_rows == 0) {
        // Admin account not found, handle accordingly
        // header("Location: unauthorized.php");
        header("Location: ../User/login.php");
        exit();
    }

    $resultAdmin->close();

    // Get admin session data
    $adminData = array(
        'account_number' => $_SESSION['account_number'],
        'last_name' => $_SESSION['last_name'],
        'first_name' => $_SESSION['first_name'],
        'middle_name' => $_SESSION['middle_name'],
    );
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benefactors</title>
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="../css/admin_pending.css" />
    <link rel="stylesheet" href="../css/custom.css" />

    <!-- Add the favicon link here -->
    <link rel="icon" type="image/png" href="../img/Logo2.png">


    <!-- Year Picker -->
    <link rel='stylesheet' href='YearPicker/yearpicker.css' />

    <!-- ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- BOOTSTRAP -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <link href="../css/bootstrap.css" rel="stylesheet">

    <!-- DATATABLES -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <script type="javascript/text" src="https://unpkg.com/@popperjs/core@2"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="YearPicker/jquery.min.js"></script>

    <style>
        /* Center align DataTables header and content */
        #benefactor-table.dataTable thead th,
        #benefactor-table.dataTable tbody td {
            text-align: center;
        }

        /* Ensure proper alignment for DataTables wrapper */
        #benefactor-table_wrapper {
            text-align: center;
        }

        /* Left-align length data and info data in DataTables */
        #benefactor-table_info,
        #benefactor-table_length {
            text-align: left;
        }
    </style>
</head>

<body>

    <nav class="navbar bg-body-tertiary fixed-top  ">
        <div class="container-fluid d-flex justify-content-start">

            <div>
                <a class="navbar-brand d-flex align-items-center" href="#">
                    <div class="me-2 h-25 logo">

                        <img src="../img/Logo2.png" class="logo" alt="logo">
                    </div>
                    <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULSU Office of the Student
                        Financial
                        Assistance and Scholarships</h5>
                </a>
            </div>
        </div>
    </nav>


    <div class="sidebar close">
        <ul class="nav-links">
            <li>
                <a href="dashboard.php">
                    <i class="bi bi-house"></i>
                    <span class="link_name">Dashboard</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="dashboard.php">Dashboard</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-book"></i>
                        <span class="link_name">Scholars</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Scholars</a></li>
                    <li><a href="listMasterlist.php">Masterlist</a></li>
                    <li><a href="Listpending.php">Pending</a></li>
                    <li><a href="list_approve.php">Approved</a></li>
                </ul>
            </li>
            <li>
                <a href="benefactor.php">
                    <i class="bi bi-people"></i>
                    <span class="link_name">Benefactors</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="benefactor.php">Benefactors</a></li>
                </ul>
            </li>
            <li>
                <a href="listgraduates.php">
                    <i class="bi bi-award"></i>
                    <span class="link_name">Graduates</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="listgraduates.php">Graduates</a></li>
                </ul>
            </li>
            <li>
                <a href="announcement.php">
                    <i class="bi bi-megaphone"></i>
                    <span class="link_name">Announcement</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="account.php">
                    <i class="bi bi-person"></i>
                    <span class="link_name">Accounts</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="account.php">Accounts</a></li>
                </ul>
            </li>
            <li>
                <a href="activitylogs.php">
                    <i class="bi bi-list-check"></i>
                    <span class="link_name">Activity Logs</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="activitylogs.php">Activity Logs</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-archive"></i>
                        <span class="link_name">Archive</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Archives</a></li>
                    <li><a href="archive_masterlist.php">Masterlist</a></li>
                    <li><a href="archive_benefactor.php">Benefactor</a></li>
                    <li><a href="archive_announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="reports.php">
                    <i class="bi bi-bar-chart"></i>
                    <span class="link_name">Reports</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="reports.php">Charts & Reports</a></li>
                </ul>
            </li>

            <li>
                <div class="profile-details">
                    <div class="profile-content">
                    </div>
                    <div class="name-job">
                        <div class="profile_name">
                            <?php echo $adminData['first_name']; ?>
                        </div>
                        <div class="job">Admin</div>
                    </div>
                    <a href="#" role="button" class=" p-0 text-decoration-none text-black" data-bs-toggle="dropdown" aria-expanded="false"><i style="font-size: 14px;" class="bi bi-chevron-up"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="setting.php">Setting</a></li>
                        <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>

    <section class="home-section">




        <div class="toast-container position-fixed bottom-0 end-0 p-3">
            <div id="success-edit-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        Updated Succesfully.
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>

            <div id="success-archive-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        Successfully Archived.
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>


        </div>
        <div class="banner d-flex justify-content-between align-items-center  ps-1">
            <i class="btn btn-outline-light bi bi-arrow-right sidebar-menu" id="icon"></i>
            <button class="btn btn-save btn-sm me-1 rounded-pill" type="button" data-bs-toggle="modal" data-bs-target="#add-benefactor-modal"><i class="bi bi-plus-circle me-0 me-sm-1"></i><span class="d-none d-sm-inline">Add Benefactor</span></button>
        </div>
        <!-- Modal Add -->
        <div class="modal fade" id="add-benefactor-modal" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-md">
                <div class="modal-content">
                    <form id="add-benefactor-form" onsubmit="return false;">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5">Add Benefactor</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container-fluid">
                                <div id="alert-error"></div>
                                <div class="row gap-1">
                                    <div class="col-12 mb-1 p-0">
                                        <div class="form-floating">
                                            <input type="text" id="benefactor-name" class="form-control" placeholder="" required />
                                            <label class="form-label" for="benefactor-name">Benefactor Name <span class="text-danger"> *</span></label>
                                        </div>
                                    </div>

                                    <div class="col-12 mb-1 p-0">
                                        <select class="form-select" id="benefactor-particular" required>
                                            <option value="" class="text-secondary" selected hidden disabled>Select a
                                                particular <span class="text-danger"> *</span></option>
                                            <option value="Government">Government</option>
                                            <option value="Institutional">Institutional</option>
                                            <option value="Private">Private</option>
                                        </select>
                                    </div>

                                    <div class="col-5 mb-1 p-0">
                                        <input type="text" class="form-control yearpicker" id="from_sy" value="" placeholder="From">
                                    </div>
                                    <div class="col mb-1 p-0 d-flex justify-content-center align-items-center">
                                        <span>-</span>
                                    </div>
                                    <div class="col-5 mb-1 p-0">
                                        <input type="text" class="form-control yearpicker" id="to_sy" readonly placeholder="To">
                                    </div>




                                    <div class="col-12 mb-1 p-0">
                                        <select class="form-select" id="benefactor-semester" required>
                                            <option value="" class="text-secondary" selected hidden disabled>
                                                Semester<span class="text-danger"> *</span>
                                            </option>
                                            <option value="1st">1st Semester</option>
                                            <option value="2nd">2nd Semester</option>
                                        </select>
                                    </div>

                                    <div class="col-6 mb-1 p-0 d-none">
                                        <div class="form-floating">
                                            <input type="number" id="benefactor-slot" class="form-control" placeholder="" />
                                            <label class="form-label" for="benefactor-slot">Slot</label>
                                        </div>
                                    </div>

                                    <div class="col mb-1 p-0 d-none">
                                        <div class="form-floating">
                                            <input type="number" id="benefactor-amount" class="form-control" placeholder="" />
                                            <label class="form-label" for="edit-last-name"><i class="fa-solid fa-peso-sign"></i> Amount</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-save" onclick="addBenefactor()">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Modal Add -->

        <!-- Modal Monitor -->
        <div class="modal fade" id="monitor-benefactor-modal" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-md">
                <div class="modal-content px-3">
                    <form id="add-benefactor-form" onsubmit="return false;">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5">Monitor Benefactor's Scholars</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <!-- Radio buttons for monitor options -->
                            <div class="row gap-1">
                                <div class="col mb-1 p-0">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="monitor-option" id="semester" checked>
                                        <label class="form-check-label" for="monitor-semester">
                                            Per Semester
                                        </label>
                                    </div>
                                </div>
                                <div class="col mb-1 p-0">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="monitor-option" id="renew-acad-year">
                                        <label class="form-check-label" for="renew-acad-year">
                                            Per Academic Year
                                        </label>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-save" data-bs-toggle="modal" data-bs-target="#confirmationModal">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Confirmation Modal -->
        <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="confirmationModalLabel">Confirm Update</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        Are you sure you want to update?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-save" onclick="monitor()">OK</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Confirmation Modal -->

        <!-- Modal Edit -->
        <div class="modal fade" id="edit-benefactor-modal" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-md">
                <div class="modal-content">
                    <form id="edit-benefactor-form" onsubmit="return false;">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5">Edit Benefactor</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container-fluid">
                                <div id="alert-error-edit"></div>
                                <div class="row gap-1">
                                    <input type="number" name="benefactor_id" id="benefactor-id" readonly hidden>
                                    <div class="col mb-1 p-0">
                                        <div class="form-floating">
                                            <input type="text" id="edit-benefactor-name" class="form-control" placeholder="" required />
                                            <label class="form-label" for="benefactor-name">Benefactor Name <span class="text-danger"> *</span></label>
                                        </div>
                                    </div>

                                    <div class="col-12 mb-1 p-0">
                                        <select class="form-select" id="edit-benefactor-particular" required>
                                            <option value="" class="text-secondary" selected hidden disabled>Select a
                                                particular <span class="text-danger"> *</span></option>
                                            <option value="GOVERNMENT">Government</option>
                                            <option value="INSTITUTIONAL">Institutional</option>
                                            <option value="PRIVATE">Private</option>
                                        </select>
                                    </div>

                                    <div class="col-5 mb-1 p-0">
                                        <input type="number" class="form-control yearpicker" id="edit-from_sy" value="" placeholder="From">
                                    </div>
                                    <div class="col mb-1 p-0 d-flex justify-content-center align-items-center">
                                        <span>-</span>
                                    </div>
                                    <div class="col-5 mb-1 p-0">
                                        <input type="number" class="form-control yearpicker" id="edit-to_sy" placeholder="To">
                                    </div>
                                    <div class="col-12 mb-1 p-0">
                                        <select class="form-select" id="edit-benefactor-semester" required>
                                            <option value="" class="text-secondary" selected>Semester<span class="text-danger"> *</span>
                                            </option>
                                            <option value="1ST">1st Semester</option>
                                            <option value="2ND">2nd Semester</option>
                                        </select>
                                    </div>

                                    <div class="col-6 mb-1 p-0 d-none">
                                        <div class="form-floating">
                                            <input type="number" id="edit-benefactor-slot" class="form-control" placeholder="" required />
                                            <label class="form-label" for="benefactor-slot">Slot</label>
                                        </div>
                                    </div>

                                    <div class="col mb-1 p-0 d-none">
                                        <div class="form-floating">
                                            <input type="number" id="edit-benefactor-amount" class="form-control" placeholder="" required />
                                            <label class="form-label" for="edit-last-name"><i class="fa-solid fa-peso-sign"></i> Amount</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-save" onclick="EditBenefactor()">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Modal Edit -->




        <div class=" toast-container position-fixed bottom-0 end-0 p-3">
            <div id="success-add-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        Successfully Added
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>
            <div id="updated-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        Successfully Updated
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>
        </div>


        <nav class="ms-2 mt-2 ">
            <ol class="breadcrumb fs-6">


            </ol>
        </nav>

        <div class=" d-flex justify-content-between ms-2">
            <h2><span class="border-5 border-start border-success me-2"></span>Benefactors</h2>
            <div class="me-3">
                <button type="button" class="btn btn-save delete-btn btn-sm  w-100 d-flex flex-nowrap align-items-center justify-content-center" data-bs-toggle="modal" data-bs-target="#monitor-benefactor-modal">
                    Update Semester
                </button>
            </div>
        </div>

        <div class="container-fluid">
            <div class="p-1 rounded border shadow-sm">
                <div>
                    <div class="table-responsive mt-2 px-1 py-2 ">
                        <table id="benefactor-table" class="table table-striped" style="width:100%">
                            <thead class="table-secondary">
                                <tr>
                                    <th scope="col">Benefactor Name</th>
                                    <th scope="col">Particular</th>
                                    <th scope="col">Academic Year</th>
                                    <th scope="col">Semester</th>
                                    <th scope="col" class="d-none">Slots</th>
                                    <th scope="col" class="d-none">Amount</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody id="benefactor-table-body">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src='YearPicker/yearpicker.js'></script>


    <script type="text/javascript" src="../js/sidebar.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <!-- DATATABLES -->
    <!-- <script  src="https://code.jquery.com/jquery-3.7.0.js"></script> -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="../js/datatable.js"></script>
    <script type="text/javascript" src="../js/monitor_scholars.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            actLogs('<?php echo $adminData['first_name'] ?>', '<?php echo $adminData['last_name'] ?>');

        });
    </script>
    <script>
        $(document).ready(function() {

            $("#from_sy").yearpicker({
                year: new Date().getFullYear(),
                startYear: new Date().getFullYear() - 10,
                endYear: new Date().getFullYear() + 10,
                onChange: function() {
                    console.log(parseInt($("#from_sy").val()) + 1);
                    // $("#to_sy").removeAttr("disabled");
                    $("#to_sy").val(parseInt($("#from_sy").val()) + 1);

                },
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get the icon element
            var icon = document.getElementById('icon');

            // Add a click event listener
            icon.addEventListener('click', function() {
                // Toggle the class to switch the icon
                icon.classList.toggle('bi-arrow-left');
                icon.classList.toggle('bi-arrow-right');
            });
        });
    </script>
</body>

</html>
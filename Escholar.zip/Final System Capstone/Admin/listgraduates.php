<?php
session_start();
include_once '../php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['account_number'], $_SESSION['isAdmin'])) {
    header("Location: http://escholar.eyjeyesdiar.com/");
    exit();
} else {
    // Security: Regenerate session ID
    session_regenerate_id(true);

    // Check if the logged-in user is an admin
    if (!$_SESSION['isAdmin']) {
        // header("Location: unauthorized.php");
        header("Location: http://escholar.eyjeyesdiar.com/");
        exit();
    }


    // For example, you can fetch admin-specific data using the account_number
    $accountNumber = $_SESSION['account_number'];

    // Security: Use prepared statement to prevent SQL injection
    $queryAdmin = $conn->prepare("SELECT * FROM admin_account WHERE account_number = ?");
    $queryAdmin->bind_param("s", $accountNumber);
    $queryAdmin->execute();
    $resultAdmin = $queryAdmin->get_result();

    if ($resultAdmin->num_rows == 0) {
        // Admin account not found, handle accordingly
        // header("Location: unauthorized.php");
        header("Location: ../User/login.php");
        exit();
    }

    $resultAdmin->close();

    // Get admin session data
    $adminData = array(
        'account_number' => $_SESSION['account_number'],
        'last_name' => $_SESSION['last_name'],
        'first_name' => $_SESSION['first_name'],
        'middle_name' => $_SESSION['middle_name'],
    );
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Graduates</title>
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="../css/custom.css" />

    <!-- Add the favicon link here -->
    <link rel="icon" type="image/png" href="../img/Logo2.png">


    <!-- ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- BOOTSTRAP -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <link href="../css/bootstrap.css" rel="stylesheet">

    <!-- DATATABLES -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="YearPicker/jquery.min.js"></script>

    <style>
        /* Center align DataTables header and content */
        #table-graduatelist.dataTable thead th,
        #table-graduatelist.dataTable tbody td {
            text-align: center;
        }

        /* Ensure proper alignment for DataTables wrapper */
        #table-graduatelist_wrapper {
            text-align: center;
        }

        /* Left-align length data and info data in DataTables */
        #table-graduatelist_info,
        #table-graduatelist_length {
            text-align: left;
        }
    </style>
</head>

<body>

    <nav class="navbar bg-body-tertiary fixed-top  ">
        <div class="container-fluid d-flex justify-content-start">

            <div>
                <a class="navbar-brand d-flex align-items-center" href="#">
                    <div class="me-2 h-25 logo">

                        <img src="../img/Logo2.png" class="logo" alt="logo">
                    </div>
                    <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULSU Office of the Student
                        Financial
                        Assistance and Scholarships</h5>
                </a>
            </div>
        </div>
    </nav>


    <div class="sidebar close">
        <ul class="nav-links">
            <li>
                <a href="dashboard.php">
                    <i class="bi bi-house"></i>
                    <span class="link_name">Dashboard</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="dashboard.php">Dashboard</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-book"></i>
                        <span class="link_name">Scholars</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Scholars</a></li>
                    <li><a href="listMasterlist.php">Masterlist</a></li>
                    <li><a href="Listpending.php">Pending</a></li>
                    <li><a href="list_approve.php">Approved</a></li>
                </ul>
            </li>
            <li>
                <a href="benefactor.php">
                    <i class="bi bi-people"></i>
                    <span class="link_name">Benefactors</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="benefactor.php">Benefactors</a></li>
                </ul>
            </li>
            <li>
                <a href="listgraduates.php">
                    <i class="bi bi-award"></i>
                    <span class="link_name">Graduates</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="listgraduates.php">Graduates</a></li>
                </ul>
            </li>
            <li>
                <a href="announcement.php">
                    <i class="bi bi-megaphone"></i>
                    <span class="link_name">Announcement</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="account.php">
                    <i class="bi bi-person"></i>
                    <span class="link_name">Accounts</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="account.php">Accounts</a></li>
                </ul>
            </li>
            <li>
                <a href="activitylogs.php">
                    <i class="bi bi-list-check"></i>
                    <span class="link_name">Activity Logs</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="activitylogs.php">Activity Logs</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class="bi bi-archive"></i>
                        <span class="link_name">Archive</span>
                    </a>

                    <i class="bi bi-caret-down arrow"></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Archives</a></li>
                    <li><a href="archive_masterlist.php">Masterlist</a></li>
                    <li><a href="archive_benefactor.php">Benefactor</a></li>
                    <li><a href="archive_announcement.php">Announcement</a></li>
                </ul>
            </li>
            <li>
                <a href="reports.php">
                    <i class="bi bi-bar-chart"></i>
                    <span class="link_name">Reports</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="reports.php">Charts & Reports</a></li>
                </ul>
            </li>

            <li>
                <div class="profile-details">
                    <div class="profile-content">
                    </div>
                    <div class="name-job">
                        <div class="profile_name">
                            <?php echo $adminData['first_name']; ?>
                        </div>
                        <div class="job">Admin</div>
                    </div>
                    <a href="#" role="button" class=" p-0 text-decoration-none text-black" data-bs-toggle="dropdown" aria-expanded="false"><i style="font-size: 14px;" class="bi bi-chevron-up"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="setting.php">Setting</a></li>
                        <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>

    <section class="home-section">
        <div class="banner d-flex justify-content-start align-items-center ps-1">

            <i class="btn btn-outline-light bi bi-arrow-right sidebar-menu" id="icon"></i>
        </div>
        <nav class="ms-2 mt-2 ">
            <ol class="breadcrumb fs-6">


            </ol>
        </nav>

        <div class="ms-2 mb-5">
            <h2><span class="border-5 border-start border-success me-2"></span>List of Graduates</h2>
        </div>

        <div class="container-fluid mt-3">
            <div class="p-1 rounded border border shadow-sm">
                <div class="table-responsive px-1 py-2">
                    <table id="table-graduatelist" class="table table-hover text-center">
                        <thead class="table-secondary">
                            <tr>

                                <th scope="col">Batch</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody id="table-graduatelist-body">


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>





    <!-- DATATABLES -->
    <!-- <script  src="https://code.jquery.com/jquery-3.7.0.js"></script> -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="../js/datatable.js"></script>

    <script type="text/javascript" src="../js/sidebar.js"></script>
    <script type="text/javascript" src="../js/bootstrap.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <script type="text/javascript">
        document.addEventListener("DOMContentLoaded", () => {
            fetchGraduateList();
        });

        // FETCH BENEFACTOR IN MASTERLIST
        function fetchGraduateList() {
            $('#table-graduatelist').DataTable().destroy();
            const tableBody = document.getElementById("table-graduatelist-body");

            const displayData = (data) =>
                tableBody.innerHTML = ""; // Clear previous data

            data.forEach((year_graduated) => {
                const newRow = document.createElement("tr");
                newRow.innerHTML = `
                        <td>${year_graduated}</td>
                        <td>
                            <a href="graduate.php?id=${year_graduated}" id="${year_graduated}" class="btn btn-success btn-sm" style="background-color: #008000;">View</a>
                        </td>
                    `;
                tableBody.appendChild(newRow);
            });
            $('#table-graduatelist').DataTable(); // Initialize DataTable here
        };

        // Function to handle errors
        const handleError = (error) => {
            console.error("Error:", error);
            tableBody.innerHTML = "<tr><td colspan='10' class='text-center'>An error occurred while fetching data.</td></tr>";
        };

        // AJAX fetch request
        fetch("../php/getBatch.php")
            .then((response) => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then((data) => {
                displayData(data);
                console.log(data);
            })
            .catch((error) => {
                handleError(error);
            });
        }
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get the icon element
            var icon = document.getElementById('icon');

            // Add a click event listener
            icon.addEventListener('click', function() {
                // Toggle the class to switch the icon
                icon.classList.toggle('bi-arrow-left');
                icon.classList.toggle('bi-arrow-right');
            });
        });
    </script>

</body>

</html>
<?php
session_start();
include_once '../php/config.php';
$conn = OpenCon();


// Security: Check if the user is already logged in
if (!isset($_SESSION['account_number'], $_SESSION['isAdmin'])) {
  header("Location: http://escholar.eyjeyesdiar.com/");
  exit();
} else {
  // Security: Regenerate session ID
  session_regenerate_id(true);

  // Check if the logged-in user is an admin
  if (!$_SESSION['isAdmin']) {
    // header("Location: unauthorized.php");
    header("Location: http://escholar.eyjeyesdiar.com/");
    exit();
  }

  // For example, you can fetch admin-specific data using the account_number
  $accountNumber = $_SESSION['account_number'];

  // Security: Use prepared statement to prevent SQL injection
  $queryAdmin = $conn->prepare("SELECT * FROM admin_account WHERE account_number = ?");
  $queryAdmin->bind_param("s", $accountNumber);
  $queryAdmin->execute();
  $resultAdmin = $queryAdmin->get_result();

  if ($resultAdmin->num_rows == 0) {
    // Admin account not found, handle accordingly
    // header("Location: unauthorized.php");
    header("Location: ../User/login.php");
    exit();
  }

  $resultAdmin->close();

  // Get admin session data
  $adminData = array(
    'account_number' => $_SESSION['account_number'],
    'last_name' => $_SESSION['last_name'],
    'first_name' => $_SESSION['first_name'],
    'middle_name' => $_SESSION['middle_name'],
  );
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reports</title>
  <link rel="stylesheet" href="../css/style.css" />
  <link rel="stylesheet" href="../css/custom.css" />


  <!-- Add the favicon link here -->
  <link rel="icon" type="image/png" href="../img/Logo2.png">

  <!-- ICON -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <!-- BOOTSTRAP -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
  <link href="../css/bootstrap.css" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">


  <!-- HIGHCHARTS -->
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/data.js"></script>
  <script src="https://code.highcharts.com/modules/drilldown.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
  <script src="https://code.highcharts.com/modules/accessibility.js"></script>
</head>

<body>

  <nav class="navbar bg-body-tertiary fixed-top  ">
    <div class="container-fluid d-flex justify-content-start">
      <div>
        <a class="navbar-brand d-flex align-items-center" href="#">
          <div class="me-2 h-25 logo">
            <img src="../img/Logo2.png" class="logo" alt="logo">
          </div>
          <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULSU Office of the Student
            Financial
            Assistance and Scholarships</h5>
        </a>
      </div>
    </div>
  </nav>

  <div class="sidebar close">
    <ul class="nav-links">
      <li>
        <a href="dashboard.php">
          <i class="bi bi-house"></i>
          <span class="link_name">Dashboard</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="dashboard.php">Dashboard</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="">
            <i class="bi bi-book"></i>
            <span class="link_name">Scholars</span>
          </a>

          <i class="bi bi-caret-down arrow"></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href="">Scholars</a></li>
          <li><a href="listMasterlist.php">Masterlist</a></li>
          <li><a href="Listpending.php">Pending</a></li>
          <li><a href="list_approve.php">Approved</a></li>
        </ul>
      </li>
      <li>
        <a href="benefactor.php">
          <i class="bi bi-people"></i>
          <span class="link_name">Benefactors</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="benefactor.php">Benefactors</a></li>
        </ul>
      </li>
      <li>
        <a href="listgraduates.php">
          <i class="bi bi-award"></i>
          <span class="link_name">Graduates</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="listgraduates.php">Graduates</a></li>
        </ul>
      </li>
      <li>
        <a href="announcement.php">
          <i class="bi bi-megaphone"></i>
          <span class="link_name">Announcement</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="announcement.php">Announcement</a></li>
        </ul>
      </li>
      <li>
        <a href="account.php">
          <i class="bi bi-person"></i>
          <span class="link_name">Accounts</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="account.php">Accounts</a></li>
        </ul>
      </li>
      <li>
        <a href="activitylogs.php">
          <i class="bi bi-list-check"></i>
          <span class="link_name">Activity Logs</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="activitylogs.php">Activity Logs</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="">
            <i class="bi bi-archive"></i>
            <span class="link_name">Archive</span>
          </a>

          <i class="bi bi-caret-down arrow"></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href="">Archives</a></li>
          <li><a href="archive_masterlist.php">Masterlist</a></li>
          <li><a href="archive_benefactor.php">Benefactor</a></li>
          <li><a href="archive_announcement.php">Announcement</a></li>
        </ul>
      </li>
      <li>
        <a href="reports.php">
          <i class="bi bi-bar-chart"></i>
          <span class="link_name">Reports</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="reports.php">Charts & Reports</a></li>
        </ul>
      </li>

      <li>
        <div class="profile-details">
          <div class="profile-content">
          </div>
          <div class="name-job">
            <div class="profile_name">
              <?php echo $adminData['first_name']; ?>
            </div>
            <div class="job">Admin</div>
          </div>
          <a href="#" role="button" class=" p-0 text-decoration-none text-black" data-bs-toggle="dropdown" aria-expanded="false"><i style="font-size: 14px;" class="bi bi-chevron-up"></i></a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="setting.php">Setting</a></li>
            <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
          </ul>
        </div>
      </li>
    </ul>
  </div>


  <section class="home-section">
    <div class="banner d-flex justify-content-start align-items-center ps-1">

      <i class="btn btn-outline-light bi bi-arrow-right sidebar-menu" id="icon"></i>
    </div>
    <nav class="ms-2 mt-2">

    </nav>
    <div class="ms-2 mb-3">
      <h2><span class="border-5 border-start border-success me-2"></span>Reports</h2>
    </div>

    <div class="container-fluid">

      <div class="d-flex justify-content-end mb-2">
        <div class="toast-container position-fixed bottom-0 end-0 p-3">
          <div id="success-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Downloading Excel File
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
          </div>
          <div id="failed-toast" class="toast align-items-center text-bg-danger border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Please Select Category
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
          </div>
        </div>


      </div>

      <!-- Bootstrap Select with Filter Button -->
      <div class="container-fluid d-flex justify-content-end">
        <div class="input-group w-25 me-3">
          <select class="form-control" id="mySelect">

            <!-- Add more options as needed -->
          </select>
          <div class="input-group-append">
            <button class="btn btn-save" onclick="filterSelect()">Filter</button>
          </div>
        </div>

      </div>

      <!-- End Bootstrap Select -->

      <div class="row mx-3 mt-3">
        <div class="col-lg-4 mb-2">
          <div class="card">
            <div class="card-header">
              <div class="d-flex justify-content-end">
                <button class="btn btn-save btn-sm btn-rounded" data-bs-toggle="modal" data-bs-target="#approveBenefactorModal"><i class="bi bi-file-earmark-arrow-down me-0 me-sm-1"></i><span class="print-text">Download
                    Reports</span></button>
              </div>
            </div>

            <div class="card-body">
              <figure class="highcharts-figure">
                <div id="approve-per-benefactor">
                </div>
              </figure>
            </div>
          </div>
        </div>

        <div class="col-lg-4 mb-2">
          <div class="card">
            <div class="card-header">
              <div class="d-flex justify-content-end">
                <button class="btn btn-save btn-sm btn-rounded" data-bs-toggle="modal" data-bs-target="#perCollegeModal"><i class="bi bi-file-earmark-arrow-down me-0 me-sm-1"></i><span class="print-text">Download Reports</span></button>
              </div>
            </div>

            <div class="card-body">
              <figure class="highcharts-figure">
                <div id="scholars-per-college">
                </div>
              </figure>
            </div>
          </div>
        </div>

        <div class="col-lg-4 mb-2">
          <div class="card">
            <div class="card-header">
              <div class="d-flex justify-content-end">
                <button class="btn btn-save btn-sm btn-rounded" data-bs-toggle="modal" data-bs-target="#graduateModal"><i class="bi bi-file-earmark-arrow-down me-0 me-sm-1"></i><span class="print-text">Download Reports</span></button>
              </div>
            </div>

            <div class="card-body">
              <figure class="highcharts-figure">
                <div id="graduate-status">
                </div>
              </figure>
            </div>
          </div>
        </div>


        <!-- <div class="col-lg-4 mb-2">
          <div class="card">
            <div class="card-header">
              <div class="d-flex justify-content-end">
                <button type="button" class="btn btn-primary btn-sm btn-rounded" data-bs-toggle="modal"
                  data-bs-target="#benefactorModal"><i class="bi bi-printer me-0 me-sm-1"></i><span
                    class="print-text">Download Reports</span></button>
              </div>
            </div>
            <div class="card-body">
              <figure class="highcharts-figure">
                <div id="benefactor">
                </div>
              </figure>
            </div>
          </div>
        </div>  -->

      </div>

      <div class="row mx-3 mt-3">
        <div class="col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div class="d-flex justify-content-end">
                <button type="button" class="btn btn-save btn-sm btn-rounded" data-bs-toggle="modal" data-bs-target="#ScholarsPerBenefactorModal"><i class="bi bi-file-earmark-arrow-down me-0 me-sm-1"></i><span class="print-text">Download
                    Reports</span></button>
              </div>
            </div>
            <div class="card-body">
              <figure class="highcharts-figure">
                <div id="total-scholars">
                </div>
              </figure>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Graduate -->
    <div class="modal fade" id="graduateModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title fs-5">Download Reports</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="graduateSelect">
              <label for="employmentStatusSelect">Select Status:</label>
              <select class="form-select form-select-sm border-primary mb-1" aria-label="Default select example" id="employmentStatusSelect">
                <option selected disabled hidden>Employment Status</option>
                <?php



                // Check for connection errors
                if (!$conn) {
                  die("Connection failed: " . mysqli_connect_error());
                }

                // Query to select distinct employment statuses from the graduate_info table
                $sql = "SELECT DISTINCT employment FROM graduate_information";
                $result = mysqli_query($conn, $sql);

                // Populate the select options with data from the database
                while ($row = mysqli_fetch_assoc($result)) {
                  $employmentStatus = strtoupper($row['employment']);
                  echo "<option value='" . $employmentStatus . "'>" . $employmentStatus . "</option>";
                }

                // Close the database connection
                mysqli_close($conn);
                ?>
              </select>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-save btn-sm" id="graduateprint">Download</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Graduate -->

    <!-- Approve Per Benefactor -->
    <div class="modal fade" id="approveBenefactorModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title fs-5">Download Reports</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="perBenefactorSelect">
              <label for="benefactorSelect">Select Benefactor:</label>
              <select class="form-select form-select-sm border-primary mb-1" aria-label="Default select example" id="benefactorSelect">

              </select>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-save btn-sm" id="approvePrint">Download</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Scholars Per Campus -->

    <!-- Scholars Per College-->
    <div class="modal fade" id="perCollegeModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title fs-5">Download Reports</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="collegeFormSelect">
              <label for="collegeSelect">Select College:</label>
              <select class="form-select form-select-sm border-primary mb-1" aria-label="Default select example" id="collegeSelect">

              </select>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-save btn-sm" id="perCollegePrint">Download</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Scholars Per College-->


    <!-- All Scholars Per Benefactor -->
    <div class="modal fade" id="ScholarsPerBenefactorModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title fs-5">Download Reports</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="perScholarsFormSelect">
              <label for="ScholarsSelect">Select Benefactor:</label>
              <select class="form-select form-select-sm border-primary mb-1" aria-label="Default select example" id="ScholarsSelect">

              </select>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-save btn-sm" id="perScholarsPrint">Download</button>
          </div>
        </div>
      </div>
    </div>
    <!-- All Scholars Per Benefactor -->





  </section>


  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>

  <!-- Include Bootstrap and DataTables scripts -->
  <script type="text/javascript" src="../js/bootstrap.js"></script>
  <script type="text/javascript" src="../js/charts.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

  <!-- <script type="text/javascript" src="../js/reports.js"></script> -->
  <script type="text/javascript" src="../js/sidebar.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Get the icon element
      var icon = document.getElementById('icon');

      // Add a click event listener
      icon.addEventListener('click', function() {
        // Toggle the class to switch the icon
        icon.classList.toggle('bi-arrow-left');
        icon.classList.toggle('bi-arrow-right');
      });
    });
  </script>



</body>

</html>
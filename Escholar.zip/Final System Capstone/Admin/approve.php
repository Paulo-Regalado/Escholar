<?php
session_start();
include_once '../php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['account_number'], $_SESSION['isAdmin'])) {
  header("Location: http://escholar.eyjeyesdiar.com/");
  exit();
} else {
  // Security: Regenerate session ID
  session_regenerate_id(true);

  // Check if the logged-in user is an admin
  if (!$_SESSION['isAdmin']) {
    // header("Location: unauthorized.php");
    header("Location: http://escholar.eyjeyesdiar.com/");
    exit();
  }

  // For example, you can fetch admin-specific data using the account_number
  $accountNumber = $_SESSION['account_number'];

  // Security: Use prepared statement to prevent SQL injection
  $queryAdmin = $conn->prepare("SELECT * FROM admin_account WHERE account_number = ?");
  $queryAdmin->bind_param("s", $accountNumber);
  $queryAdmin->execute();
  $resultAdmin = $queryAdmin->get_result();

  if ($resultAdmin->num_rows == 0) {
    // Admin account not found, handle accordingly
    // header("Location: unauthorized.php");
    header("Location: ../User/login.php");
    exit();
  }

  $resultAdmin->close();

  // Get admin session data
  $adminData = array(
    'account_number' => $_SESSION['account_number'],
    'last_name' => $_SESSION['last_name'],
    'first_name' => $_SESSION['first_name'],
    'middle_name' => $_SESSION['middle_name'],
  );
}

if (isset($_GET['id'])) {
  $id = $_GET['id'];
} else {
  header("Location: list_approve.php");
  exit();
}

$query = "SELECT * FROM benefactor WHERE id=?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id); // "i" indicates an integer, adjust as needed
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $particular = $row["particular"];
    $semester = $row["semester"];
    $benefactor_name = $row["name"];
    $slot = $row["slot"];
    $amount = $row["amount"];
    $table_name = $row["table_name"];
  }
} else {
  // No matching benefactors found, redirect to Listpending.php
  header("Location: Listpending.php");
  exit();
}

// $stmt->close(); // Close the prepared statement

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Approved Scholars</title>
  <link rel="stylesheet" href="../css/style.css" />
  <link rel="stylesheet" href="../css/admin_approve.css">
  <link rel="stylesheet" href="../css/custom.css">

  <!-- Add the favicon link here -->
  <link rel="icon" type="image/png" href="../img/Logo2.png">

  <!-- Email Library -->
  <script src="https://smtpjs.com/v3/smtp.js"></script>

  <!-- ICON -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <!-- BOOTSTRAP -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
  <link href="../css/bootstrap.css" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- DATATABLES -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

  <style>
    /* Center align DataTables header and content */
    #approve-table.dataTable thead th,
    #approve-table.dataTable tbody td {
      text-align: center;
    }

    /* Ensure proper alignment for DataTables wrapper */
    #approve-table_wrapper {
      text-align: center;
    }

    /* Left-align length data and info data in DataTables */
    #approve-table_info,
    #approve-table_length {
      text-align: left;
    }

    #processed-table.dataTable thead th,
    #processed-table.dataTable tbody td {
      text-align: center;
    }

    /* Ensure proper alignment for DataTables wrapper */
    #processed-table_wrapper {
      text-align: center;
    }

    /* Left-align length data and info data in DataTables */
    #processed-table_info,
    #processed-table_length {
      text-align: left;
    }

    #claim-table.dataTable thead th,
    #claim-table.dataTable tbody td {
      text-align: center;
    }

    /* Ensure proper alignment for DataTables wrapper */
    #claim-table_wrapper {
      text-align: center;
    }

    /* Left-align length data and info data in DataTables */
    #claim-table_info,
    #claim-table_length {
      text-align: left;
    }
  </style>
</head>

<body>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.16/jspdf.plugin.autotable.min.js"></script>

  <nav class="navbar bg-body-tertiary fixed-top  ">
    <div class="container-fluid d-flex justify-content-start">

      <div>
        <a class="navbar-brand d-flex align-items-center" href="#">
          <div class="me-2 h-25 logo">

            <img src="../img/Logo2.png" class="logo" alt="logo">
          </div>
          <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULSU Office of the Student
            Financial
            Assistance and Scholarships</h5>
        </a>
      </div>
    </div>
  </nav>


  <div class="sidebar close">
    <ul class="nav-links">
      <li>
        <a href="dashboard.php">
          <i class="bi bi-house"></i>
          <span class="link_name">Dashboard</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="dashboard.php">Dashboard</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="">
            <i class="bi bi-book"></i>
            <span class="link_name">Scholars</span>
          </a>

          <i class="bi bi-caret-down arrow"></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href="">Scholars</a></li>
          <li><a href="listMasterlist.php">Masterlist</a></li>
          <li><a href="Listpending.php">Pending</a></li>
          <li><a href="list_approve.php">Approved</a></li>
        </ul>
      </li>
      <li>
        <a href="benefactor.php">
          <i class="bi bi-people"></i>
          <span class="link_name">Benefactors</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="benefactor.php">Benefactors</a></li>
        </ul>
      </li>
      <li>
        <a href="listgraduates.php">
          <i class="bi bi-award"></i>
          <span class="link_name">Graduates</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="listgraduates.php">Graduates</a></li>
        </ul>
      </li>
      <li>
        <a href="announcement.php">
          <i class="bi bi-megaphone"></i>
          <span class="link_name">Announcement</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="announcement.php">Announcement</a></li>
        </ul>
      </li>
      <li>
        <a href="account.php">
          <i class="bi bi-person"></i>
          <span class="link_name">Accounts</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="account.php">Accounts</a></li>
        </ul>
      </li>
      <li>
        <a href="activitylogs.php">
          <i class="bi bi-list-check"></i>
          <span class="link_name">Activity Logs</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="activitylogs.php">Activity Logs</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="">
            <i class="bi bi-archive"></i>
            <span class="link_name">Archive</span>
          </a>

          <i class="bi bi-caret-down arrow"></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href="">Archives</a></li>
          <li><a href="archive_masterlist.php">Masterlist</a></li>
          <li><a href="archive_benefactor.php">Benefactor</a></li>
          <li><a href="archive_announcement.php">Announcement</a></li>
        </ul>
      </li>
      <li>
        <a href="reports.php">
          <i class="bi bi-bar-chart"></i>
          <span class="link_name">Reports</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="reports.php">Charts & Reports</a></li>
        </ul>
      </li>

      <li>
        <div class="profile-details">
          <div class="profile-content">
          </div>
          <div class="name-job">
            <div class="profile_name">
              <?php echo $adminData['first_name']; ?>
            </div>
            <div class="job">Admin</div>
          </div>
          <a href="#" role="button" class=" p-0 text-decoration-none text-black" data-bs-toggle="dropdown"
            aria-expanded="false"><i style="font-size: 14px;" class="bi bi-chevron-up"></i></a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="setting.php">Setting</a></li>
            <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
          </ul>
        </div>
      </li>
    </ul>
  </div>
  <section class="home-section">
    <div class="banner d-flex justify-content-start align-items-center ps-1">
      <i class="btn btn-outline-light bi bi-arrow-right sidebar-menu" id="icon"></i>

      <div class="dito-toast">

        <div class="toast-container position-fixed bottom-0 end-0 p-3">
          <div id="success-move-toast" class="toast align-items-center text-bg-success border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Successfully moved.
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                aria-label="Close"></button>
            </div>
          </div>
          <div id="failed-move-toast" class="toast align-items-center text-bg-danger border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Move failed.
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                aria-label="Close"></button>
            </div>
          </div>
          <div id="reject-pending-toast" class="toast align-items-center text-bg-danger border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Scholar has been rejected.
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                aria-label="Close"></button>
            </div>
          </div>
          <div id="skipped-toast" class="toast align-items-center text-bg-danger border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Added Records: <span id="added-count"></span> Skipped Records: <span id="record-count"></span>
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                aria-label="Close"></button>
            </div>
          </div>
          <div id="success-add-toast" class="toast align-items-center text-bg-success border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Successfully Added
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                aria-label="Close"></button>
            </div>
          </div>
          <div id="failed-toast" class="toast align-items-center text-bg-danger border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Cannot Insert Data Due to Incorrect Column Format
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                aria-label="Close"></button>
            </div>
          </div>
          <div id="incorrect-toast" class="toast align-items-center text-bg-danger border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Cannot Insert Data Due to Incorrect Data Format
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                aria-label="Close"></button>
            </div>
          </div>
          <div id="select-failed-toast" class="toast align-items-center text-bg-danger border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
              <div class="toast-body">
                Please select a record
              </div>
              <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                aria-label="Close"></button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Add -->
    <div class="modal fade" id="add-approved" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5">Add Approved Scholar</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <div class="modal-body">
            <form id="add-pending-form" class="" onsubmit="return false;">

              <div id="alert-result"></div>
              <div class="container-fluid">

                <div class="row gap-1">

                  <div class="col-12 mb-1 p-0">
                    <div class="form-floating ">
                      <input type="text" id="edit-benefactor" class="form-control"
                        value="<?php echo $benefactor_name; ?>" readonly />
                      <label class="form-label" for="edit-benefactor">Benefactor<span class="text-danger">
                          *</span></label>
                    </div>
                  </div>

                  <div class="col-12 mb-2 p-0">
                    <div class="form-floating  position-relative">
                      <input type="number" id="student-number" class="form-control" placeholder=""
                        onkeyup="searchStudentNo('<?php echo $table_name; ?>')" required />
                      <label class="form-label" for="student-number">Student No.<span class="text-danger">
                          *</span></label>
                      <div class='ms-2 ' id="result"></div>
                    </div>
                    <div class="ms-2 text-secondary" id="loader" style="display: none">
                      <span>Loading...</span>
                      <div class="spinner-border spinner-border-sm ms-auto" role="status" aria-hidden="true"></div>
                    </div>

                  </div>

                  <div class="col-4 mb-1 p-0">
                    <div class="form-floating">
                      <input type="text" id="last-name" class="form-control" placeholder="" required />
                      <label class="form-label" for="last-name">Last Name<span class="text-danger"> *</span></label>
                    </div>
                  </div>

                  <div class="col-4 mb-1 p-0">
                    <div class="form-floating">
                      <input type="text" id="first-name" class="form-control" placeholder="" required />
                      <label class="form-label" for="first-name">First Name<span class="text-danger"> *</span></label>
                    </div>
                  </div>

                  <div class="col mb-1 p-0">
                    <div class="form-floating">
                      <input type="text" id="middle-name" class="form-control" placeholder="" />
                      <label class="form-label" for="middle-name">Middle Name</label>
                    </div>
                  </div>

                  <div class="col-6 mb-1 p-0">
                    <div class="form-floating">
                      <input type="email" id="email" class="form-control" placeholder="" required />
                      <label class="form-label" for="email">Email<span class="text-danger"> *</span></label>
                    </div>
                  </div>

                  <div class="col mb-1 p-0">
                    <div class="form-floating">
                      <input type="text" id="contact" class="form-control" pattern="09[0-9]{9}"
                        placeholder="09XXXXXXXXX" required />
                      <label class="form-label" for="contact">Contact No.<span class="text-danger"> *</span></label>
                    </div>
                  </div>
                </div>

                <div class="row gap-1">
                  <div class="col mb-1 p-0">
                    <div class="form-floating">
                      <input type="number" id="gwa" class="form-control" step="0.01" placeholder="" required />
                      <label class="form-label" for="gwa">GWA<span class="text-danger"> *</span></label>
                    </div>
                  </div>

                  <div class="col mb-1 p-0">
                    <div class="form-floating">
                      <input type="number" id="units" class="form-control" placeholder="" required />
                      <label class="form-label" for="units">Units<span class="text-danger"> *</span></label>
                    </div>
                  </div>

                </div>

                <div class="row gap-1">

                  <div class="col-6 mb-1 p-0">
                    <select class="form-select" id="add-campus" required>
                      <option value="" class="text-secondary" selected disabled>Select a campus<span
                          class="text-danger">
                          *</span></option>
                      <option value="Bustos Campus">Bustos Campus</option>
                      <option value="Hagonoy Campus">Hagonoy Campus</option>
                      <option value="Malolos Campus">Malolos Campus</option>
                      <option value="Meneses Campus">Meneses Campus</option>
                      <option value="San Rafael Campus">San Rafael Campus</option>
                      <option value="Sarmiento">Sarmiento Campus</option>
                    </select>
                  </div>


                  <div class="col mb-1 p-0">
                    <select class="form-select" id="add-college" onchange="changeCollege()" required>
                      <option value="" selected disabled hidden>Select College<span class="text-danger"> *</span>
                      </option>
                      <option value="CAFA">College of Architecture and Fine Arts</option>
                      <option value="CAL">College of Arts and Letters</option>
                      <option value="CBA">College of Business Administration</option>
                      <option value="CCJE">College of Criminal Justice Education</option>
                      <option value="CHTM">College of Hospitality and Tourism Management</option>
                      <option value="CICT">College of Information and Communications Technology</option>
                      <option value="CIT">College of Industrial Technology</option>
                      <option value="CLAW">College of Law</option>
                      <option value="CN">College of Nursing</option>
                      <option value="COE">College of Engineering</option>
                      <option value="COED">College of Education</option>
                      <option value="CS">College of Science</option>
                      <option value="CSER">College of Sports, Exercise and Recreation</option>
                      <option value="CSSP">College of Social Sciences and Philosophy</option>
                    </select>
                  </div>
                </div>

                <div class="row gap-1">
                  <div class="col-6 mb-1 p-0">
                    <select class="form-select" id="add-course" onchange="checkArchi()" disabled required>
                      <option value="" class="text-secondary" selected disabled>Select Course<span class="text-danger">
                          *</span></option>
                    </select>
                  </div>

                  <div class="col mb-1 p-0">
                    <select class="form-select" id="year-level" required>
                      <option value="" selected disabled hidden>Year Level<span class="text-danger"> *</span></option>
                      <option value="1st">1st Year</option>
                      <option value="2nd">2nd Year</option>
                      <option value="3rd">3rd Year</option>
                      <option value="4th">4th Year</option>
                    </select>
                  </div>
                </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-save" id="add-masterlist"
                  onclick="addApprovedScholar('<?php echo $table_name; ?>', '<?php echo $particular; ?>')">Add</button>
              </div>


            </form>
          </div>

        </div>
      </div>
    </div>

    <!-- Modal Add-->

    <!-- Modal Import -->
    <div class="modal fade" id="import-approved" data-bs-keyboard=" false" tabindex="-1"
      aria-labelledby="importModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5">Import Scholars</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="import-approved-form" name="upload_excel" enctype="multipart/form-data" onsubmit="return false;">
              <div class="col-12 mb-1 p-0">
                <div class="form-floating">
                  <input type="text" id="edit-benefactor" class="form-control" value="<?php echo $benefactor_name; ?>"
                    readonly />
                  <label class="form-label" for="edit-benefactor">Benefactor<span class="text-danger"> *</span></label>
                </div>
              </div>

              <div class="form-floating">
                <input type="file" class="form-control" id="excel-file" name="file" accept=".xlsx, .csv" required>
                <label for="file">Upload File<span class="text-danger"> *</span></label>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-save" id="import-masterlist"
                  onclick="importApprovedScholar('<?php echo $table_name; ?>')">Import</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal Import-->

    <nav class="ms-2 mt-2">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="" class="text-decoration-none text-secondary">Scholars</a></li>
        <li class="breadcrumb-item"><a href="list_approve.php" class="text-decoration-none text-secondary">Approved
            Scholars</a></li>
        <li class="breadcrumb-item active" aria-current="page">
          <?php echo $benefactor_name; ?>
        </li>
      </ol>
    </nav>

    <div class="ms-2 mb-5">
      <h2><span class="border-5 border-start border-success me-2"></span>
        <?php echo $benefactor_name; ?>
      </h2>
    </div>

    <div class="container-fluid">
      <nav>
        <div class="nav nav-tabs fw-bold" id="nav-tab" role="tablist">
          <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home"
            type="button" role="tab" aria-controls="nav-home" aria-selected="true">
            <i class="bi bi-check-circle me-1"></i>COMPLETE REQUIREMENTS
            <span class=" rounded bg-danger text-light px-2 py-1 fw-bold"><small id="complete-count">0</small></span>
          </button>
          <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button"
            role="tab" aria-controls="nav-profile" aria-selected="false">
            <i class="bi bi-list-check me-1"></i>PROCESSED BY ACCOUNTING
            <span class=" rounded bg-danger text-light px-2 py-1 fw-bold"><small id="process-count">0</small></span>
          </button>
          <button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button"
            role="tab" aria-controls="nav-contact" aria-selected="false">
            <i class="bi bi-credit-card me-1"></i>SCHOLARSHIP GRANT CLAIM
            <span class=" rounded bg-danger text-light px-2 py-1 fw-bold"><small id="claim-count">0</small></span>
          </button>
        </div>
      </nav>
      <div class="tab-content" id="nav-tabContent">

        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
          tabindex="0">
          <div class="p-1 rounded-bottom-1 border border-top-0 shadow-sm">
            <div class="table-responsive  px-1 py-2">
              <div class="d-flex justify-content-end mb-1 ">
                <button class="btn btn-save btn-sm me-1 mt-1 mb-2" type="button" data-bs-toggle="modal"
                  data-bs-target="#add-approved"><i class="bi bi-plus-circle me-0 me-sm-1"></i><span
                    class="d-none d-sm-inline">Add</span>
                </button>
                <button class="btn btn-save btn-sm me-1 mt-1 mb-2" type="button" data-bs-toggle="modal"
                  data-bs-target="#import-approved"><i class="bi bi-file-earmark-arrow-down me-0 me-sm-1"></i><span
                    class="d-none d-sm-inline">Import</span>
                </button>
                <button id="toProcess" class="btn btn-sm btn-save me-1 mt-1 mb-2" type="button" data-bs-toggle="modal"
                  data-bs-target="#toProcessModal">Proceed <i class="bi bi-arrow-right-circle ms-1"></i></button>
              </div>
              <table id="approve-table" class="table table-hover">
                <thead class="table-secondary">
                  <tr>
                    <th scope="col"><input type="checkbox" id="selectAllApprove"></th>
                    <th scope="col" nowrap>Student No.</th>
                    <th scope="col">Surname</th>
                    <th scope="col">Firstname</th>
                    <th scope="col">Middlename</th>
                    <th scope="col">Email</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Campus</th>
                    <th scope="col">College</th>
                    <th scope="col">Course</th>
                    <th scope="col">Year</th>
                    <th scope="col">GWA</th>
                    <th scope="col">Units</th>
                  </tr>
                </thead>
                <tbody id="approve-table-body">
                </tbody>
              </table>
            </div>
          </div>
          <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-2">

          </div>


          <!-- Modal Alert for Move to Process -->
          <div class="modal fade" id="toProcessModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Confirmation</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                  <p>Are you sure you want to move all the selected scholars?</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                  <button type="button" class="btn btn-save" id="approveButton"
                    onclick="moveSelectedToProcess('<?php echo $table_name ?>')">OK</button>
                </div>
              </div>
            </div>
          </div>
          <!-- Modal Alert for Move to Process -->

        </div>
        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">
          <div class="p-1 rounded-bottom-1 border border-top-0 shadow-sm">
            <div class="table-responsive  px-1 py-2">
              <div class="d-flex justify-content-end mb-1 ">
                <button id="toClaim" class="btn btn-sm  btn-save me-1 mt-1 mb-2" type="button" data-bs-toggle="modal"
                  data-bs-target="#toClaimModal">Proceed <i class="bi bi-arrow-right-circle ms-1"></i></button>

              </div>
              <table id="processed-table" class="table table-hover">
                <thead class="table-secondary">
                  <tr>
                    <th scope="col"><input type="checkbox" id="selectAllProcess"></th>
                    <th scope="col" nowrap>Student No.</th>
                    <th scope="col">Surname</th>
                    <th scope="col">Firstname</th>
                    <th scope="col">Middlename</th>
                    <th scope="col">Email</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Campus</th>
                    <th scope="col">College</th>
                    <th scope="col">Course</th>
                    <th scope="col">Year</th>
                    <th scope="col">GWA</th>
                    <th scope="col">Units</th>
                  </tr>
                </thead>
                <tbody id="processed-table-body">
                </tbody>
              </table>
            </div>
          </div>
          <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-2">

          </div>

          <!-- Modal Alert for Move to Claim -->
          <div class="modal fade" id="toClaimModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Confirmation</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                  <p>Are you sure you want to move all the selected scholars?</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                  <button type="button" class="btn btn-save" id="approveButton"
                    onclick="moveSelectedToClaim('<?php echo $table_name ?>')">OK</button>
                </div>
              </div>
            </div>
          </div>
          <!-- Modal Alert for Move to Claim -->
        </div>
        <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab" tabindex="0">
          <div class="p-1 rounded-bottom-1 border border-top-0 shadow-sm">
            <div class="table-responsive  px-1 py-2">
              <div class="d-grid gap-2 d-sm-flex justify-content-sm-end mb-2">
                <button id="exportToCSVButton" class="btn btn-tool btn-sm" type="button" style="font-size: 12px;"><i
                    class="bi bi-filetype-xlsx me-1"></i>Export
                  Excel</button>

                <button id="exportToPDFButton" class="btn btn-tool btn-sm" onclick="exportToPDF()"
                  style="font-size: 12px;"><i class="bi bi-file-earmark-pdf me-1"></i>Export PDF</button>
              </div>
              <table id="claim-table" class="table table-hover">
                <thead class="table-secondary">
                  <tr>
                    <th scope="col"><input type="checkbox" id="selectAllClaim"></th>
                    <th scope="col" nowrap>Student No.</th>
                    <th scope="col">Surname</th>
                    <th scope="col">Firstname</th>
                    <th scope="col">Middlename</th>
                    <th scope="col">Email</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Campus</th>
                    <th scope="col">College</th>
                    <th scope="col">Course</th>
                    <th scope="col">Year</th>
                    <th scope="col">GWA</th>
                    <th scope="col">Units</th>
                  </tr>
                </thead>
                <tbody id="claim-table-body">
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>

  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script type="text/javascript" src="../js/bootstrap.js"></script>
  <script defer src="../js/datatable.js"></script>

  <script type="text/javascript" src="../js/sidebar.js"></script>
  <script type="text/javascript" src="../js/admin_approve.js"></script>
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
    crossorigin="anonymous"></script> -->
  <!-- Include jQuery library -->

  <!-- DATA TABLE -->
  <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
  <script type="text/javascript" charset="utf8"
    src="https://cdn.datatables.net/select/1.3.4/js/dataTables.select.min.js"></script> <!-- select extension -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
    crossorigin="anonymous"></script> -->


  <script>
    window.jsPDF = window.jspdf.jsPDF;
    document.addEventListener("DOMContentLoaded", () => {
      actLogs('<?php echo $adminData['first_name'] ?>', '<?php echo $adminData['last_name'] ?>');
      fetchTableCount("<?php echo $table_name; ?>");
      fetchApproveScholars("<?php echo $table_name; ?>");
      fetchProcessedScholars("<?php echo $table_name; ?>");
      fetchClaimScholars("<?php echo $table_name; ?>");



      console.log("<?php echo $particular; ?>");
      var particular = "<?php echo $particular; ?>";
      // console.log("CHECK IF GOVERNMENT: ", particular == "GOVERNMENT" );
    });
  </script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Get the icon element
      var icon = document.getElementById('icon');

      // Add a click event listener
      icon.addEventListener('click', function () {
        // Toggle the class to switch the icon
        icon.classList.toggle('bi-arrow-left');
        icon.classList.toggle('bi-arrow-right');
      });
    });
  </script>

</body>

</html>
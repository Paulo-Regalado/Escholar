<?php
session_start();
include_once 'php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['student_number'], $_SESSION['masterlist_data'])) {
  header("Location: http://escholar.eyjeyesdiar.com/");
  exit(); // Ensure that the script stops execution after the redirect
} else {
  // Security: Regenerate session ID
  session_regenerate_id(true);

  $studentNumber = $_SESSION['student_number'];
  $masterlistData = $_SESSION['masterlist_data'];

  // Security: Use prepared statement to prevent SQL injection
  $query = $conn->prepare("SELECT * FROM monitoring_form WHERE student_number = ?");
  $query->bind_param("s", $studentNumber);
  $query->execute();
  $result = $query->get_result();

  if ($result->num_rows > 0) {
    // User has submitted monitoring form, redirect to dashboard
    header("Location: dashboard.php");
    exit(); // Ensure that no further code is executed after the redirect
  }

  // Security: Close the database connection
  $query->close();
  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>Monitoring Form</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.0/mdb.min.css" rel="stylesheet" />

  <!-- Add the favicon link here -->
  <link rel="icon" type="image/png" href="img/Logo2.png">

  <!-- ICON -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">


  <link href="../css/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" href="../User/css/user.css">


</head>

<body>

  <nav class="navbar bg-body-tertiary sticky-top">
    <div class="container-fluid d-flex justify-content-between">
      <div>
        <a class="navbar-brand d-flex align-items-center" href="#">
          <div class="me-2 h-25 logo">
            <img src="../img/Logo2.png" class="logo" alt="logo">
          </div>
          <h5 class="m-0 fs-6 d-none d-lg-block fw-bold">BULACAN STATE UNIVERSITY<br> Office of the Student Financial
            Assistance and Scholarships</h5>
        </a>
      </div>
      <div class="d-flex align-items-center">
        <div>
          <div class="dropdown">
            <a href="#" role="button" class="dropdown-toggle p-0 text-decoration-none text-black"
              data-bs-toggle="dropdown" aria-expanded="false">
              <img style="width: 50px; height: 50px;"
                class="rounded-circle shadow-sm border border-secondary-subtle me-1" style="height: 45px;"
                src="../Profile_Pictures/<?php echo $masterlistData['student_number'] . '_profile_pic.jpg?' . time(); ?>">
              <span class="ms-1 me-2 d-none d-md-inline">
                <?php echo $masterlistData['last_name'] . ', ' . $masterlistData['first_name'] . ' ' . $masterlistData['middle_name']; ?>
              </span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item text-danger" href="/php/toLogout.php">Logout</a></li>
            </ul>
          </div>

        </div>
      </div>
    </div>
  </nav>


  <div class="banner d-flex justify-content-end align-items-center">
    <img src="img/BSU BANNER.jpg" alt="Banner Image">
    <!-- Your content goes here -->
  </div>

  <section class="container-fluid pb-2">

    <div class="dito-toast">
      <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="success-add-toast" class="toast align-items-center text-bg-success border-0" role="alert"
          aria-live="assertive" aria-atomic="true">
          <div class="d-flex">
            <div class="toast-body">
              Successfully Submitted
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
              aria-label="Close"></button>
          </div>
        </div>
      </div>
    </div>


    <div class="container-md shadow p-3 mb-5 mt-5 bg-body rounded">
      <h2 class=" fw-bolder">SCHOLARSHIP MONITORING FORM</h2>
      <hr class="mb-3">
      <div>
        <div>
          <div class="alert alert-success px-5 mb-4" role="alert">
            <!-- <h4 class="alert-heading display-6">KUYA WIN Scholarship Program Renewal 2nd Semester, Academic Year 2022-2023</h4> -->
            <p>This form will be used for your scholarship program monitoring. Please ensure to answer all the following
              questions and submit all the required forms. Failure to submit the necessary documents on time may result
              in the cancellation of your scholarship. Thank you!</p>
            <hr>
          </div>

          <form id="renewal-form" method="POST" enctype="multipart/form-data" action="toSendRequirement.php" novalidate>
            <div class="row g-2">

              <h4 class="form-title mt-3  border-start border-5 border-success"><span>SCHOLARSHIP REQUIREMENTS</span>
              </h4>
              <div>
                <input type="text" name="student_number" id="student_number" class="form-control"
                  value="<?php echo $studentNumber; ?>" style="display: none;" readonly />
              </div>

              <div class="row">

                <div class="alert alert-danger col-12" role="alert" id="validation-error" style="display: none;">
                  Your error here
                </div>

                <div class="mb-3 col-12">
                  <label for="id_file" class="form-label">School ID (Front & Back PDF only)</label>
                  <input class="form-control" type="file" name="id" id="id" accept=".pdf">
                </div>

                <div class=" col-12 col-md-3">
                  <label for="unit" class="form-label">No. of Unit</label>
                  <input type="number" class="form-control" id="unit" name="unit">
                </div>

                <div class="mb-3 col-12 col-md-9">
                  <label for="cor_file" class="form-label">Certificate Of Registration</label>
                  <input class="form-control" type="file" name="cor" id="cor" accept=".pdf">
                </div>

                <div class=" col-12 col-md-3">
                  <label for="gwa" class="form-label">GWA</label>
                  <input type="number" class="form-control" id="gwa" name="gwa" step="0.01">
                </div>

                <div class="mb-3 col-12 col-md-9">
                  <label for="cog_file" class="form-label">Certificate Of Grades</label>
                  <input class="form-control" type="file" name="cog" id="cog" accept=".pdf">
                </div>
              </div>


              <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-success" onclick="validate()">
                  Continue
                </button>


                <!-- Modal -->
                <div class=" modal fade" id="term" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                  aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered  modal-lg modal-fullscreen-sm-down">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">TERMS AND CONDITION</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="p-1">
                          <h4 class="form-title">TERMS AND CONDITION</h4>
                          <p style="text-align: justify;">
                            By accepting these terms and conditions, all scholars acknowledge that any submission of
                            fraudulent or falsified academic credentials or requirements shall result in the immediate
                            forfeiture of their scholar status. This includes, but is not limited to, degrees,
                            certifications, or any other documentation deemed necessary for eligibility. The institution
                            reserves the right to verify the authenticity of all submitted documents and take
                            appropriate action in case of any misrepresentation or deceit.
                          </p>

                          <div class="form-check">
                            <input type="checkbox" id="agreeCheckbox" class="form-check-input">
                            <label class="form-check-label h6 fw-bold" for="agreeCheckbox">I agree on Terms and
                              Conditions</label>
                          </div>


                        </div>
                        <div class="modal-footer">
                          <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <input type="submit" id="submitButton" class="btn btn-primary" disabled value="Submit">
                          </div>

                          <script>
                            const agreeCheckbox = document.getElementById('agreeCheckbox');
                            const submitButton = document.getElementById('submitButton');

                            agreeCheckbox.addEventListener('change', function () {
                              submitButton.disabled = !this.checked;
                            });
                          </script>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
          </form>
        </div>
      </div>
    </div>
  </section>


  <!-- Include jQuery -->
  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <!-- Popper -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
    crossorigin="anonymous"></script>
  <!-- Bootstrap -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
    integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
    crossorigin="anonymous"></script>

  <script type="text/javascript" src="../js/monitoring_form.js"></script>

  <script>
    function validate() {
      const unit = document.getElementById('unit');
      const gwa = document.getElementById('gwa');
      const cor = document.getElementById('cor');
      const cog = document.getElementById('cog');
      const validationError = document.getElementById('validation-error');

      // if any required field is empty or not a valid number
      if (isNaN(parseFloat(unit.value)) || unit.value.trim() === '' || isNaN(parseFloat(gwa.value)) || gwa.value.trim() === '' || cor.value.trim() === '' || cog.value.trim() === '') {
        validationError.textContent = 'All fields are required.';
        validationError.style.display = 'block';
        return;
      }


      // Check if unit is within a specific range, for example, between 0 and 100
      const unitValue = parseFloat(unit.value);
      if (isNaN(unitValue) || unitValue < 1 || unitValue > 100) {
        validationError.textContent = 'Please enter a valid number for the unit between 1 and 100.';
        validationError.style.display = 'block';
        return;
      }


      // Check if GWA is within a specific range, for example, between 1 and 5
      const gwaValue = parseFloat(gwa.value);
      if (isNaN(gwaValue) || gwaValue < 1 || gwaValue > 5) {
        validationError.textContent = 'Please enter a valid GWA between 1.00 and 5.00';
        validationError.style.display = 'block';
        return;
      }

      const corFileName = cor.value.toLowerCase();
      const cogFileName = cog.value.toLowerCase();

      if (!corFileName.endsWith('.pdf') || !cogFileName.endsWith('.pdf')) {
        validationError.textContent = 'Please upload a PDF file for Certificate Of Registration and Certificate Of Grades.';
        validationError.style.display = 'block';
        return;
      }

      const maxFileSizeInBytes = 5242880; // 5 MB
      if (cor.files[0]?.size > maxFileSizeInBytes || cog.files[0]?.size > maxFileSizeInBytes) {
        validationError.textContent = 'File size should not exceed 5 MB.';
        validationError.style.display = 'block';
        return;
      }


      // If all checks pass, hide the validation error and show the modal
      validationError.style.display = 'none';
      var myModal = new bootstrap.Modal(document.getElementById('term'));
      myModal.toggle();
    }
  </script>
</body>

</html>
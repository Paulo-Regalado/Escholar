<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Graduate Tracer</title>

    <!-- Add the favicon link here -->
    <link rel="icon" type="image/png" href="img/Logo2.png">

    <!-- ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <link rel="stylesheet" href="css/user.css" />
    <link href="../css/bootstrap.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar bg-body-tertiary sticky-top">
        <div class="container-fluid d-flex justify-content-start">
            <div>
                <a class="navbar-brand d-flex align-items-center" href="#">
                    <div class="me-2 h-25 logo">
                        <img src="../img/Logo2.png" class="logo" alt="logo">
                    </div>
                    <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULACAN STATE UNIVERSITY<br> Office of the Student
                        Financial
                        Assistance and Scholarships</h5>
                </a>
            </div>
        </div>
    </nav>

    <div class="banner d-flex justify-content-end align-items-center">
        <img src="img/BSU BANNER.jpg" alt="Banner Image">
        <!-- Your content goes here -->
    </div>

    <section class="container-fluid pb-2">
        <div class="dito-toast">

            <div class="toast-container position-fixed bottom-0 end-0 p-3">
                <div id="success-add-toast" class="toast align-items-center text-bg-success border-0" role="alert"
                    aria-live="assertive" aria-atomic="true">
                    <div class="d-flex">
                        <div class="toast-body">
                            Successfully Submitted
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                            aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-md shadow p-3 mb-5 mt-5 bg-body rounded">
            <h2 class=" fw-bolder">GRADUATE TRACER FORM</h2>
            <hr class="mb-3">
            <div>
                <div>
                    <div class="alert alert-success px-5 mb-4" role="alert">
                        <!-- <h4 class="alert-heading display-6">KUYA WIN Scholarship Program Renewal 2nd Semester, Academic Year 2022-2023</h4> -->
                        <p>This form will be used for your tracking graduates of Bulacan State University. Please ensure
                            to answer all the following questions and submit all the required forms. Thank you!</p>

                    </div>
                    <div class="alert alert-danger col-12" role="alert" id="validation-error" style="display: none;">
                        Your error here
                    </div>

                    <form id="tracer_form" method="post" enctype="multipart/form-data">
                        <h4 class="form-title">PERSONAL INFORMATION</h4>
                        <div class="row g-2">
                            <div class=" col-12 col-md-6">
                                <label for="grad_pic" class="form-label">Graduation Picture (JPEG/PNG format)</label>
                                <input type="file" class="form-control" id="grad_pic" name="grad_pic" required>
                            </div>
                            <div class=" col-12 col-md-6">
                                <label for="student_number" class="form-label">Student Number</label>
                                <input type="number" class="form-control" id="student_number" name="student_number"
                                    required>
                            </div>
                            <div class=" col-12 col-md-6">
                                <label for="full_name" class="form-label">Complete Name (Firstname Middle Initial
                                    Lastname)</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" required>
                            </div>
                            <div class=" col-12 col-md-6">
                                <label for="birthday" class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" id="birthday" name="birthday">
                            </div>
                            <div class=" col-12 col-md-6">
                                <label for="Gender" class="form-label">Gender</label>
                                <select class="form-select" id="gender" name="gender">
                                    <option value="" selected disabled hidden>Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Others">Others</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="civil_status" class="form-label">Civil Status</label>
                                <select class="form-select" id="civil_status" name="civil_status">
                                    <option value="" selected disabled hidden>Select Civil Status</option>
                                    <option value="Single">Single</option>
                                    <option value="Married">Married</option>
                                    <option value="Divorced">Divorced</option>
                                    <option value="Widowed">Widowed</option>
                                </select>
                            </div>

                            <div class=" col-12 col-md-4">
                                <label for="current_address" class="form-label">Current Address of Residence</label>
                                <input type="text" class="form-control" id="current_address" name="current_address"
                                    required>
                            </div>
                            <div class=" col-12 col-md-4">
                                <label for="contact" class="form-label">Active Contact Number</label>
                                <input type="number" class="form-control" id="contact" name="contact" required>
                            </div>
                            <div class=" col-12 col-md-4">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>

                        </div>

                        <h4 class="form-title mt-3">SCHOLARSHIP INFORMATION</h4>

                        <div class="row g-2">
                            <div class=" col-12 col-md-6">
                                <label for="course" class="form-label">Course Completed</label>
                                <input type="text" class="form-control" id="course" name="course" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="year_graduated" class="form-label">Year Graduated</label>
                                <input type="number" class="form-control" id="year_graduated" name="year_graduated"
                                    placeholder="YYYY" min="1900" max="2100" required>
                            </div>
                            <div class=" col-12 col-md-6">
                                <label for="benefactor" class="form-label">Scholar Benefactor</label>
                                <input type="text" class="form-control" id="benefactor" name="benefactor" required>
                            </div>
                            <div class=" col-12 col-md-6">
                                <label for="campus" class="form-label">Campus</label>
                                <select class="form-select" id="campus" name="campus" required>
                                    <option value="" selected disabled hidden>Select Campus</option>
                                    <option value="Bustos Campus">Bustos Campus</option>
                                    <option value="Hagonoy Campus">Hagonoy Campus</option>
                                    <option value="Malolos Campus">Malolos Campus</option>
                                    <option value="Meneses Campus">Meneses Campus</option>
                                    <option value="San Rafael Campus">San Rafael Campus</option>
                                    <option value="Sarmiento Campus">Sarmiento Campus</option>
                                </select>
                            </div>
                        </div>

                        <h4 class="form-title mt-3">CURRENT EMPLOYEMENT INFORMATION</h4>

                        <div class="row g-2">
                            <div class=" col-12 col-md-6">
                                <label for="employment" class="form-label" required>Status of Employment</label>
                                <select class="form-select" id="employment" name="employment"
                                    onchange="selectOrganization()" required>
                                    <option value="" selected disabled hidden>Select Status of Employment</option>
                                    <option value="Employed, Locally">Employed, Locally</option>
                                    <option value="Employed, Abroad">Employed, Abroad</option>
                                    <option value="Self-employed">Self-employed</option>
                                    <option value="Unemployed">Unemployed</option>

                                </select>
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="org_type" class="form-label">Type of Organization (If
                                    Employed)</label>
                                <select class="form-select" id="org_type" name="org_type" disabled required>
                                    <option value="" selected disabled>Select Organization
                                    </option>

                                </select>
                            </div>

                            <div class=" col-12 col-md-6">
                                <label for="company_name" class="form-label" required>Name of Company</label>
                                <input type="text" class="form-control" id="company_name" name="company_name">
                            </div>
                            <div class=" col-12 col-md-6">
                                <label for="company_address" class="form-label" required>Address of Company</label>
                                <input type="text" class="form-control" id="company_address" name="company_address">
                            </div>
                            <div class=" col-12 col-md-6">
                                <label for="position" class="form-label" required>Current Work Position</label>
                                <input type="text" class="form-control" id="position" name="position">
                            </div>
                            <div class=" col-12 col-md-6">
                                <label for="year_in_company" class="form-label" required>Number of Years in the
                                    Company</label>
                                <input type="number" class="form-control" id="year_in_company" name="year_in_company">
                            </div>
                            <div class=" col-12">
                                <label for="reasons" class="form-label">Reason(s) for Unemployment (if not
                                    employed)</label>
                                <input type="text" class="form-control" id="reasons" name="reasons" disabled required>
                            </div>
                        </div>


                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <!-- <a href="dashboard.php"> -->
                            <button class="btn btn-secondary" type="button"
                                onclick="redirectToDashboard()">Cancel</button>
                            <!-- </a> -->

                            <button class="btn btn-success" type="button" id="saveButton">Save</button>

                            <!-- Modal -->
                            <div class="modal fade" id="term" tabindex="-1" data-bs-backdrop="static"
                                data-bs-keyboard="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered  modal-lg modal-fullscreen-sm-down">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">TERMS AND CONDITION</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="p-1">

                                                <p style="text-align: justify;">
                                                    This survey form is intended exclusively for Scholar graduates
                                                    of
                                                    Bulacan State University.
                                                    Data gathered from this form
                                                    will be treated with the utmost confidentiality in accordance
                                                    with
                                                    Republic Act 10173, also known as the Data Privacy Act of 2012.
                                                    <br><br>This Scholar Graduate Tracer form require you
                                                    to provide
                                                    some
                                                    personal information.Clicking on the "I Agree" button indicates
                                                    that you have read the above information, and you voluntarily
                                                    agree
                                                    to respond.

                                                </p>

                                                <div class="form-check">
                                                    <input type="checkbox" id="agreeCheckbox" class="form-check-input">
                                                    <label class="form-check-label h6 fw-bold" for="agreeCheckbox">I
                                                        agree on Terms and
                                                        Conditions</label>
                                                </div>


                                            </div>
                                            <div class="modal-footer">
                                                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                                                    <input type="submit" id="submitButton" class="btn btn-primary"
                                                        disabled value="Submit">
                                                </div>

                                                <script>
                                                    const agreeCheckbox = document.getElementById('agreeCheckbox');
                                                    const submitButton = document.getElementById('submitButton');

                                                    agreeCheckbox.addEventListener('change', function () {
                                                        submitButton.disabled = !this.checked;
                                                    });
                                                </script>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </section>


    <script>
        function redirectToDashboard() {
            window.location.href = 'dashboard.php';
        }
    </script>

    <script type="text/javascript" src="../js/bootstrap.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="../js/graduate_tracer.js"></script>
</body>



</html>
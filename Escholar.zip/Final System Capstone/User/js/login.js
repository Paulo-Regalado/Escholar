function login() {
    var studentNumber = document.getElementById('student-number').value;
    var password = document.getElementById('password').value;
    const login_form = document.getElementById('login-form');

    // Validate student number length
    if (studentNumber.length !== 10) {
        const message = '<div class="alert alert-danger" role="alert"><i class="bi bi-exclamation-circle me-1"></i>Please enter a correct account or student number.</div>';
        document.getElementById('alert').innerHTML = message;
        login_form.reset();
    } else {
        // Show spinner and disable the button
        document.getElementById('spinner').style.display = 'inline-block';
        document.getElementById('status').style.display = 'inline-block';
        document.getElementById('loginButton').disabled = true;

        let formData = new FormData();
        formData.append('student_number', studentNumber);
        formData.append('password', password);

        fetch('../User/php/toLogin.php', {
            method: 'POST',
            body: formData
        })
            .then(response => {
                console.log(response);
                if (!response.ok) {

                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log(data);
                // Hide spinner and enable the button
                document.getElementById('spinner').style.display = 'none';
                document.getElementById('status').style.display = 'none';
                document.getElementById('loginButton').disabled = false;

                if (!data.success) {
                    const message = '<div class="alert alert-danger" role="alert"><i class="bi bi-exclamation-circle me-1"></i>' + data.message + '</div>';
                    document.getElementById('alert').innerHTML = message;
                    login_form.reset();
                } else {
                    login_form.reset();
                    window.location.href = data.redirect;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                const message = '<div class="alert alert-danger" role="alert"><i class="bi bi-exclamation-circle me-1"></i>An error has occurred</div>';
                document.getElementById('alert').innerHTML = message;
                // Hide spinner and enable the button in case of an error
                document.getElementById('spinner').style.display = 'none';
                document.getElementById('status').style.display = 'none';
                document.getElementById('loginButton').disabled = false;
                login_form.reset();
            });
    }
}

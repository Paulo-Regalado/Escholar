document.addEventListener('DOMContentLoaded', function () {
  fetchAnnouncement();
});


function fetchStatus(student_number) {
  const statusContainer = document.getElementById("status");
  var studentNumber = student_number;

  console.log(studentNumber);

  let formData = new FormData();
  formData.append('student_number', studentNumber);

  fetch('php/toFetchStatus.php', {
    method: 'POST',
    body: formData
  })
    .then(response => {
      return response.json();
    })
    .then(data => {
      console.log(data);

      // Loop through the data and create HTML based on the status
      data.forEach(item => {
        let statusHTML = '';
        switch (item.status) {
          case 'pending':
            statusHTML = getPendingHTML(item.table_name);
            break;
          case 'approved':
            statusHTML = getApprovedHTML(item.table_name);
            break;
          case 'processed':
            statusHTML = getProcessedHTML(item.table_name);
            break;
          case 'claim':
            statusHTML = getClaimHTML(item.table_name);
            break;
          // Add more cases if needed
          default:
            // Handle other statuses or errors
            break;
        }

        // Append the created HTML to the status container
        statusContainer.innerHTML += statusHTML;
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
      });
    })
    .catch(error => {
      console.error('Error:', error);
    });
}

// Helper functions to generate HTML for different statuses
function getPendingHTML(tableName) {
  // Extract the part of the table name before the last underscore
  const lastUnderscoreIndex = tableName.lastIndexOf('_');
  const displayName = lastUnderscoreIndex !== -1 ? tableName.substring(0, lastUnderscoreIndex) : tableName;

  // Replace remaining underscores with spaces
  const formattedName = displayName.replace(/_/g, ' ');

  return `
    <div class=" rounded border shadow mt-3">
        <div class="">
          <div class="bg-status border-bottom">
            <div class="px-3 py-1">
            <h5 class='text-white m-0'><i class="bi bi-info-circle-fill me-2"></i>${formattedName}</h5>
            </div>
          </div>
          <div>
            <div class="hh-grayBox pt45 pb20 m-auto" >
              <div class=" d-flex justify-content-between">
                <div class="order-tracking completed" >
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="You have submitted your forms successfully."
                  ></span>
                  <p>Submission of Forms</p>
                </div>
                <div class="order-tracking">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your forms have been approved."
                  ></span>
                  <p>Approved Forms</p>
                </div>
                <div class="order-tracking ">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your scholarship is being processed by the accounting department."
                  ></span>
                  <p>Processed by Accounting Office</p>
                </div>
                <div class="order-tracking ">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your scholarship grant is ready for claim. Please wait for the scheduled payout date.                  "
                  ></span>
                  <p>Payout is in process</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
}

function getApprovedHTML(tableName) {
  // Extract the part of the table name before the last underscore
  const lastUnderscoreIndex = tableName.lastIndexOf('_');
  const displayName = lastUnderscoreIndex !== -1 ? tableName.substring(0, lastUnderscoreIndex) : tableName;

  // Replace remaining underscores with spaces
  const formattedName = displayName.replace(/_/g, ' ');

  return `
    <div class=" rounded border shadow mt-3">
        <div class="">
        <div class="bg-status border-bottom">
        <div class="px-3 py-2">
        <h5 class='text-white m-0'><i class="bi bi-info-circle-fill me-2"></i>${formattedName}</h5>
            </div>
          </div>
          <div>
            <div class="hh-grayBox pt45 pb20 m-auto">
                <div class=" d-flex justify-content-between">
                <div class="order-tracking completed" >
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="You have submitted your forms successfully."
                  ></span>
                  <p>Submission of Forms</p>
                </div>
                <div class="order-tracking completed">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your forms have been approved."
                  ></span>
                  <p>Approved Forms</p>
                </div>
                <div class="order-tracking ">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your scholarship is being processed by the accounting department."
                  ></span>
                  <p>Processed by Accounting Office</p>
                </div>
                <div class="order-tracking ">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your scholarship grant is ready for claim. Please wait for the scheduled payout date.                  "
                  ></span>
                  <p>Payout is in process</p>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    `;
}

function getProcessedHTML(tableName) {
  // Extract the part of the table name before the last underscore
  const lastUnderscoreIndex = tableName.lastIndexOf('_');
  const displayName = lastUnderscoreIndex !== -1 ? tableName.substring(0, lastUnderscoreIndex) : tableName;

  // Replace remaining underscores with spaces
  const formattedName = displayName.replace(/_/g, ' ');

  return `
    <div class=" rounded border shadow mt-3">
        <div class="">
          <div class="bg-status border-bottom">
            <div class="px-3 py-2">
            <h5 class='text-white m-0'><i class="bi bi-info-circle-fill me-2"></i>${formattedName}</h5>
            </div>
          </div>
          <div>
            <div class="hh-grayBox pt45 pb20 m-auto">

              <div class=" d-flex justify-content-between">
                <div class="order-tracking completed" >
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="You have submitted your forms successfully."
                  ></span>
                  <p>Submission of Forms</p>
                </div>
                <div class="order-tracking completed">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your forms have been approved."
                  ></span>
                  <p>Approved Forms</p>
                </div>
                <div class="order-tracking completed">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your scholarship is being processed by the accounting department."
                  ></span>
                  <p>Processed by Accounting Office</p>
                </div>
                <div class="order-tracking ">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your scholarship grant is ready for claim. Please wait for the scheduled payout date.                  "
                  ></span>
                  <p>Payout is in process</p>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    `;
}

function getClaimHTML(tableName) {
  // Extract the part of the table name before the last underscore
  const lastUnderscoreIndex = tableName.lastIndexOf('_');
  const displayName = lastUnderscoreIndex !== -1 ? tableName.substring(0, lastUnderscoreIndex) : tableName;

  // Replace remaining underscores with spaces
  const formattedName = displayName.replace(/_/g, ' ');

  return `
        <div class=" rounded border shadow mt-3">
        <div class="">
          <div class="bg-status border-bottom">
            <div class="px-3 py-2">
            <h5 class='text-white m-0'><i class="bi bi-info-circle-fill me-2"></i>${formattedName}</h5>
            </div>
          </div>
          <div>
            <div class="hh-grayBox pt45 pb20 m-auto">

              <div class=" d-flex justify-content-between">
                <div class="order-tracking completed" >
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="You have submitted your forms successfully."
                  ></span>
                  <p>Submission of Forms</p>
                </div>
                <div class="order-tracking completed">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your forms have been approved."
                  ></span>
                  <p>Approved Forms</p>
                </div>
                <div class="order-tracking completed">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your scholarship is being processed by the accounting department."
                  ></span>
                  <p>Processed by Accounting Office</p>
                </div>
                <div class="order-tracking completed">
                  <span class="is-complete"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  data-bs-custom-class="custom-tooltip"
                  data-bs-title="Your scholarship grant is ready for claim. Please wait for the scheduled payout date.                  "
                  ></span>
                  <p>Payout is in process</p>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    `;
}




function fetchAnnouncement() {

  const content = document.getElementById("announcement-tab");

  // Function to format a timestamp
  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString(undefined, options);
  };


  const displayData = (data) => {
    content.innerHTML = ""; // Clear previous data

    data.forEach((row) => {
      content.innerHTML += `
      <a href="announcement.php?id=${row.id}" class="text-decoration-none">
        <div class="announcement-container d-flex align-items-center my-3 shadow" type="button">
          <div class="front">
            <div class="announcement-title text-black m-0">${row.title}</div>
            <div class="date-posted">DATE POSTED: ${formatTimestamp(row.date_created)}</div>
          </div>
          <i class="bi bi-megaphone announcement-icon"></i>
        </div>
        </a>
      `;
    });
  };


  // Function to handle errors
  const handleError = (error) => {
    console.error("Error:", error);
    content.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
  };

  fetch("././../php/getAnnouncement.php", {
    method: 'POST',
  })
    .then((response) => {
      if (!response.ok) {
        console.log("Response status:", response.status); // Log response status
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then((data) => {
      console.log("Received data:", data); // Log received data

      if (Array.isArray(data.data)) {
        const reversedData = data.data.reverse(); // Reverse the order of the array
        displayData(reversedData); // Pass the reversed array to displayData
      } else {
        // Handle the case where data is not an array
        handleError("Data is not an array");
      }
    })

    .catch((error) => {
      console.error("Fetch error:", error); // Log fetch error
      handleError(error);
    });
}
<?php
session_start();
include_once 'php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['student_number'], $_SESSION['masterlist_data'])) {
    header("Location: http://escholar.eyjeyesdiar.com/");
    exit(); // Ensure that the script stops execution after the redirect
} else {
    // Security: Regenerate session ID
    session_regenerate_id(true);

    $masterlistData = $_SESSION['masterlist_data'];
    // Security: Use prepared statement to prevent SQL injection
    $studentNumber = $_SESSION['student_number'];
    $query = $conn->prepare("SELECT * FROM monitoring_form WHERE student_number = ?");
    $query->bind_param("s", $studentNumber);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows == 0) {
        // Student number does not exist in the monitoring_form table
        // Redirect to monitoring_form.php
        header("Location: monitoring_form.php");
        exit(); // Ensure that no further code is executed after the redirect
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>

    <link rel="icon" type="image/png" href="img/Logo2.png">

    <!-- ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <link rel="stylesheet" href="css/user.css" />
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/custom.css" rel="stylesheet">

    <style>
        .nav-link {
            color: #008000;
        }

        .nav-link:hover,
        .nav-link:focus {
            color: #008000;
        }
    </style>

</head>

<body>
    <nav class="navbar bg-body-tertiary sticky-top">
        <div class="container-fluid d-flex justify-content-between">
            <div>
                <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                    <div class="me-2 h-25 logo">
                        <img src="../img/Logo2.png" class="logo" alt="logo">
                    </div>
                    <h5 class="m-0 fs-6 d-none d-lg-block fw-bold">BULACAN STATE UNIVERSITY<br> Office of the Student
                        Financial
                        Assistance and Scholarships</h5>
                </a>
            </div>
            <div class="d-flex align-items-center">
                <div>
                    <div class="dropdown">
                        <a href="#" role="button" class="dropdown-toggle p-0 text-decoration-none text-black" data-bs-toggle="dropdown" aria-expanded="false">
                            <img style="width: 50px; height: 50px;" class="rounded-circle shadow-sm border border-secondary-subtle me-1" style="height: 45px;" src="../Profile_Pictures/<?php echo $masterlistData['student_number'] . '_profile_pic.jpg?' . time(); ?>">
                            <span class="ms-1 me-2 d-none d-md-inline">
                                <?php echo $masterlistData['last_name'] . ', ' . $masterlistData['first_name'] . ' ' . $masterlistData['middle_name']; ?>
                            </span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="settings.php">Setting</a></li>
                            <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </nav>


    <div class="banner d-flex justify-content-end align-items-center">
        <img src="img/BSU BANNER.jpg" alt="Banner Image">
        <!-- Your content goes here -->
    </div>

    <div>
        <div class="dito-toast">
            <div class="toast-container position-fixed bottom-0 end-0 p-3">
                <div id="success-add-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="d-flex">
                        <div class="toast-body">
                            Updated Successfully
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
        <div style="margin-top: 50px;" class="container">
            <h3 class="border-start border-4 border-success ps-1">Settings</h3>
            <div class="text-success">
                <ul class="nav nav-underline mb-3 " id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Change Avatar</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Change Password</button>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                        <div class="p-3">
                            <form action="../php/toChangeAvatar.php" method="post" enctype="multipart/form-data">
                                <div class="d-flex align-items-center">
                                    <img style="height: 140px;" src="../Profile_Pictures/<?php echo $masterlistData['student_number'] . '_profile_pic.jpg?' . time(); ?>" class="rounded-0 border border-2 border-black" alt="...">
                                    <input type="hidden" name="student_number" id="password_form_student_number" value="<?php echo $studentNumber; ?>" readonly>
                                    <div class="ms-3">
                                        <input class="form-control" type="file" id="formFile" name="avatar" accept=".jpg" required>
                                    </div>
                                </div>
                                <div class="d-grid gap-2 d-md-flex justify-content-md-start mt-3">
                                    <button type="button" class="btn btn-secondary" onclick="redirectToDashboard()">Cancel</button>
                                    <button type="submit" class="btn btn-save">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                        <div class="alert alert-danger col-12" role="alert" id="password-error" style="display: none;">
                            Your error here
                        </div>
                        <form id="passwordForm" action="../php/toChangePass.php" method="post" onsubmit="validateForm(event)">

                            <div class="">
                                <div style="max-width: 500px;" class="text-black">
                                    <input type="hidden" name="student_number" id="password_form_student_number" value="<?php echo $studentNumber; ?>" readonly>
                                    <div class="mb-2">
                                        <label for="current-password" class="form-label">Current Password</label>
                                        <input type="password" class="form-control" id="current-password" name="current-pass" required>
                                    </div>
                                    <div class="mb-2">
                                        <label for="new-pass" class="form-label">New Password</label>
                                        <input type="password" class="form-control" id="new-pass" name="new-pass" required>
                                    </div>
                                    <div class="mb-2">
                                        <label for="re-pass" class="form-label">Re-type Password</label>
                                        <input type="password" class="form-control" id="re-pass" required>
                                    </div>
                                </div>
                                <div class=" d-grid gap-2 d-md-flex justify-content-md-start mt-3">
                                    <button type="button" class="btn btn-secondary" onclick=" checkCurrentPassword('<?php echo $studentNumber; ?>', 'user')">Cancel</button>
                                    <button type="submit" class="btn btn-save">Change Password</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="footer text-white">
        <div>
            <div class="m-auto">
                <h5>CONTACT US</h5>
            </div>
        </div>
        <div class="container ">
            <div class="row justify-content-center">
                <div class="col-sm-12 col-md-4 text-center ">
                    <i style="color: #008000" class="bi bi-geo-alt me-1"></i>McArthur Highway, Malolos, Philippines
                </div>
                <div class="col-sm-12 col-md-4 text-center ">
                    <i style="color: #008000" class="bi bi-telephone me-1"></i>(044) 790 6520
                </div>
                <div class="col-sm-12 col-md-4 text-center ">
                    <i style="color: #008000" class="bi bi-envelope me-1"></i>scholarship@bulsu.edu.ph
                </div>
            </div>
        </div>


    </div>

    <!-- <script type="text/javascript" src="../js/bootstrap.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <script>
        function redirectToDashboard() {
            window.location.href = 'dashboard.php';
        }

        function validatePasswordComplexity(password) {
            // Check if password contains at least one capital letter and one symbol
            return /[A-Z]/.test(password) && /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(password);
        }

        function validatePass() {
            const validationError = document.getElementById("password-error");
            const pass = document.getElementById("new-pass");

            if (pass.value.length < 8) {
                validationError.textContent = 'Password must be a minimum of 8 characters and include at least one capital letter and one symbol.';
                validationError.style.display = 'block';
                return false; // Prevent form submission
            } else {
                return true;
            }
        }

        function validateSamePass() {
            const validationError = document.getElementById("password-error");
            const pass = document.getElementById("new-pass");
            const rePass = document.getElementById("re-pass");

            if (pass.value === rePass.value) {
                return true; // Prevent form submission
            } else {
                validationError.textContent = 'Passwords do not match.';
                validationError.style.display = 'block';
                return false; // Prevent form submission
            }
        }

        async function checkCurrentPassword() {
            const validationError = document.getElementById("password-error");
            const currentPass = document.getElementById("current-password").value;
            const studentNumber = document.getElementById("password_form_student_number").value;

            var formData = new FormData();
            formData.append('student-number', studentNumber);
            formData.append('type', 'user');
            formData.append('current-password', currentPass);

            try {
                const response = await fetch('php/toValidateCurrentPassword.php', {
                    method: 'POST',
                    body: formData
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok. Status: ' + response.status);
                }

                const data = await response.json();

                if (data && data.hasOwnProperty('valid')) {
                    if (data.valid) {
                        // Password is valid, allow form submission
                        return true;
                    } else {
                        validationError.textContent = 'The Current password is incorrect.';
                        validationError.style.display = 'block';
                        // Password is invalid, prevent form submission
                        return false;
                    }
                } else {
                    console.error('Unexpected response format:', data);
                    // Unexpected response format, prevent form submission
                    return false;
                }
            } catch (error) {
                console.error('Error validating current password:', error.message);
                // Error in validation, prevent form submission
                return false;
            }
        }

        async function validateForm(event) {
            // Prevent the default form submission behavior
            event.preventDefault();

            const validationError = document.getElementById("password-error");
            const isSamePass = validateSamePass();
            const isPassValid = validatePass();
            const isCurrentPassValid = await checkCurrentPassword();

            if (isSamePass && isPassValid && isCurrentPassValid) {
                // All validations passed, allow form submission
                document.getElementById("passwordForm").submit();
            }
        }
    </script>




</body>

</html>
<?php
session_start();
include_once 'php/config.php';
$conn = OpenCon();

// Security: Check if the user is already logged in
if (!isset($_SESSION['student_number'], $_SESSION['masterlist_data'])) {
    header("Location: http://escholar.eyjeyesdiar.com/");
    exit(); // Ensure that the script stops execution after the redirect
} else {
    // Security: Regenerate session ID
    session_regenerate_id(true);

    $masterlistData = $_SESSION['masterlist_data'];
    // Security: Use prepared statement to prevent SQL injection
    $studentNumber = $_SESSION['student_number'];
    $query = $conn->prepare("SELECT * FROM monitoring_form WHERE student_number = ?");
    $query->bind_param("s", $studentNumber);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows == 0) {
        // Student number does not exist in the monitoring_form table
        // Redirect to monitoring_form.php
        header("Location: monitoring_form.php");
        exit(); // Ensure that no further code is executed after the redirect
    }

    if (isset($_GET['id'])) {
        // Sanitize the input to prevent potential security issues
        $id = htmlspecialchars($_GET['id']);
    } else {
        header("Location: dashboard.php");
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>


    <!-- Add the favicon link here -->
    <link rel="icon" type="image/png" href="img/Logo2.png">

    <!-- ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <link rel="stylesheet" href="css/user.css" />
    <link href="../css/bootstrap.css" rel="stylesheet">



    <!-- FULL CALENDAR -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.9/index.global.min.js"></script>

</head>

<body>
    <nav class="navbar bg-body-tertiary sticky-top">
        <div class="container-fluid d-flex justify-content-between">
            <div>
                <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                    <div class="me-2 h-25 logo">
                        <img src="../img/Logo2.png" class="logo" alt="logo">
                    </div>
                    <h5 class="m-0 fs-6 d-none d-lg-block fw-bold">BULACAN STATE UNIVERSITY<br> Office of the Student Financial
                        Assistance and Scholarships</h5>
                </a>
            </div>
            <div class="d-flex align-items-center">
                <div>
                    <div class="dropdown">
                        <a href="#" role="button" class="dropdown-toggle p-0 text-decoration-none text-black" data-bs-toggle="dropdown" aria-expanded="false">
                            <img style="width: 50px; height: 50px;" class="rounded-circle shadow-sm border border-secondary-subtle me-1" style="height: 45px;" src="../Profile_Pictures/<?php echo $masterlistData['student_number'] . '_profile_pic.jpg?' . time(); ?>">
                            <span class="ms-1 me-2 d-none d-md-inline">
                                <?php echo $masterlistData['last_name'] . ', ' . $masterlistData['first_name'] . ' ' . $masterlistData['middle_name']; ?>
                            </span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="settings.php">Setting</a></li>
                            <li><a class="dropdown-item text-danger" href="../php/toLogout.php">Logout</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </nav>

    <div class="banner d-flex justify-content-end align-items-center">
        <img src="img/BSU BANNER.jpg" alt="Banner Image">
        <!-- Your content goes here -->
    </div>

    <div style="margin-bottom: 100px;" class="container-fluid p-4">
        <div class="p-2 p-md-0">
            <div class="row">
                <div class="col-12 col-lg-8 mb-4">
                    <?php
                    // Prepare and execute SQL query
                    $sql = "SELECT * FROM announcement WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    // Check if the announcement with the given ID exists
                    if ($result->num_rows > 0) {
                        // Fetch data
                        $row = $result->fetch_assoc();

                        $formattedDate = date("F j, Y", strtotime($row['date_created']));

                        echo '<h3 style="color: #008000;" class="">'. $row['title'] .'</h3>';
                        echo '<h6 class="">Posted '.$formattedDate.'</h6><hr>';
                        echo '<p>'.$row['description'].'</p><br>';
                        if ($row['url'] !== null && $row['url'] !== '') {
                            echo '<a href="'.$row['url'].'">'.$row['url'].'</a><br>';
                        }
                        if ($row['file_name'] !== null && $row['file_name'] !== '') {
                            echo '<img class="w-100" style="max-width: 600px" src="./../Announcement_Files/' . $row['file_name'] . '"><br>';
                        }

                        if (!empty($row['supporting_name'])) {
                            echo '<br><a href="./../Announcement_Files/' . $row['supporting_name'] . '" download>' . $row['supporting_name'] . '</a>';
                        }


                    } else {
                        header("Location: dashboard.php");
                    }

                    // Close the prepared statement and result set
                    $stmt->close();
                    $result->close();
                    ?>

                </div>

                <div class="col-12 col-lg-4">
                    <div>
                        <h3 style="color: #008000;" class="ps-2 m-0">Other Announcement</h3>
                    </div>
                    <div id="announcement-tab">
                    </div>
                </div>

            </div>

        </div>
    </div>

    </div>

    <div class="footer text-white">
        <div>
            <div class="m-auto">
                <h5>CONTACT US</h5>
            </div>
        </div>
        <div class="container ">
            <div class="row justify-content-center">
                <div class="col-sm-12 col-md-4 text-center ">
                    <i style="color: #008000" class="bi bi-geo-alt me-1"></i>McArthur Highway, Malolos, Philippines
                </div>
                <div class="col-sm-12 col-md-4 text-center ">
                    <i style="color: #008000" class="bi bi-telephone me-1"></i>(044) 790 6520
                </div>
                <div class="col-sm-12 col-md-4 text-center ">
                    <i style="color: #008000" class="bi bi-envelope me-1"></i>scholarship@bulsu.edu.ph
                </div>
            </div>
        </div>


    </div>

    <!-- <script type="text/javascript" src="../js/bootstrap.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <script type="text/javascript" src="js/dashboard.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {

            // Call the fetchStatus function when the document is fully loaded
            fetchStatus('<?php echo $studentNumber; ?>');
            fetchAnnouncement();
        });
    </script>


</body>

</html>
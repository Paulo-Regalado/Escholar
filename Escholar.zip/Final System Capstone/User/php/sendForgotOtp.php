<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../../phpmailer/src/Exception.php';
require '../../phpmailer/src/PHPMailer.php';
require '../../phpmailer/src/SMTP.php';

if (isset($_POST['email']) && isset($_POST['otp'])) {
    $email = $_POST['email'];
    $otp = $_POST['otp'];

    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'ofsasscholarshiptracker@gmail.com';
    $mail->Password = 'cnzzoctusxpxlgpa';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('ofsasscholarshiptracker@gmail.com');

    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = 'Scholar Forgot Password';
    $mail->Body = '<h4>Hello,<br>
        To authenticate your change password to the scholar portal, kindly use the provided One Time Password (OTP): <b>' . $otp . '</b>
        <br>Please refrain from sharing this OTP with anyone. If you have any questions or require assistance, please feel free to visit the Scholarship Office.
        <br><br>Please be guided. Thank you!
        </h4>';

    if ($mail->send()) {
        echo '<script>alert("Sent Successful");</script>';
    } else {
        echo '<script>alert("Sending failed: ' . $mail->ErrorInfo . '");</script>';
    }
}
?>
<?php
// Include your database connection code here
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the student number from the AJAX request
    $studentNumber = $_POST['student_number'];

    // Query the 'benefactor' table to get all table names
    $query = "SELECT table_name FROM benefactor";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $responses = [];

        // Loop through each result
        while ($row = mysqli_fetch_assoc($result)) {
            $tableName = $row['table_name'];

            // Use the table name to query the corresponding table for the status
            $statusQuery = "SELECT status FROM $tableName WHERE student_number = $studentNumber";
            $statusResult = mysqli_query($conn, $statusQuery);

            $statusQuery = "SELECT status FROM $tableName WHERE student_number = ?";
            $statusStatement = $conn->prepare($statusQuery);
            $statusStatement->bind_param("i", $studentNumber); // "i" indicates integer type
            $statusStatement->execute();
            $statusResult = $statusStatement->get_result();


            if ($statusResult) {
                $statusRow = mysqli_fetch_assoc($statusResult);

                if ($statusRow) {
                    // Get the status
                    $status = $statusRow['status'];

                    // Add the result to the responses array
                    $responses[] = ['table_name' => $tableName, 'status' => $status];
                } else {
                    $responses[] = ['error' => 'Status not found'];
                }
            } else {
                $responses[] = ['error' => 'Status query failed'];
            }
        }

        // Return the responses in JSON format
        echo json_encode($responses);
    } else {
        echo json_encode(['error' => 'Table name query failed']);
    }
} else {
    echo json_encode(['error' => 'Invalid request method']);
}
?>
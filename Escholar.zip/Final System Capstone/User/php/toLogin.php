<?php

include_once 'config.php';
// Create a connection to the database
$conn = OpenCon();

// Set the content type to JSON before any output
header('Content-Type: application/json');

// Get user input
$studentNumber = $_POST['student_number'] ?? null;
$password = $_POST['password'] ?? null;

// Validate input
if (empty($studentNumber) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

// Check if the connection is successful
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

// Security: Use prepared statement to prevent SQL injection

// Check in admin_account table
$sqlAdmin = "SELECT * FROM admin_account WHERE account_number = ?";
$stmtAdmin = $conn->prepare($sqlAdmin);

$stmtAdmin->bind_param("s", $studentNumber);
$stmtAdmin->execute();
$resultAdmin = $stmtAdmin->get_result();

if ($resultAdmin->num_rows > 0) {
    // Admin account found, verify the password
    $adminData = $resultAdmin->fetch_assoc();
    if (password_verify($password, $adminData['password_hash'])) {
        // Admin authenticated, start a session
        session_start();

        // Start a new session and store data
        $_SESSION['account_number'] = $adminData['account_number'];
        $_SESSION['last_name'] = $adminData['last_name'];
        $_SESSION['first_name'] = $adminData['first_name'];
        $_SESSION['middle_name'] = $adminData['middle_name'];
        $_SESSION['isAdmin'] = true;

        echo json_encode(['success' => true, 'message' => 'Admin Logged in', 'redirect' => '/Admin/dashboard.php']);
        exit();
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid account number or password']);
        exit();
    }
} else {
    // No match in admin_account table, check in user_account table
    $sqlUser = "SELECT * FROM user_account WHERE student_number = ?";
    $stmtUser = $conn->prepare($sqlUser);

    $stmtUser->bind_param("s", $studentNumber);
    $stmtUser->execute();
    $resultUser = $stmtUser->get_result();



    if ($resultUser->num_rows > 0) {

        // User account found, verify the password
        $userData = $resultUser->fetch_assoc();
        $hashedPassword = $userData['password'];

        if (password_verify($password, $hashedPassword)) {
            // User authenticated, start a session
            session_start();


            $_SESSION['student_number'] = $studentNumber;
            $_SESSION['isAdmin'] = false;

            $masterlistQuery = "SELECT * FROM masterlist WHERE student_number = ?";
            $masterlistStmt = $conn->prepare($masterlistQuery);
            $masterlistStmt->bind_param("s", $studentNumber); // Use "s" for string
            $masterlistStmt->execute();
            $masterlistResult = $masterlistStmt->get_result();

            if ($masterlistResult->num_rows > 0) {
                // Fetch the data and store it in the session
                $masterlistData = $masterlistResult->fetch_assoc();
                $_SESSION['masterlist_data'] = $masterlistData;
                // Close the $masterlistResult object
                $masterlistResult->close();

                echo json_encode(['success' => true, 'message' => 'User Logged in', 'redirect' => 'User/dashboard.php']);
                exit();
            } else {
                // No data found in masterlist for the given student number
                echo json_encode(['success' => false, 'message' => 'No information found for the given student number']);
                exit();
            }

        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid student number or password']);
            exit();
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'No Account Found']);

    }
}

$resultAdmin->close();
$resultUser->close();
$conn->close();
?>
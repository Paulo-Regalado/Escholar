<?php
// Include your database connection file
include_once 'config.php';

// Open the database connection
$conn = OpenCon();

// Check for database connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Ensure this file is accessed through a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get posted data
    $studentNumber = $_POST['student-number'];
    $type = $_POST['type'];
    $currentPassword = $_POST['current-password'];

    // Choose the appropriate table and column based on the type
    $tableName = ($type === 'admin') ? 'admin_account' : 'user_account';
    $passwordColumn = ($type === 'admin') ? 'password_hash' : 'password';
    $whereClause = ($type === 'admin') ? 'account_number' : 'student_number';

    // Fetch the actual password from the database
    $query = "SELECT $passwordColumn FROM $tableName WHERE $whereClause = ?";

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param('s', $studentNumber);
    $stmt->execute();
    if ($stmt->error) {
        die("Execute failed: " . $stmt->error);
    }

    $stmt->bind_result($dbPassword);
    $stmt->fetch();
    $stmt->close();

    // Check if the provided current password matches the one in the database
    $isValid = password_verify($currentPassword, $dbPassword);

    // Return a JSON response
    echo json_encode(['valid' => $isValid]);
}

// Close the database connection
CloseCon($conn);
?>

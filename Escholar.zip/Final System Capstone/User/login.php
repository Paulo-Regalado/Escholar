<?php
// Start the session
session_start();

// Check if the user is already logged in

if (isset($_SESSION['account_number'])) {
    // Regenerate session ID to prevent session fixation attacks
    session_regenerate_id(true);

    // Redirect to the dashboard using an absolute URL
    header("Location: ../Admin/dashboard.php");
    exit();
}

if (isset($_SESSION['student_number'])) {
    // Regenerate session ID to prevent session fixation attacks
    session_regenerate_id(true);

    // Redirect to the dashboard using an absolute URL
    header("Location: User/dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!-- Add the favicon link here -->
    <link rel="icon" type="image/png" href="User/img/Logo2.png">

    <!-- ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <link rel="stylesheet" href="/User/css/user.css" />
    <link href="css/bootstrap.css" rel="stylesheet">
    <style>
        .login {
            min-height: 100vh;
        }

        .bg-image {
            background-image: url('./User/img/Login_Bg.jpg');
            background-size: cover;
            background-position: center;
        }

        .login-heading {
            font-weight: 300;
        }

        .btn-login {
            font-size: 0.9rem;
            letter-spacing: 0.05rem;
            padding: 0.75rem 1rem;

        }
    </style>

</head>

<body>
    <div>
        <div class="container-fluid ps-md-0">
            <div class="row g-0">
                <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
                <div class="col-md-8 col-lg-6">
                    <div class="login d-flex align-items-center py-5">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-9 col-lg-8 mx-auto">
                                    <div class="text-center">
                                        <img class="login-logo" src="../img/Logo.png">
                                        <img class="login-logo" src="../img/Logo2.png">
                                        <h4 class="login-heading mb-4 mt-1">Office of the Student Financial Assistance
                                            and Scholarships</h4>
                                    </div>
                                    <!-- Sign In Form -->
                                    <form id="login-form" onsubmit="return false;">
                                        <div class="text-center mb-3">
                                            <h4>Login to your account</h4>
                                        </div>
                                        <div id="alert">

                                        </div>
                                        <div class="form-floating mb-3">
                                            <input type="number" class="form-control" id="student-number"
                                                placeholder="name@example.com" required autocomplete="username">
                                            <label for="student-number">Employee/Student Number</label>
                                        </div>
                                        <div class="form-floating mb-3 position-relative">
                                            <input type="password" class="form-control" id="password"
                                                placeholder="Password" required autocomplete="current-password">
                                            <label for="password">Password</label>
                                            <div class="invalid-feedback">
                                                The password you entered is incorrect.
                                            </div>
                                            <!-- Add the eye icon for password visibility -->
                                            <i id="toggle-password"
                                                class="bi bi-eye position-absolute top-50 translate-middle"
                                                style="right: 10px; cursor: pointer;"
                                                onclick="togglePasswordVisibility()"></i>
                                        </div>

                                        <div class="d-flex justify-content-between">
                                            <div class="form-check mb-3">
                                                <input class="form-check-input" type="checkbox" value=""
                                                    id="rememberPasswordCheck">
                                                <label class="form-check-label" for="rememberPasswordCheck">Remember
                                                    password</label>
                                            </div>
                                            <div>
                                                <a href="../User/forgot_password.php">Forgot password?</a>
                                            </div>
                                        </div>


                                        <div class="d-grid">
                                            <button id="loginButton" class="btn btn-lg  btn-login text-uppercase mb-2"
                                                onclick="login()" style="background-color: #008000; color: #ffffff;">
                                                Login
                                                <span id="spinner" class="spinner-border spinner-border-sm"
                                                    aria-hidden="true" style="display: none;"></span>
                                                <span id="status" role="status" style="display: none;"></span>
                                            </button>
                                            <div class="text-center">
                                                <span>Not Activated? <a class=""
                                                        href="../User/user_activation.php">Activate Here</a></span>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script type="text/javascript" src="../js/bootstrap.js"></script>
        <script type="text/javascript" src="User/js/login.js"></script>
    </div>
    <script>
        (() => {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.needs-validation')

            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>

    <script>
        function togglePasswordVisibility() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('toggle-password');

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
            }
        }
    </script>

</body>

</html>
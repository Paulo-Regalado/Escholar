<?php
session_start();
include_once '../php/config.php';
//include_once 'toCheckStudentNo.php';
$conn = OpenCon();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>Account Activation</title>

  <!-- Add the favicon link here -->
  <link rel="icon" type="image/png" href="img/Logo2.png">

  <!-- ICON -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <script src="https://smtpjs.com/v3/smtp.js"></script>
  <!-- Befor moving ahead please wheather you created credentials... -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />

  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <!-- BOOTSTRAP -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
  <link href="../css/bootstrap.css" rel="stylesheet">





  <link rel="stylesheet" href="css/user.css" />

</head>

<body style="height: 100vh; margin: 0; overflow: hidden;">



  <!-- Navbar -->
  <nav class="navbar bg-body-tertiary sticky-top">
    <div class="container-fluid d-flex justify-content-start">
      <div>
        <a class="navbar-brand d-flex align-items-center" href="http://escholar.eyjeyesdiar.com/">
          <div class="me-2 h-25 logo">
            <img src="../img/Logo2.png" class="logo" alt="logo">
          </div>
          <h5 class="m-0 fs-6 d-none d-md-block fw-bold">BULACAN STATE UNIVERSITY<br> Office of the Student
            Financial
            Assistance and Scholarships</h5>
        </a>
      </div>
    </div>
  </nav>

  <div class="banner d-flex justify-content-end align-items-center">
    <img src="img/BSU BANNER.jpg" alt="Banner Image">
    <!-- Your content goes here -->
  </div>

  <section style="height: 75%;" class="container-fluid d-flex justify-content-center align-items-center pb-2">

    <nav class="mt-2 "
      style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);"
      aria-label="breadcrumb">
      <ol class="breadcrumb">
        <!-- <li class="breadcrumb-item "><a href="#" class="text-black"><i class="fa-solid fa-house me-1"></i>Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Activation</li> -->
      </ol>
    </nav>

    <div class="toast-container position-fixed bottom-0 end-0 p-3">
      <div id="send-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive"
        aria-atomic="true">
        <div class="d-flex">
          <div class="toast-body">
            OTP Sent to you Email
          </div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
            aria-label="Close"></button>
        </div>
      </div>

      <div id="success-toast" class="toast align-items-center text-bg-success border-0" role="alert"
        aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
          <div class="toast-body">
            Account Verified, Create Password
          </div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
            aria-label="Close"></button>
        </div>
      </div>
    </div>

    <div class="d-flex justify-content-center ">
      <div style="max-width: 550px;" class="shadow p-3 mb-5 bg-body rounded">
        <h3 class=" fw-bolder text-center">SCHOLAR ACCOUNT ACTIVATION</h3>
        <hr class="mb-3">
        <div>
          <div>
            <div class="alert alert-success px-5 mb-4" role="alert">
              <!-- <h4 class="alert-heading display-6">KUYA WIN Scholarship Program Renewal 2nd Semester, Academic Year 2022-2023</h4> -->
              <h3>Welcome Scholars!</h3>
              <p class="mb-0">Please fill out the following field to activate your account as a scholar.</p>
            </div>

            <?php
            if (isset($_SESSION['error_message'])) {
              echo '<div class="error text-danger text-center">' . $_SESSION['error_message'] . '</div>';
              unset($_SESSION['error_message']); // Clear the error message after displaying it
            }
            ?>

            <form id="scholar-info-form" action="" method="post">
              <h4 class="form-title">Scholar Information</h4>

              <div class="row g-2 tex-center">
                <div class=" col">
                  <label for="student_number" class="form-label">Student No.</label>
                  <input type="number" name="student_number" id="student_number" class="form-control"
                    onkeyup="searchStudentNo()" required />
                  <div class='ms-2 ' id="result"></div>
                </div>

                <div class="ms-2 text-secondary" id="loader" style="display: none">
                  <span>Loading...</span>
                  <div class="spinner-border spinner-border-sm ms-auto" role="status" aria-hidden="true"></div>
                </div>
              </div>

              <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                <button onclick="sendOTP(event); copyStudentNumber();" class="btn btn-success" id="sendBtn"
                  disabled>Send
                  OTP</button>
              </div>
            </form>


            <!-- Verify Otp Form -->
            <div id="otp-form" class="otpverify" style="display:none;">
              <h4 class="form-title">OTP Verification</h4>
              <p>An OTP has been sent to your email address. Please enter it below to verify your account.</p>
              <div class="alert alert-danger col-12" role="alert" id="validation-error" style="display: none;">
                Your error here
              </div>
              <form action="" method="post">
                <div class="row g-2">
                  <div class="col">
                    <label for="otp" class="form-label">OTP Code</label>
                    <input type="number" name="otp" class="form-control" id="otp_inp" required>
                  </div>
                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                  <button id="otp-btn" class="btn btn-primary">Verify</button>
                </div>
              </form>
            </div>

            <!-- Password Form -->
            <div id="password_form" class="password_form" style="display:none;">
              <h4 class="form-title">Account Activation</h4>
              <p>Please Enter Password to be use in your account.</p>
              <div class="alert alert-danger col-12" role="alert" id="profile-error" style="display: none;">
                Your error here
              </div>
              <form action="../php/toInsertAccount.php" method="post" enctype="multipart/form-data">
                <div class="row">
                  <div class="col">
                    <label for="profile-pic" class="form-label">Profile Picture (JPG)</label>
                    <input type="file" name="profile-pic" accept=".jpg" class="form-control" id="profile-pic" required>
                  </div>
                </div>
                <div class="row g-2 mt-1">
                  <!-- Hidden input field to store the student number value -->
                  <input type="hidden" name="student_number" id="password_form_student_number" value="">


                  <div class="col">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" id="password" required>
                  </div>

                  <div class="col">
                    <label for="con_password" class="form-label">Confirm Password</label>
                    <input type="password" name="con_password" class="form-control" id="con_password" required
                      onkeyup="validatePasswordMatch()">
                  </div>
                </div>
                <div id="password_result" class="text-danger"></div>

                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                  <button type="button" id="submit-btn" class="btn btn-primary"
                    onclick="validateFileSizes();">Submit</button>
                </div>

                <!-- Modal -->
                <div class=" modal fade" id="term" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                  aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div
                    class="modal-dialog modal-dialog-centered modal-dialog-scrollable  modal-lg modal-fullscreen-sm-down">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">PRIVACY POLICY</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="p-1">
                          <p style="text-align: justify;">
                          <h4>Introduction</h4>

                          Welcome to E-Scholar, a web-based scholarship monitoring and graduate tracking system.
                          At
                          E-Scholar, we value your privacy and are committed to protecting your personal information.
                          This Privacy Policy explains how we collect, use, disclose, and safeguard your personal
                          information when you use our website. By using our services, you consent to the practices
                          described in this policy.<br><br>

                          <h4>Information We Collect</h4>

                          We may collect various types of personal information from users of our website, including
                          but not limited to:
                          <br>• Name: We collect your name to create and manage your account.
                          <br>• Email Address: Your email address is used for account-related communication and
                          notifications.
                          <br>• Contact Number: We collect your contact number to facilitate communication related to
                          your
                          account and the services we provide.
                          <br>• Password: We store a securely hashed version of your password to authenticate your
                          access
                          to our platform.
                          <br>• Profile Picture: You may choose to upload a profile picture. This is optional and used
                          to
                          personalize your account.<br><br>

                          <h4>How We Use Your Information</h4>

                          We use your personal information for the following purposes:

                          <br>• Account Creation and Management: We use your name, email address, contact number, and
                          password to activate and manage your account.
                          <br>• Communication: We use your email address and contact number to send you important
                          account-related information, updates, and notifications.
                          <br>• Personalization: If you choose to upload a profile picture, we use it to personalize
                          your
                          account and make your experience on our platform more engaging.
                          <br>• Improvement of Services: We may use aggregated and anonymized data to improve our
                          services, enhance user experience, and for research and analysis.<br><br>

                          <h4>Disclosure of Your Information
                          </h4>
                          We do not sell, trade, or rent your personal information to third parties. We may, however,
                          share your information with third parties in the following circumstances:

                          <br>Legal Requirements: We may disclose your information if required by law, to comply with
                          legal processes, or to protect our rights, privacy, safety, or property.<br><br>

                          <h4>Data Security</h4>

                          We take the security of your personal information seriously and have implemented measures to
                          safeguard it from unauthorized access, disclosure, alteration, and destruction. These
                          measures include encryption, access controls, and regular security assessments.<br><br>

                          <h4>Your Choices</h4>

                          You have the following choices regarding your personal information:

                          <br>• Access and Correction: You can access and update your personal information by logging
                          into
                          your account.
                          <br>• Account Deletion: You can request the deletion of your account. We will retain some
                          information for legal, regulatory, and operational purposes.<br><br>

                          <h4>Changes to this Policy</h4>

                          We may update this Privacy Policy from time to time to reflect changes in our practices and
                          services. We will notify you of any significant changes through our website or via
                          email.<br><br>

                          <h4>Contact Us</h4>

                          If you have any questions or concerns about this Privacy Policy or your personal
                          information, please contact us at <a href="">ofsasscholarshiptracker@gmail.com</a>.<br><br>

                          Thank you for using E-Scholar. Your privacy and trust are important to us.

                          </p>

                          <div class="form-check">
                            <input type="checkbox" id="agreeCheckbox" class="form-check-input">
                            <label class="form-check-label h6 fw-bold" for="agreeCheckbox">I agree on Privacy
                              Policy</label>
                          </div>


                        </div>
                        <div class="modal-footer">
                          <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <input type="submit" id="submitButton" class="btn btn-primary" disabled value="Submit">
                          </div>

                          <script>
                            const agreeCheckbox = document.getElementById('agreeCheckbox');
                            const submitButton = document.getElementById('submitButton');

                            agreeCheckbox.addEventListener('change', function () {
                              submitButton.disabled = !this.checked;
                            });
                          </script>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>


              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <div class="footer">
    <div>
      <div class="m-auto">
        <h5>CONTACT US</h5>
      </div>
    </div>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-sm-12 col-md-4 text-center ">
          <i class="bi bi-geo-alt me-1"></i>McArthur Highway, Malolos, Philippines
        </div>
        <div class="col-sm-12 col-md-4 text-center ">
          <i class="bi bi-telephone me-1"></i>(044) 790 6520
        </div>
        <div class="col-sm-12 col-md-4 text-center ">
          <i class="bi bi-envelope me-1"></i>scholarship@bulsu.edu.ph
        </div>
      </div>
    </div>
  </div>


  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
    crossorigin="anonymous"></script>

  <!-- Include jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</body>



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="../js/user_activation.js"></script>


<script>
  function sendOTP(event) {
    event.preventDefault();

    const form = document.getElementById('scholar-info-form');
    const otpverify = document.getElementsByClassName('otpverify')[0];
    const password_form = document.getElementsByClassName('password_form')[0];

    // Obtain form data
    const student_number = document.getElementById('student_number').value;

    let otp_val;

    // Create a FormData object to send the form data
    let formData = new FormData();
    formData.append('student_number', student_number);

    // Send the form data to a PHP script to get the email
    fetch('../php/getEmail.php', {
      method: 'POST',
      body: formData
    })
      .then(function (response) {
        return response.text();
      })
      .then(function (email) {
        // Check if email is empty or an error occurred
        if (email.trim() === "") {
          alert("Unable to retrieve email.");
          return;
        }

        // Create a SMTP credentials that I showed you in my previous video

        // Generating a random 6-digit OTP
        otp_val = Math.floor(100000 + Math.random() * 900000);

        sendOtpEmail(email, otp_val);

        // Continue the promise chain
        return "OK"; // Add this line to return a value for the next `then` block
      })
      .then(function (message) {
        if (message === "OK") {
          // SUCCESSFULLY
          const send_toast = document.getElementById('send-toast');
          bootstrap.Toast.getOrCreateInstance(send_toast).show();

          // Now making OTP input visible

          form.style.display = "none";
          otpverify.style.display = "block";
          password_form.style.display = "none"; // Correct this line
          const otp_inp = document.getElementById('otp_inp');
          const otp_btn = document.getElementById('otp-btn');

          otp_btn.addEventListener('click', (event) => {
            event.preventDefault(); // Remove `event` parameter, it's not needed
            // Now check whether sent email is valid
            console.log("otp button is clicked")

            if (otp_inp.value.length !== 6) {
              console.log("OTP length is not 6 digits");
              const validationError = document.getElementById('validation-error');
              validationError.textContent = 'OTP should be exactly 6 digits.';
              validationError.style.display = 'block';
            } else {
              if (otp_inp.value == otp_val) {
                // SUCCESSFULLY
                const success_toast = document.getElementById('success-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();
                form.style.display = "none";
                otpverify.style.display = "none";
                password_form.style.display = "block"; // Correct this line
              } else {
                const validationError = document.getElementById('validation-error');
                validationError.textContent = 'Invalid OTP.';
                validationError.style.display = 'block';
                otp_inp.value = ""; // Clear the OTP input field
              }
            }
          });
        }
      })
      .catch(function (error) {
        console.error('Error:', error);
      });
  }



  function validateFileSizes() {

    const profilePicInput = document.getElementById("profile-pic");
    const validationError = document.getElementById("profile-error");
    const maxFileSizeInBytes = 2097152; // 2 MB

    if (profilePicInput.files[0]?.size > maxFileSizeInBytes) {
      validationError.textContent = 'File size should not exceed 2 MB.';
      validationError.style.display = 'block';

      return false; // Prevent form submission
    }

    const pass = document.getElementById("password");
    if (pass.value.length < 8) {
      validationError.textContent = 'Password must be minimum of 8 characters.';
      validationError.style.display = 'block';
      return false; // Prevent form submission

    }

    var myModal = new bootstrap.Modal(document.getElementById('term'));
    myModal.toggle();


  }


  function sendOtpEmail(email, otp) {
    let formData = new FormData();
    formData.append('email', email);
    formData.append('otp', otp);

    fetch('../User/php/sendOtpEmail.php', { // Correct the URL path
      method: 'POST',
      body: formData
    })
      .then(function (response) {
        if (response.ok) {
          return response.text();
        } else {
          throw new Error('Failed to send OTP email');
        }
      })
      .then(function (responseText) {
        // You can handle the responseText here if needed
        console.log('Email sent:', responseText);
      })
      .catch(function (error) {
        console.error('Error:', error);
      });
  }
</script>

</html>
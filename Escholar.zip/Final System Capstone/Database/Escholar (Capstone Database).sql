-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2023 at 01:10 AM
-- Server version: 10.5.19-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u156823415_escholar`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `event_id` int(11) NOT NULL,
  `admin_username` varchar(250) NOT NULL,
  `activity_type` varchar(250) NOT NULL,
  `description` varchar(300) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`event_id`, `admin_username`, `activity_type`, `description`, `date`) VALUES
(997, 'PAULO REGALADO', 'Progress Tracking', 'Approved 2020101687 from UNIFAST TULONG DUNONG PROGRAM', '2023-11-27 16:08:48'),
(998, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT FOR TDP SCHOLARS', '2023-11-27 16:17:17'),
(999, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT FOR TDP SCHOLARS', '2023-11-27 16:45:03'),
(1000, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT FOR TDP SCHOLARS', '2023-11-27 16:45:13'),
(1001, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT FOR TDP SCHOLARS', '2023-11-27 16:47:25'),
(1002, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT FOR TDP SCHOLARS', '2023-11-27 16:49:00'),
(1003, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT FOR TDP SCHOLARS', '2023-11-27 16:49:10'),
(1004, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT FOR TDP SCHOLARS', '2023-11-27 16:49:11'),
(1005, 'PAULO REGALADO', 'Announcement Management', 'Posted an announcement about ANNOUNCEMENT FOR TDP SCHOLARS', '2023-11-27 16:51:18'),
(1006, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about DISTRIBUTION CANCELLED', '2023-11-27 16:54:03'),
(1007, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about DISTRIBUTION CANCELLED', '2023-11-27 16:54:04'),
(1008, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about DISTRIBUTION CANCELLED', '2023-11-27 16:54:51'),
(1009, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about DISTRIBUTION CANCELLED', '2023-11-27 16:54:52'),
(1010, 'PAULO REGALADO', 'Benefactor Management', 'Added CHED in benefactor.', '2023-11-27 21:40:18'),
(1011, 'PAULO REGALADO', 'Benefactor Management', 'Added TDP in benefactor.', '2023-11-27 21:40:29'),
(1012, 'PAULO REGALADO', 'Scholar Management', 'Imported 5 scholars in CHED benefactor.', '2023-11-27 21:40:47'),
(1013, 'PAULO REGALADO', 'Progress Tracker', 'Move 1 records to Process by Accounting.', '2023-11-27 21:41:17'),
(1014, 'PAULO REGALADO', 'Progress Tracker', 'Move 4 records to Process by Accounting.', '2023-11-27 21:41:25'),
(1015, 'PAULO REGALADO', 'Scholar Management', 'Added 2023405678 in TDP benefactor.', '2023-11-27 22:00:42'),
(1016, 'PAULO REGALADO', 'Scholar Management', 'Added 2023456789 in TDP benefactor.', '2023-11-27 22:03:51'),
(1017, 'PAULO REGALADO', 'Scholar Management', 'Added 2022101291 in TDP benefactor.', '2023-11-27 22:07:04'),
(1018, 'Admin', 'Academic Management', 'Updated the system for the new semester', '2023-11-27 22:07:38'),
(1019, 'PAULO REGALADO', 'Scholar Management', 'Edited 2020102116 from Masterlist.', '2023-11-27 22:08:01'),
(1020, 'PAULO REGALADO', 'Scholar Management', 'Edited 2020102118 from Masterlist.', '2023-11-27 22:08:07'),
(1021, 'PAULO REGALADO', 'Scholar Management', 'Edited 2020102119 from Masterlist.', '2023-11-27 22:08:12'),
(1022, 'PAULO REGALADO', 'Scholar Management', 'Edited 2020102190 from Masterlist.', '2023-11-27 22:08:29'),
(1023, 'PAULO REGALADO', 'Scholar Management', 'Edited 2022101291 from Masterlist.', '2023-11-27 22:08:40'),
(1024, 'Admin', 'Academic Management', 'Updated the system for the new academic year to 2024 to 2025', '2023-11-27 22:09:06'),
(1025, 'PAULO REGALADO', 'Scholar Management', 'Edited 2020102116 from Masterlist.', '2023-11-27 22:09:23'),
(1026, 'PAULO REGALADO', 'Scholar Management', 'Edited 2020102118 from Masterlist.', '2023-11-27 22:09:28'),
(1027, 'PAULO REGALADO', 'Scholar Management', 'Edited 2020102119 from Masterlist.', '2023-11-27 22:09:33'),
(1028, 'PAULO REGALADO', 'Scholar Management', 'Edited 2020102190 from Masterlist.', '2023-11-27 22:09:44'),
(1029, 'PAULO REGALADO', 'Scholar Management', 'Edited 2022101291 from Masterlist.', '2023-11-27 22:09:48'),
(1030, 'PAULO REGALADO', 'Announcement Management', 'Posted an announcement about Scholar Survey', '2023-11-27 22:15:31'),
(1031, 'PAULO REGALADO', 'Benefactor Management', 'Archive  in benefactor.', '2023-11-27 22:32:03'),
(1032, 'PAULO REGALADO', 'Benefactor Management', 'Archive  in benefactor.', '2023-11-27 22:32:44'),
(1033, 'PAULO REGALADO', 'Benefactor Management', 'Archive  in benefactor.', '2023-11-27 22:33:32'),
(1034, 'PAULO REGALADO', 'Benefactor Management', 'Archive  in benefactor.', '2023-11-27 22:34:36'),
(1035, 'PAULO REGALADO', 'Benefactor Management', 'Archive  in benefactor.', '2023-11-27 22:35:03'),
(1036, 'PAULO REGALADO', 'Announcement Management', 'Archive Scholar Survey in announcement.', '2023-11-27 22:45:01'),
(1037, 'PAULO REGALADO', 'Benefactor Management', 'Restore Scholar Survey in announcement.', '2023-11-27 22:45:16'),
(1038, 'PAULO REGALADO', 'Announcement Management', 'Archive Scholar Survey in announcement.', '2023-11-27 22:45:35'),
(1039, 'PAULO REGALADO', 'Scholar Management', 'Edited 2020102116 from Masterlist.', '2023-11-28 00:36:03'),
(1040, 'PAULO REGALADO', 'Benefactor Management', 'Added AICS in benefactor.', '2023-11-28 00:37:25'),
(1041, 'PAULO REGALADO', 'Benefactor Management', 'Archive AICS in benefactor.', '2023-11-28 00:37:34'),
(1042, 'PAULO REGALADO', 'Benefactor Management', 'Added AICS in benefactor.', '2023-11-28 00:38:25'),
(1043, 'PAULO REGALADO', 'Progress Tracker', 'Move 1 records to Process by Accounting.', '2023-11-29 10:32:35'),
(1044, 'PAULO REGALADO', 'Progress Tracker', 'Move 1 records to Scholarship Grant Claim.', '2023-11-29 10:32:45'),
(1045, 'PAULO REGALADO', 'Progress Tracker', 'Move 1 records to Process by Accounting.', '2023-11-29 10:32:58'),
(1046, 'PAULO REGALADO', 'Progress Tracker', 'Move 1 records to Process by Accounting.', '2023-11-29 10:34:17'),
(1047, 'PAULO REGALADO', 'Progress Tracker', 'Move 2 records to Scholarship Grant Claim.', '2023-11-29 10:34:24'),
(1048, 'PAULO REGALADO', 'Progress Tracker', 'Move 2 records to Process by Accounting.', '2023-11-29 10:41:51'),
(1049, 'PAULO REGALADO', 'Progress Tracker', 'Move 2 records to Scholarship Grant Claim.', '2023-11-29 10:41:58'),
(1050, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT', '2023-11-30 12:14:15'),
(1051, 'PAULO REGALADO', 'Announcement Management', 'Posted an announcement about Distribution of Scholars', '2023-11-30 16:27:20'),
(1052, 'PAULO REGALADO', 'Announcement Management', 'Posted an announcement about Announcement for Kuya Win Scholars', '2023-11-30 16:28:34'),
(1053, 'PAULO REGALADO', 'Announcement Management', 'Archive ANNOUNCEMENT FOR TDP SCHOLARS in announcement.', '2023-11-30 16:28:44'),
(1054, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT', '2023-11-30 16:29:30'),
(1055, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT', '2023-11-30 16:29:30'),
(1056, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT', '2023-11-30 16:29:31'),
(1057, 'PAULO REGALADO', 'Announcement Management', 'Update an announcement about ANNOUNCEMENT', '2023-11-30 16:29:31'),
(1058, 'PAULO REGALADO', 'Scholar Management', 'Imported 0 scholars in CHED benefactor.', '2023-12-01 01:53:19'),
(1059, 'PAULO REGALADO', 'Scholar Management', 'Imported 0 scholars in CHED benefactor.', '2023-12-01 01:53:25'),
(1060, 'PAULO REGALADO', 'Scholar Management', 'Imported 0 scholars in CHED benefactor.', '2023-12-01 01:54:06'),
(1061, 'PAULO REGALADO', 'Benfactor Management', 'Edited AICS from Benefactor.', '2023-12-01 01:57:39'),
(1062, 'PAULO REGALADO', 'Benfactor Management', 'Edited AICS from Benefactor.', '2023-12-01 01:58:04'),
(1063, 'PAULO REGALADO', 'Benfactor Management', 'Edited CHED from Benefactor.', '2023-12-01 01:58:10'),
(1064, 'PAULO REGALADO', 'Benfactor Management', 'Edited TDP from Benefactor.', '2023-12-01 01:58:16'),
(1065, 'PAULO REGALADO', 'Scholar Management', 'Added 2020101687 in CHED benefactor.', '2023-12-01 01:59:00'),
(1066, 'Admin', 'Academic Management', 'Updated the system for the new semester', '2023-12-01 01:59:38'),
(1067, 'PAULO REGALADO', 'Scholar Management', 'Archive 2020101687 from CHED masterlist.', '2023-12-01 02:02:46'),
(1068, 'PAULO REGALADO', 'Scholar Management', 'Added 2020101687 in CHED benefactor.', '2023-12-01 02:03:25'),
(1069, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-03 11:56:10'),
(1070, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-03 12:00:18'),
(1071, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-03 12:01:33'),
(1072, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-03 12:04:19'),
(1073, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-03 12:10:04'),
(1074, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-03 12:11:03'),
(1075, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-03 13:18:41'),
(1076, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-03 23:40:39'),
(1077, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-03 23:48:56'),
(1078, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-04 00:14:41'),
(1079, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-04 00:15:15'),
(1080, 'PAOLO JENESIS MENESES', 'Gallery Management', 'Added an image to the gallery', '2023-12-04 00:15:28'),
(1081, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Added 2020101688 in AICS benefactor.', '2023-12-04 01:08:27'),
(1082, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Added 2020101689 in AICS benefactor.', '2023-12-04 01:26:00'),
(1083, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Edited 2020101689 from Masterlist.', '2023-12-04 01:26:34'),
(1084, 'Admin', 'Academic Management', 'Updated the system for the new semester', '2023-12-04 01:30:03'),
(1085, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Added 2020101681 in CHED benefactor.', '2023-12-04 17:45:44'),
(1086, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Imported 2 scholars in AICS benefactor.', '2023-12-04 23:19:53'),
(1087, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Imported 0 scholars in AICS benefactor.', '2023-12-04 23:20:20'),
(1088, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Imported 0 scholars in AICS benefactor.', '2023-12-04 23:20:53'),
(1089, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Imported 0 scholars in AICS benefactor.', '2023-12-04 23:22:50'),
(1090, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Imported 0 scholars in AICS benefactor.', '2023-12-04 23:23:05'),
(1091, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Imported 0 scholars in AICS benefactor.', '2023-12-04 23:25:33'),
(1092, 'PAULO REGALADO', 'Scholar Management', 'Added 2020152119 in CHED benefactor.', '2023-12-05 05:59:40'),
(1093, 'PAULO REGALADO', 'Scholar Management', 'Imported 4 scholars in CHED benefactor.', '2023-12-05 06:13:03'),
(1094, 'PAULO REGALADO', 'Scholar Management', 'Added 2021101819 in TDP benefactor.', '2023-12-05 06:20:02'),
(1095, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Imported 0 scholars in AICS benefactor.', '2023-12-05 06:22:45'),
(1096, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Archive 2020101688 from AICS masterlist.', '2023-12-07 12:25:55'),
(1097, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Archive 2020101689 from AICS masterlist.', '2023-12-07 12:25:56'),
(1098, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Archive 2020102116 from AICS masterlist.', '2023-12-07 12:25:57'),
(1099, 'PAOLO JENESIS MENESES', 'Scholar Management', 'Archive 2020102117 from AICS masterlist.', '2023-12-07 12:25:59');

-- --------------------------------------------------------

--
-- Table structure for table `admin_account`
--

CREATE TABLE `admin_account` (
  `account_id` int(11) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `account_number` varchar(10) NOT NULL,
  `password_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_account`
--

INSERT INTO `admin_account` (`account_id`, `last_name`, `first_name`, `middle_name`, `account_number`, `password_hash`) VALUES
(14, 'REGALADO', 'PAULO', 'SAMSON', '1234567890', '$2y$10$MDErM.G84RlqaOeB4ffRvetO82c1Ua/Csovu/5QGqWQ3nFjgiAJpe'),
(18, 'MENESES', 'PAOLO JENESIS', 'VALERIANO', '0000000000', '$2y$10$hNKs2zHiwekxReWQ6hfWjO9hQRnSypmgifOlBsryJBdYQ8iFN1.nu'),
(20, 'Velasco', 'Nina', '', '1234567899', '$2y$10$EeENFqul.f.0GTg0wWuonef8EiGQKd.RU2K06BsoovI.ywP/m6MS6');

-- --------------------------------------------------------

--
-- Table structure for table `AICS_656cbb1bd4a86`
--

CREATE TABLE `AICS_656cbb1bd4a86` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AICS_6564c5c53b108`
--

CREATE TABLE `AICS_6564c5c53b108` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AICS_6564c6010b4c2`
--

CREATE TABLE `AICS_6564c6010b4c2` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AICS_6568cd8a4d57f`
--

CREATE TABLE `AICS_6568cd8a4d57f` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `AICS_6568cd8a4d57f`
--

INSERT INTO `AICS_6568cd8a4d57f` (`student_number`, `status`) VALUES
(2020101688, 'approved'),
(2020101689, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` mediumtext NOT NULL,
  `url` varchar(250) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `supporting_name` varchar(255) DEFAULT NULL,
  `supporting_type` varchar(100) DEFAULT NULL,
  `date_created` date NOT NULL DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `title`, `description`, `url`, `file_name`, `file_type`, `supporting_name`, `supporting_type`, `date_created`) VALUES
(57, 'ANNOUNCEMENT', '📌WHAT: KUYA WIN SCHOLARSHIP PROGRAM ORIENTATION AND AWARDING OF NOTICE OF AWARD (NOA) AY 2023-2024<br>📌WHO: KWSP SCHOLARS FOR AY 2023-2024 (Kindly see attached photos for the list of KWSP Shortlisted Scholars)<br>📌WHEN: November 14, 2023 (Tuesday) 12:30 PM START OF REGISTRATION<br>📌WHERE: BULACAN STATE UNIVERSITY VALENCIA HALL MAIN CAMPUS<br>📌WHAT TO BRING:<br>-1 Photocopy of BulSU ID/Any Valid ID with 3 original specimen signatures and contact number<br>-BALLPEN<br><br>Please view the attach file: ', '', '404876039_731853208969576_2562731681167484649_n.jpg', 'image/jpeg', NULL, NULL, '2023-11-15'),
(64, 'DISTRIBUTION CANCELLED', 'The Distribution of Scholars is cancelled. Please wait for further announcement', 'https://www.youtube.com/', 'bulsu_office_of_the_scholarship_official_logo_by_idrianmark_d6cnil0-pre.jpg', 'image/jpeg', NULL, NULL, '2023-11-26'),
(69, 'Distribution of Scholars', '📌WHAT: KUYA WIN SCHOLARSHIP PROGRAM ORIENTATION AND AWARDING OF NOTICE OF AWARD (NOA) AY 2023-2024<br>📌WHO: KWSP SCHOLARS FOR AY 2023-2024 (Kindly see attached photos for the list of KWSP Shortlisted Scholars)<br>📌WHEN: November 14, 2023 (Tuesday) 12:30 PM START OF REGISTRATION<br>📌WHERE: BULACAN STATE UNIVERSITY VALENCIA HALL MAIN CAMPUS<br>📌WHAT TO BRING:<br>-1 Photocopy of BulSU ID/Any Valid ID with 3 original specimen signatures and contact number<br>-BALLPEN<br><br>Please view the attach file: ', NULL, '404876039_731853208969576_2562731681167484649_n.jpg', 'image/jpeg', NULL, NULL, '2023-11-30'),
(70, 'Announcement for Kuya Win Scholars', 'Please be advised that the distribution of Tulong Dunong Program (TDP) A.Y 2021-2022 2nd Semester will resume on Wednesday, November 15, 2023. We will be conducting a face-to-face orientation and notice of award of Kuya Win Scholarship Program tomorrow, November 14, 2023.<br><br>Please kindly wait for further announcements.<br><br>Thank you!', NULL, '404876039_731853208969576_2562731681167484649_n.jpg', 'image/jpeg', NULL, NULL, '2023-11-30');

-- --------------------------------------------------------

--
-- Table structure for table `archived_announcement`
--

CREATE TABLE `archived_announcement` (
  `id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` mediumtext NOT NULL,
  `url` varchar(250) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `supporting_name` varchar(255) DEFAULT NULL,
  `supporting_type` varchar(100) DEFAULT NULL,
  `date_created` date NOT NULL DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `archived_announcement`
--

INSERT INTO `archived_announcement` (`id`, `title`, `description`, `url`, `file_name`, `file_type`, `supporting_name`, `supporting_type`, `date_created`) VALUES
(2, 'Scholar Survey', 'Please answer the survey found in the link below', 'https://survey.com', 'Icon.png', 'image/png', NULL, NULL, '2023-11-27'),
(3, 'ANNOUNCEMENT FOR TDP SCHOLARS', 'Please be advised that the distribution of Tulong Dunong Program (TDP) A.Y 2021-2022 2nd Semester will resume on Wednesday, November 15, 2023. We will be conducting a face-to-face orientation and notice of award of Kuya Win Scholarship Program tomorrow, November 14, 2023.<br><br>Please kindly wait for further announcements.<br><br>Thank you!', NULL, 'SK PAULO.png', 'image/png', NULL, NULL, '2023-11-27');

-- --------------------------------------------------------

--
-- Table structure for table `archived_benefactor`
--

CREATE TABLE `archived_benefactor` (
  `id` int(11) NOT NULL,
  `particular` varchar(55) NOT NULL,
  `semester` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  `slot` int(5) NOT NULL,
  `amount` int(11) NOT NULL,
  `from_sy` year(4) NOT NULL,
  `to_sy` year(4) NOT NULL,
  `table_name` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `archived_benefactor`
--

INSERT INTO `archived_benefactor` (`id`, `particular`, `semester`, `name`, `slot`, `amount`, `from_sy`, `to_sy`, `table_name`) VALUES
(233, 'GOVERNMENT', '1ST', 'CHED', 0, 0, 2023, 2024, 'CHED_65649c4273cff'),
(234, 'INSTITUTIONAL', '1ST', 'TDP', 0, 0, 2023, 2024, 'TDP_65649c4cec2fe'),
(235, 'GOVERNMENT', '2ND', 'CHED', 0, 0, 2023, 2024, 'CHED_6564a2aa833d9'),
(236, 'INSTITUTIONAL', '2ND', 'TDP', 0, 0, 2023, 2024, 'TDP_6564a2aa8d861'),
(237, 'GOVERNMENT', '2ND', 'AICS', 0, 0, 2023, 2024, 'AICS_6564c5c53b108'),
(238, 'GOVERNMENT', '1ST', 'CHED', 0, 0, 2022, 2023, 'CHED_6564a301e4f73'),
(239, 'INSTITUTIONAL', '1ST', 'TDP', 0, 0, 2022, 2023, 'TDP_6564a302057bd'),
(240, 'GOVERNMENT', '1ST', 'AICS', 0, 0, 2022, 2023, 'AICS_6564c6010b4c2'),
(241, 'GOVERNMENT', '2ND', 'CHED', 0, 0, 2022, 2023, 'CHED_6568cd8a31c85'),
(242, 'INSTITUTIONAL', '2ND', 'TDP', 0, 0, 2022, 2023, 'TDP_6568cd8a3f73a'),
(243, 'GOVERNMENT', '2ND', 'AICS', 0, 0, 2022, 2023, 'AICS_6568cd8a4d57f');

-- --------------------------------------------------------

--
-- Table structure for table `archived_masterlist`
--

CREATE TABLE `archived_masterlist` (
  `id` int(11) NOT NULL,
  `benefactor_name` varchar(55) NOT NULL,
  `table_name` varchar(55) NOT NULL,
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `archived_masterlist`
--

INSERT INTO `archived_masterlist` (`id`, `benefactor_name`, `table_name`, `student_number`, `status`) VALUES
(31, 'AICS 2023-2024 1ST Semester', 'AICS_656cbb1bd4a86', 2020101688, 'waiting'),
(32, 'AICS 2023-2024 1ST Semester', 'AICS_656cbb1bd4a86', 2020101689, 'pending'),
(33, 'AICS 2023-2024 1ST Semester', 'AICS_656cbb1bd4a86', 2020102116, 'approved'),
(34, 'AICS 2023-2024 1ST Semester', 'AICS_656cbb1bd4a86', 2020102117, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `benefactor`
--

CREATE TABLE `benefactor` (
  `id` int(11) NOT NULL,
  `particular` varchar(55) NOT NULL,
  `semester` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  `slot` int(5) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `from_sy` year(4) NOT NULL,
  `to_sy` year(4) NOT NULL,
  `table_name` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `benefactor`
--

INSERT INTO `benefactor` (`id`, `particular`, `semester`, `name`, `slot`, `amount`, `from_sy`, `to_sy`, `table_name`) VALUES
(322, 'GOVERNMENT', '1ST', 'CHED', 0, 0, 2023, 2024, 'CHED_656cbb1bc437b'),
(323, 'INSTITUTIONAL', '1ST', 'TDP', 0, 0, 2023, 2024, 'TDP_656cbb1bcd165'),
(324, 'GOVERNMENT', '1ST', 'AICS', 0, 0, 2023, 2024, 'AICS_656cbb1bd4a86');

-- --------------------------------------------------------

--
-- Table structure for table `CHED_656cbb1bc437b`
--

CREATE TABLE `CHED_656cbb1bc437b` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `CHED_656cbb1bc437b`
--

INSERT INTO `CHED_656cbb1bc437b` (`student_number`, `status`) VALUES
(2020101681, 'approved'),
(2020101687, 'pending'),
(2020102116, 'waiting'),
(2020102117, 'approved'),
(2020102118, 'approved'),
(2020102119, 'approved'),
(2020102121, 'approved'),
(2020152119, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `CHED_6564a2aa833d9`
--

CREATE TABLE `CHED_6564a2aa833d9` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `CHED_6564a2aa833d9`
--

INSERT INTO `CHED_6564a2aa833d9` (`student_number`, `status`) VALUES
(2020102116, 'approved'),
(2020102117, 'waiting'),
(2020102118, 'approved'),
(2020102119, 'approved'),
(2020102121, 'waiting');

-- --------------------------------------------------------

--
-- Table structure for table `CHED_6564a301e4f73`
--

CREATE TABLE `CHED_6564a301e4f73` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `CHED_6564a301e4f73`
--

INSERT INTO `CHED_6564a301e4f73` (`student_number`, `status`) VALUES
(2020101687, 'approved'),
(2020102116, 'claim'),
(2020102118, 'claim'),
(2020102119, 'claim');

-- --------------------------------------------------------

--
-- Table structure for table `CHED_6568cd8a31c85`
--

CREATE TABLE `CHED_6568cd8a31c85` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `CHED_6568cd8a31c85`
--

INSERT INTO `CHED_6568cd8a31c85` (`student_number`, `status`) VALUES
(2020101687, 'approved'),
(2020102116, 'pending'),
(2020102118, 'waiting'),
(2020102119, 'waiting');

-- --------------------------------------------------------

--
-- Table structure for table `CHED_65649c4273cff`
--

CREATE TABLE `CHED_65649c4273cff` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `CHED_65649c4273cff`
--

INSERT INTO `CHED_65649c4273cff` (`student_number`, `status`) VALUES
(2020102116, 'processed'),
(2020102117, 'processed'),
(2020102118, 'processed'),
(2020102119, 'processed'),
(2020102121, 'processed');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(10) NOT NULL,
  `stack_order` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `stack_order`, `file_name`) VALUES
(12, 1, 'poster.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `graduate_information`
--

CREATE TABLE `graduate_information` (
  `grad_pic` varchar(300) NOT NULL,
  `student_number` int(11) NOT NULL,
  `complete_name` varchar(250) NOT NULL,
  `birthday` date NOT NULL,
  `gender` varchar(20) NOT NULL,
  `civil_status` enum('Single','Married','Divorced','Widowed') NOT NULL,
  `current_address` varchar(250) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `course` varchar(250) NOT NULL,
  `year_graduated` int(10) NOT NULL,
  `benefactor` varchar(250) NOT NULL,
  `campus` enum('Malolos Campus','Bustos Campus','Meneses Campus','Hagonoy Campus','Sarmiento Campus') NOT NULL,
  `employment` enum('Employed, Locally','Employed, Abroad','Self-employed','Unemployed') NOT NULL,
  `org_type` enum('Public/Government','NGO','Non-profit','Private','Owned') NOT NULL,
  `company_name` varchar(250) NOT NULL,
  `company_address` varchar(250) NOT NULL,
  `position` varchar(250) NOT NULL,
  `year_in_company` int(10) NOT NULL,
  `reasons` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `graduate_information`
--

INSERT INTO `graduate_information` (`grad_pic`, `student_number`, `complete_name`, `birthday`, `gender`, `civil_status`, `current_address`, `contact`, `email`, `course`, `year_graduated`, `benefactor`, `campus`, `employment`, `org_type`, `company_name`, `company_address`, `position`, `year_in_company`, `reasons`) VALUES
('2020112118_gradpic.jpg', 2020112118, 'Alfred T. Watermax', '2005-01-13', 'Male', 'Single', 'Malolos, Bulacan', '2147483647', 'watermax@gmail.com', 'CHTM', 2020, 'CHED', 'Malolos Campus', 'Employed, Abroad', 'Private', 'Accenture', 'Ortigas Center', 'Developer', 2, ''),
('2020122130_gradpic.jpg', 2020122130, 'Alianna J. Dolina', '2001-06-19', 'Female', 'Single', 'San Marcos Calumpit Bulacan', '2147483647', 'alyanna@gmail.com', 'CHTM', 2020, 'CHED', 'Bustos Campus', 'Employed, Abroad', 'Owned', 'Accenture', 'Ortigas Center', 'Developer', 4, ''),
('2020152219_gradpic.jpg', 2020152219, 'Kylie Rose D. Dela Cruz', '2003-09-09', 'Female', 'Single', 'San Marcos Calumpit Bulacan', '2147483647', 'kylierose@gmail.com', 'BSIT', 2020, 'CHED', 'Malolos Campus', 'Employed, Locally', 'Private', 'Accenture', 'Ortigas Center', 'Developer', 3, ''),
('2022122513_gradpic.jpg', 2022122513, 'James T. Bond', '2000-10-24', 'Male', 'Single', 'San Marcos Calumpit Bulacan', '2147483647', 'bond@gmail.com', 'BSIT', 2021, 'CHED', 'Malolos Campus', 'Self-employed', 'Private', 'Accenture', 'Ortigas Center', 'Developer', 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `masterlist`
--

CREATE TABLE `masterlist` (
  `student_number` int(10) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `email` varchar(55) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `campus` varchar(20) NOT NULL,
  `college` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `year_level` varchar(10) NOT NULL,
  `gwa` float NOT NULL,
  `units` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `masterlist`
--

INSERT INTO `masterlist` (`student_number`, `last_name`, `first_name`, `middle_name`, `email`, `contact`, `campus`, `college`, `course`, `year_level`, `gwa`, `units`) VALUES
(2020101681, 'Velasco', 'Nina', 'Sison', 'alyssadelrosario@gmail.com', '09121234567', 'Malolos Campus', 'CAFA', 'BSA', '5', 1.25, 18),
(2020101687, 'Velasco', 'Nina rapha ella', 'Sison', 'ninaraphaella.velasco.s@bulsu.edu.ph', '09069462736', 'Malolos Campus', 'CICT', 'BSIT', '3rd', 1.5, 18),
(2020101688, 'Del rosario', 'Alyssa joy', 'Tuazon', 'alyssajoy.delrosario.t@bulsu.edu.ph', '09069462736', 'Malolos Campus', 'CICT', 'BSIT', '3rd', 1.25, 18),
(2020101689, 'Cinco', 'Rovic', 'Santos', 'iamellay011@gmail.com', '09069462736', 'Bustos Campus', 'CIT', 'BIT Electronics Technology', '4th', 1.25, 18),
(2020102116, 'Regalado', 'Paulo', 'Samson', 'regaladopaulo.19@gmail.com', '09067430579', 'Malolos Campus', 'CICT', 'BSIT', '4th', 1.2, 25),
(2020102117, 'Meneses', 'Paolo', 'Valeriano', 'paolomeneses74@gmail.com', '09123456789', 'Malolos Campus', 'CICT', 'BSIT', 'graduate', 1.4, 25),
(2020102118, 'Velasco', 'Nina raphaella', 'Santos', 'velasco.ninaraphaella.s.1687@gmail.com', '09123456789', 'Malolos Campus', 'CICT', 'BSIT', '4th', 1.5, 23),
(2020102119, 'Del rosario', 'Alyssa', 'Cruz', 'delrosario.aj.t.2081@gmail.com', '09350489657', 'Bustos Campus', 'CICT', 'BSIT', '4th', 1.3, 23),
(2020102121, 'Cinco', 'Rovic jane', 'Bautista', 'rovicjane@gmail.com', '09356780223', 'Bustos Campus', 'CICT', 'BLIS', '4th', 1, 12),
(2020102190, 'Torno', 'James', 'Samson', 's@gmail.com', '09183455347', 'Meneses Campus', 'CCJE', 'BALM', '4th', 1.2, 24),
(2020152118, 'Dela cruz', 'Rudolph', '', 's@gmail.com', '09609371844', 'Hagonoy Campus', 'COED', 'BEE', '4th', 1.2, 24),
(2020152119, 'Lebron', 'James', 'Samson', 's@gmail.com', '09609371844', 'Malolos Campus', 'CN', 'BSN', '2nd', 1.4, 23),
(2021101819, 'Curry', 'Stephen', '', 'juan@gmail.com', '09183455347', 'Malolos Campus', 'COE', 'BSCE', '3rd', 1.4, 25),
(2022101291, 'Ocampo', 'Dan', 'Samson', 'juan@gmail.com', '09107875555', 'Malolos Campus', 'CIT', 'BIT AUTOMOTIVE', '3rd', 1.2, 24),
(2022102172, 'Jordan', 'Clarkson', '', 'juan@gmail.com', '09107875555', 'Hagonoy Campus', 'COED', 'BEE', '4th', 1.4, 23),
(2023102118, 'Ocampo', 'James', '', 's@gmail.com', '09183455347', 'Meneses Campus', 'COE', 'BS Mechanical Engineering', '4th', 1.4, 23),
(2023405678, 'San juan', 'Alester', '', 'juan@gmail.com', '09609371844', 'San Rafael Campus', 'CCJE', 'BALM', '3rd', 1.4, 24),
(2023456789, 'Lincoln', 'Dane', '', 's@gmail.com', '09609371844', 'Sarmiento', 'CBA', 'BSBABE', '3rd', 1.5, 25);

-- --------------------------------------------------------

--
-- Table structure for table `monitoring_form`
--

CREATE TABLE `monitoring_form` (
  `student_number` int(10) NOT NULL,
  `gwa` double NOT NULL,
  `units` int(5) NOT NULL,
  `cor_file_name` varchar(250) DEFAULT NULL,
  `cog_file_name` varchar(250) DEFAULT NULL,
  `id_file_name` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `monitoring_form`
--

INSERT INTO `monitoring_form` (`student_number`, `gwa`, `units`, `cor_file_name`, `cog_file_name`, `id_file_name`) VALUES
(2020101681, 1.25, 18, NULL, NULL, NULL),
(2020101687, 1.5, 14, '2020101687_COR.pdf', '2020101687_COG.pdf', '2020101687_ID.pdf'),
(2020101689, 1, 14, '2020101689_COR.pdf', '2020101689_COG.pdf', '2020101689_ID.pdf'),
(2020102116, 1.2, 23, NULL, NULL, NULL),
(2020102117, 1.4, 25, NULL, NULL, NULL),
(2020102118, 1.5, 23, NULL, NULL, NULL),
(2020102119, 1.3, 23, NULL, NULL, NULL),
(2020102121, 1, 12, NULL, NULL, NULL),
(2020152119, 1.4, 23, NULL, NULL, NULL),
(2021101819, 1.4, 25, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `TDP_656cbb1bcd165`
--

CREATE TABLE `TDP_656cbb1bcd165` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `TDP_656cbb1bcd165`
--

INSERT INTO `TDP_656cbb1bcd165` (`student_number`, `status`) VALUES
(2021101819, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `TDP_6564a2aa8d861`
--

CREATE TABLE `TDP_6564a2aa8d861` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `TDP_6564a2aa8d861`
--

INSERT INTO `TDP_6564a2aa8d861` (`student_number`, `status`) VALUES
(2020102190, 'approved'),
(2020152118, 'waiting'),
(2022101291, 'approved'),
(2022102172, 'waiting'),
(2023102118, 'waiting'),
(2023405678, 'waiting'),
(2023456789, 'waiting');

-- --------------------------------------------------------

--
-- Table structure for table `TDP_6564a302057bd`
--

CREATE TABLE `TDP_6564a302057bd` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `TDP_6564a302057bd`
--

INSERT INTO `TDP_6564a302057bd` (`student_number`, `status`) VALUES
(2020102190, 'claim'),
(2022101291, 'claim');

-- --------------------------------------------------------

--
-- Table structure for table `TDP_6568cd8a3f73a`
--

CREATE TABLE `TDP_6568cd8a3f73a` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `TDP_6568cd8a3f73a`
--

INSERT INTO `TDP_6568cd8a3f73a` (`student_number`, `status`) VALUES
(2020102190, 'waiting'),
(2022101291, 'waiting');

-- --------------------------------------------------------

--
-- Table structure for table `TDP_65649c4cec2fe`
--

CREATE TABLE `TDP_65649c4cec2fe` (
  `student_number` int(10) NOT NULL,
  `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `TDP_65649c4cec2fe`
--

INSERT INTO `TDP_65649c4cec2fe` (`student_number`, `status`) VALUES
(2020102190, 'approved'),
(2020152118, 'approved'),
(2022101291, 'approved'),
(2022102172, 'approved'),
(2023102118, 'approved'),
(2023405678, 'approved'),
(2023456789, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `student_number` int(10) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_pic_file` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`student_number`, `password`, `profile_pic_file`) VALUES
(2020101687, '$2y$10$TyYl5EB9UtDuMf9FwgeZy.AQURi8Sita6tw2RvfzD.B8DPW/C9Y32', '2020101687_profile_pic.jpg'),
(2020101688, '$2y$10$LV3Yj4VU7lSMSN9oHgx69OoA3t7p6a1qsCpvLOnDjW62EJN6t/s22', '2020101688_profile_pic.jpg'),
(2020101689, '$2y$10$C4.uxN9e1q4voeuTaxnEAeSGTkNIJ6JHYYIrdyy6pDtXs14RHXi6W', '2020101689_profile_pic.jpg'),
(2020102116, '$2y$10$T981b5hY8xoaycTOLoqIZOWKjjsnLk2PYFgvl2H8oaZ9oWrEL22sC', '2020102116_profile_pic.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `admin_account`
--
ALTER TABLE `admin_account`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `AICS_656cbb1bd4a86`
--
ALTER TABLE `AICS_656cbb1bd4a86`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `AICS_6564c5c53b108`
--
ALTER TABLE `AICS_6564c5c53b108`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `AICS_6564c6010b4c2`
--
ALTER TABLE `AICS_6564c6010b4c2`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `AICS_6568cd8a4d57f`
--
ALTER TABLE `AICS_6568cd8a4d57f`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `archived_announcement`
--
ALTER TABLE `archived_announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `archived_benefactor`
--
ALTER TABLE `archived_benefactor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `archived_masterlist`
--
ALTER TABLE `archived_masterlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `benefactor`
--
ALTER TABLE `benefactor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `CHED_656cbb1bc437b`
--
ALTER TABLE `CHED_656cbb1bc437b`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `CHED_6564a2aa833d9`
--
ALTER TABLE `CHED_6564a2aa833d9`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `CHED_6564a301e4f73`
--
ALTER TABLE `CHED_6564a301e4f73`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `CHED_6568cd8a31c85`
--
ALTER TABLE `CHED_6568cd8a31c85`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `CHED_65649c4273cff`
--
ALTER TABLE `CHED_65649c4273cff`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `graduate_information`
--
ALTER TABLE `graduate_information`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `masterlist`
--
ALTER TABLE `masterlist`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `monitoring_form`
--
ALTER TABLE `monitoring_form`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `TDP_656cbb1bcd165`
--
ALTER TABLE `TDP_656cbb1bcd165`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `TDP_6564a2aa8d861`
--
ALTER TABLE `TDP_6564a2aa8d861`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `TDP_6564a302057bd`
--
ALTER TABLE `TDP_6564a302057bd`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `TDP_6568cd8a3f73a`
--
ALTER TABLE `TDP_6568cd8a3f73a`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `TDP_65649c4cec2fe`
--
ALTER TABLE `TDP_65649c4cec2fe`
  ADD PRIMARY KEY (`student_number`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`student_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1100;

--
-- AUTO_INCREMENT for table `admin_account`
--
ALTER TABLE `admin_account`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `archived_announcement`
--
ALTER TABLE `archived_announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `archived_benefactor`
--
ALTER TABLE `archived_benefactor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;

--
-- AUTO_INCREMENT for table `archived_masterlist`
--
ALTER TABLE `archived_masterlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `benefactor`
--
ALTER TABLE `benefactor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=325;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

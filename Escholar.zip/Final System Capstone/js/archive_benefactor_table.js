function fetchArchivedBenefactor(name) {
    $('#archive-table').DataTable().destroy();
    const tableBody = document.getElementById("archive-table-body");

    const displayData = (data) => {
        console.log(data);
        tableBody.innerHTML = ""; // Clear previous data

        if (data.length === 0) {
            tableBody.innerHTML = "<tr><td colspan='2'>No data found</td></tr>";
        } else {
            data.forEach((row) => {
                tableBody.innerHTML += `
                    <tr>
                        <td>${row.name} ${row.from_sy} - ${row.to_sy} ${row.semester} Semester</td>
                        <td>
                            <a style="width: 150px; background-color: #008000;"  href="archive_benefactor_data.php?id=${row.id}" id="${row.id}" class="btn btn-success btn-sm mb-1">
                                <i class="bi bi-eye me-1"></i>View
                            </a>
                        </td>
                    </tr>
                `;
            });
        }

        $('#archive-table').DataTable();
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr class='text-center'><td colspan='2'>An error occurred while fetching data.</td></tr>";
    };

    var formData = new FormData();
    formData.append('name', name);

    // AJAX fetch request
    fetch("../php/getArchivedBenefactorName.php", {
        method: 'POST',
        body: formData
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data
            displayData(data); // Call the displayData function with the received data
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

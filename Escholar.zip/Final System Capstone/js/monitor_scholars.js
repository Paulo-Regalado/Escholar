document.addEventListener("DOMContentLoaded", () => {
    fetchBenefactor();
});

var full_name;
function actLogs(firstname, lastname) {

    full_name = firstname + ' ' + lastname;

}

function addBenefactor() {


    var name = document.getElementById('benefactor-name').value.toUpperCase();
    var particular = document.getElementById('benefactor-particular').value.toUpperCase();
    var semester = document.getElementById('benefactor-semester').value.toUpperCase();
    var slot = document.getElementById('benefactor-slot').value;
    var amount = document.getElementById('benefactor-amount').value;
    var from_sy = document.getElementById('from_sy').value;
    var to_sy = document.getElementById('to_sy').value;
    var user = full_name;


    // console.log(!particular);
    // console.log(!semester);
    // console.log(!name);
    // console.log(!slot);
    // console.log(!amount);
    // console.log(!from_sy);
    // console.log(!to_sy);


    let alert = document.getElementById('alert-error');

    if (!name || !particular || !semester || !from_sy || !to_sy) {
        // Display an error message or take appropriate action
        console.log(particular);
        console.log(semester);
        console.log(name);
        console.log(slot);
        console.log(amount);
        alert.innerHTML = '<div class="alert alert-danger" role="alert">Please fill out all required fields.</div>';
    }
    else if (!/^[A-Za-z ]+$/.test(name)) {
        alert.innerHTML = '<div class="alert alert-danger" role="alert">Please enter a valid benefactor with letters and spaces only.</div>';
    }
    else {

        // Create a FormData object to send the form data
        let formData = new FormData();
        formData.append('benefactor-name', name);
        formData.append('benefactor-particular', particular);
        formData.append('benefactor-semester', semester);
        formData.append('benefactor-slot', slot);
        formData.append('benefactor-amount', amount);
        formData.append('from_sy', from_sy);
        formData.append('to_sy', to_sy);
        formData.append('user', user);


        // Send the form data to a PHP script using AJAX
        fetch('../php/toAddBenefactor.php', {
            method: 'POST',
            body: formData
        })
            .then(function (response) {
                return response.text();


            })
            .then(function (data) {
                console.log(data);
                displayToast();
                dismissAddModal();
                document.getElementById('add-benefactor-form').reset();
                fetchBenefactor();
            })
            .catch(function (error) {
                console.error('Error:', error);
            });
    }
}



// ADD BENEFACTOR+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

var add_benefactor_modal = document.getElementById('add-benefactor-modal');
var AddModalInstance = new bootstrap.Modal(add_benefactor_modal);

function displayToast() {
    const success_toast = document.getElementById('success-add-toast');
    bootstrap.Toast.getOrCreateInstance(success_toast).show();
}

function dismissAddModal() {
    AddModalInstance.hide();
}

function fetchBenefactor() {
    $('#benefactor-table').DataTable().destroy();
    const tableBody = document.getElementById("benefactor-table-body");

    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            tableBody.innerHTML += `
            <td>${row.name}</td>
            <td>${row.particular}</td>
            <td>${row.from_sy} - ${row.to_sy}</td>
            <td>${row.semester}</td>
            <td class="d-none">${row.slot}</td>
            <td class="d-none">${row.amount}</td>
            <td >
              <button type="button" nowrap id="${row.id}" class="btn btn-save text-light edit-btn btn-sm w-100 mb-2 d-flex flex-nowrap align-items-center justify-content-center" data-bs-toggle="modal" data-bs-target="#edit-benefactor-modal" onclick="assignData('${row.id}')">
                <i class="bi bi-pencil-square me-0 me-sm-1"></i>Edit
              </button>
              <button type="button" class="btn btn-del delete-btn btn-sm  mb-2 w-100 d-flex flex-nowrap align-items-center justify-content-center" data-id="${row.id}" onclick="archiveBenefactor(${row.id})">
                <i class="bi bi-archive me-0 me-sm-1"></i>Archive
              </button>
             
            </td>
        `;
        });

        $('#benefactor-table').DataTable({
            columnDefs: [
                { targets: [4, 5], visible: false } // Hide the 5th and 6th columns (index 4 and 5)
            ]
        });
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr class='text-center'><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };


    fetch("../php/getBenefactor.php")
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data
            displayData(data);
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}
//Modal Instance
var monitor_modal = document.getElementById('monitor-benefactor-modal');
var monitorModalInstance = new bootstrap.Modal(monitor_modal);
function dismissMonitorModal() {
    monitorModalInstance.hide();
}

function archiveBenefactor(id) {
    console.log("ID: ", id);
    var user = full_name;


    var formData = new FormData();
    formData.append('id', id);
    formData.append('user', user);

    fetch('../php/toArchiveBenefactor.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log("ETO LUMABAS" + data);

            // Check for success and handle accordingly
            if (data.success) {
                fetchBenefactor();
                const success_toast = document.getElementById('success-archive-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();
            } else {
                console.error('Error archiving benefactor:', data.error);
            }
        })
        .catch(function (error) {
            console.error('Error archiving benefactor:', error);
        });
}


function displayData(data) {
    var id = document.getElementById('benefactor-id');
    var benefactorName_edit = document.getElementById('edit-benefactor-name');
    var particular_edit = document.getElementById('edit-benefactor-particular');
    var from_edit = document.getElementById('edit-from_sy');
    var to_edit = document.getElementById('edit-to_sy');
    var semester_edit = document.getElementById('edit-benefactor-semester');
    var slot_edit = document.getElementById('edit-benefactor-slot');
    var amount_edit = document.getElementById('edit-benefactor-amount');


    data.forEach((row) => {
        id.value = `${row.id}`;
        particular_edit.value = `${row.particular}`;
        semester_edit.value = `${row.semester}`;
        benefactorName_edit.value = `${row.name}`;
        slot_edit.value = `${row.slot}`;
        amount_edit.value = `${row.amount}`
        from_edit.value = `${row.from_sy}`;
        to_edit.value = `${row.to_sy}`;

    });
}

function assignData(id) {


    console.log("ID: " + id);

    var formData = new FormData();
    formData.append('id', id);


    fetch('../php/getListBenefactor.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log("ETO LUMABAS" + data);
            displayData(data);

        })
        .catch(function (error) {
            console.error('Error assignData:', error);
        });
}

function EditBenefactor() {
    var benefactorId = document.getElementById('benefactor-id').value;
    var benefactorName_edit = document.getElementById('edit-benefactor-name').value;
    var particular_edit = document.getElementById('edit-benefactor-particular').value;
    var from_edit = parseInt(document.getElementById('edit-from_sy').value);
    var to_edit = parseInt(document.getElementById('edit-to_sy').value);
    var semester_edit = document.getElementById('edit-benefactor-semester').value;
    var slot_edit = document.getElementById('edit-benefactor-slot').value;
    var amount_edit = document.getElementById('edit-benefactor-amount').value;
    var user = full_name;




    let alert = document.getElementById('alert-error-edit');

    if (!benefactorName_edit || !particular_edit || !semester_edit || !from_edit || !to_sy) {
        // Display an error message or take appropriate action

        alert.innerHTML = '<div class="alert alert-danger" role="alert">Please fill out all required fields.</div>';
    }
    if (!/^[A-Za-z ]+$/.test(benefactorName_edit)) {
        alert.innerHTML = '<div class="alert alert-danger" role="alert">Please enter a valid benefactor with letters and spaces only.</div>';
    }
    if (to_edit <= from_edit) {
        alert.innerHTML = '<div class="alert alert-danger" role="alert">To semester must be not lower than or equal From semester.</div>';
        return; // Exit the function if to semester is not exactly 1 greater than from semester
    }
    if (to_edit != from_edit + 1) {
        alert.innerHTML = '<div class="alert alert-danger" role="alert">To semester must be exactly greater than From semester by 1 year only.</div>';
        return; // Exit the function if to semester is not exactly 1 greater than from semester
    }

    else {

        let formData = new FormData();
        formData.append('id', benefactorId);
        formData.append('particular', particular_edit);
        formData.append('semester', semester_edit);
        formData.append('name', benefactorName_edit);
        formData.append('slot', slot_edit);
        formData.append('amount', amount_edit);
        formData.append('from_sy', from_edit);
        formData.append('to_sy', to_edit);
        formData.append('user', user);

        // Send the form data to a PHP script using AJAX
        fetch('../php/toEditBenefactor.php', {
            method: 'POST',
            body: formData
        })
            .then(function (response) {
                return response.text();
            })
            .then(function (data) {
                console.log("Successful")
                console.log(data);
                // SUCCESSFULLY ADDED
                const success_toast = document.getElementById('success-edit-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();

                dismissEditModal();
                fetchBenefactor();


            })
            .catch(function (error) {
                console.error('Error:', error);
            });


    }




}

// Get a reference to the modal element
var edit_modal = document.getElementById('edit-benefactor-modal');
var EditModalInstance = new bootstrap.Modal(edit_modal);

function dismissEditModal() {
    EditModalInstance.hide();
}






function monitor() {
    var semesterOption = document.getElementById('semester').checked;

    if (semesterOption) {
        console.log('Semester selected');
        dismissMonitorModal();
        dismissConfirmModal();
        createNewSem(); // Call the function to create a new table
    } else {
        console.log('Academic Year selected');
        dismissMonitorModal();
        dismissConfirmModal();
        createNewAcadYear();
    }
}

var confirm_modal = document.getElementById('confirmationModal');
var ConfirmModalInstance = new bootstrap.Modal(confirm_modal);

function dismissConfirmModal() {
    ConfirmModalInstance.hide();
}


//Per Sem
// function createNewSem() {
//     // Inside createNewTable function
//     fetch('../php/monitorSem.php', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//             // Add any data you want to send to the backend
//         }),
//     })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             if (data.success) {
//                 fetchBenefactor();
//                 // Handle successful response
//                 console.log('Table created successfully', data.data);
//                 // SUCCESSFULLY Updated
//                 const updated_toast = document.getElementById('updated-toast');
//                 bootstrap.Toast.getOrCreateInstance(updated_toast).show();
//             } else {
//                 // Handle error response
//                 console.error('Error creating table:', data.error);

//                 // Log SQL error message to console
//                 console.error('SQL error:', data.sql_error);

//                 // Access and log the PHP error message
//                 console.error('PHP error:', data.error);
//             }
//         })
//         .catch(error => {
//             console.error('Fetch error:', error);
//         });
// }

function createNewSem() {
    // Inside createNewTable function
    fetch('../php/monitorSem.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            // Add any data you want to send to the backend
        }),
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            if (data.success) {
                // Handle successful response
                console.log('Table created successfully', data.data);
                fetchBenefactor();
                getAllEmails();
                getGraduateEmails();

                // Show success toast
                const updatedToast = document.getElementById('updated-toast');
                bootstrap.Toast.getOrCreateInstance(updatedToast).show();
            } else {
                // Handle error response
                console.error('Error creating table:', data.error);

                // Log SQL error message to console if available
                if (data.sql_error) {
                    console.error('SQL error:', data.sql_error);
                }

                // Log the PHP error message
                console.error('PHP error:', data.error);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
        });
}


// Per Acad Year
// function createNewAcadYear() {
//     // Inside createNewTable function
//     fetch('../php/monitorAcadYear.php', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//             // Add any data you want to send to the backend
//         }),
//     })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             if (data.success) {
//                 fetchBenefactor();
//                 // Handle successful response
//                 console.log('Table created successfully', data.data);
//                 // SUCCESSFULLY Updated
//                 const updated_toast = document.getElementById('updated-toast');
//                 bootstrap.Toast.getOrCreateInstance(updated_toast).show();


//             } else {
//                 // Handle error response
//                 console.error('Error creating table:', data.error);

//                 // Log SQL error message to console
//                 console.error('SQL error:', data.sql_error);

//                 // Access and log the PHP error message
//                 console.error('PHP error:', data.error);
//             }
//         })
//         .catch(error => {
//             console.error('Fetch error:', error);
//         });
// }

function createNewAcadYear() {
    // Inside createNewTable function
    fetch('../php/monitorAcadYear.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            // Add any data you want to send to the backend
        }),
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            if (data.success) {
                // Handle successful response
                console.log('Table created successfully', data.data);
                fetchBenefactor();
                getAllEmails();
                getGraduateEmails();

                // Show success toast
                const updatedToast = document.getElementById('updated-toast');
                bootstrap.Toast.getOrCreateInstance(updatedToast).show();
            } else {
                // Handle error response
                console.error('Error creating table:', data.error);

                // Log SQL error message to console if available
                if (data.sql_error) {
                    console.error('SQL error:', data.sql_error);
                }

                // Log the PHP error message
                console.error('PHP error:', data.error);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
        });
}


//Send Email when Update Sem
function getAllEmails() {
    return fetch('../php/getAllEmails.php', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    })
        .then(response => {
            console.log('Response status:', response.status); // Log the status code
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Assuming the emails are stored in an array under the 'emails' key in the response
                const emails = data.emails;

                // Loop through the emails and call sendEmail for each
                emails.forEach(email => {
                    sendEmail(email);
                });

                return emails;
            } else {
                // Handle the case where the request was successful but the response indicates an error
                throw new Error('Error getting emails: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            // Handle the error, e.g., display an error message to the user
            throw error; // Rethrow the error to be caught further up the promise chain
        });
}

function sendEmail(emails) {
    let formData = new FormData();
    formData.append('emails', emails);

    console.log("sending email to ", emails);

    fetch('../php/sendUpdateEmail.php', { // Correct the URL path
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            if (response.ok) {
                return response.text();
            } else {
                throw new Error('Failed to send email');
            }
        })
        .then(function (responseText) {
            // You can handle the responseText here if needed
            console.log('Email sent:', responseText);
        })
        .catch(function (error) {
            console.error('Error:', error);
        });
}

// Get the emails of all 4th year and send email
function getGraduateEmails() {
    return fetch('../php/getGraduateEmail.php', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    })
        .then(response => {
            console.log('Response status:', response.status); // Log the status code
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Assuming the emails are stored in an array under the 'emails' key in the response
                const emails = data.emails;
                console.log("Graduate Emails", emails);

                // Loop through the emails and call sendEmail for each
                emails.forEach(email => {
                    sendGraduateEmail(email);
                });

                return emails;
            } else {
                // Handle the case where the request was successful but the response indicates an error
                throw new Error('Error getting emails: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            // Handle the error, e.g., display an error message to the user
            throw error; // Rethrow the error to be caught further up the promise chain
        });
}


function sendGraduateEmail(emails) {
    let formData = new FormData();
    formData.append('emails', emails);

    console.log("sending Graduate Email to ", emails);

    fetch('../php/sendGraduateEmail.php', { // Correct the URL path
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            if (response.ok) {
                return response.text();
            } else {
                throw new Error('Failed to send email');
            }
        })
        .then(function (responseText) {
            // You can handle the responseText here if needed
            console.log('Email sent:', responseText);
        })
        .catch(function (error) {
            console.error('Error:', error);
        });
}





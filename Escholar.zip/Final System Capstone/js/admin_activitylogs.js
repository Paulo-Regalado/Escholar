function fetchActivityLogs() {
    $('#activitylogs-table').DataTable().destroy();

    const tableBody = document.getElementById("activitylogs-table-body");



    // Function to display data in the table
    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {


            tableBody.innerHTML += `
              <tr>

              <td>${row.admin_username}</td>
              <td>${row.activity_type}</td>
              <td>${row.description}</td>
              <td>${row.date}</td>
                
              </tr>
          `;
        });

        // Initialize DataTable with default sorting by the date column (column index 3) in descending order
        $('#activitylogs-table').DataTable({
            "order": [[3, "desc"]]
        });
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    fetch("../php/getActivityLogs.php", {
        method: 'POST',
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data

            if (Array.isArray(data.data)) {
                displayData(data.data); // Pass the "data" property of the response
            } else {
                // Handle the case where data is not an array
                handleError("Data is not an array");
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

document.addEventListener('DOMContentLoaded', () => {
    // Data retrieved from https://gs.statcounter.com/browser-market-share#monthly-202201-202201-bar

    // Create the chart
    // Highcharts.chart('total-scholars', {
    //     chart: {
    //         type: 'column'
    //     },
    //     title: {
    //         align: 'center',
    //         text: 'TOTAL SCHOLARS PER BENEFACTOR'
    //     },
    //     subtitle: {
    //         align: 'center',
    //         text: '2nd Semester AY 2022 - 2023'
    //     },
    //     accessibility: {
    //         announceNewData: {
    //             enabled: true
    //         }
    //     },
    //     xAxis: {
    //         type: 'category'
    //     },
    //     yAxis: {
    //         title: {
    //             text: 'Total numbers of scholars'
    //         }

    //     },
    //     legend: {
    //         enabled: false
    //     },
    //     plotOptions: {
    //         series: {
    //             borderWidth: 0,
    //             dataLabels: {
    //                 enabled: true,
    //                 format: '{point.y}'
    //             }
    //         }
    //     },

    //     tooltip: {
    //         headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
    //         pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
    //     },

    //     series: [
    //         {
    //             name: 'Benefactor',
    //             colorByPoint: true,
    //             data: [
    //                 {
    //                     name: 'Kuya Win Scholarship',
    //                     y: 63,
    //                 },
    //                 {
    //                     name: 'TDP',
    //                     y: 19,
    //                 },
    //                 {
    //                     name: 'Metro Ched',
    //                     y: 4,
    //                 }
    //             ]
    //         }
    //     ]
    // });


    // Fetch data using the Fetch API
    fetch('../php/getScholarsReport.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            Highcharts.chart('total-scholars', {
                chart: {
                    type: 'column'
                },
                title: {
                    align: 'center',
                    text: 'TOTAL SCHOLARS PER BENEFACTOR'
                },
                subtitle: {
                    align: 'center',
                    text: ''
                },
                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total numbers of scholars'
                    }

                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    series: {
                        borderWidth: 0,
                        dataLabels: {
                            enabled: true,
                            format: '{point.y}'
                        }
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },

                series: [
                    {
                        name: 'Benefactor',
                        colorByPoint: true,
                        data: data
                    }
                ]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });






    //Get Scholars Per Campus
    fetch('../php/getScholarsPerCampus.php') // Update the URL to the correct endpoint
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            Highcharts.chart('scholars-per-campus', {
                chart: {
                    type: 'pie'
                },
                title: {
                    align: 'center',
                    text: 'TOTAL SCHOLARS PER CAMPUS' // Update chart title
                },

                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total scholars per campus'
                    }
                },
                legend: {
                    enabled: true, // Enable legend for pie chart
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                        }
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },
                // ... (rest of the Highcharts configuration remains the same)

                // Add or update the series data with the fetched data
                series: [{
                    name: 'Total Scholars Per Campus',
                    colorByPoint: true,
                    data: data // Use the actual property from your data
                }]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });

    //Get Employment Status
    fetch('../php/getEmployment.php') // Update the URL to the correct endpoint
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            Highcharts.chart('graduate-status', {
                chart: {
                    type: 'pie'
                },
                title: {
                    align: 'center',
                    text: 'TOTAL GRADUATE EMPLOYMENT STATUS' // Update chart title
                },

                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total numbers per Employment'
                    }
                },
                legend: {
                    enabled: true, // Enable legend for pie chart
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                        }
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },
                // ... (rest of the Highcharts configuration remains the same)

                // Add or update the series data with the fetched data
                series: [{
                    name: 'Total Number Per Employment',
                    colorByPoint: true,
                    data: data // Use the actual property from your data
                }]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });


    //Get Benefactor Count
    fetch('../php/getBenefactorCount.php') // Update the URL to the correct endpoint
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            Highcharts.chart('benefactor', {
                chart: {
                    type: 'pie'


                },
                title: {
                    align: 'center',
                    text: 'TOTAL NUMBER OF BENEFACTOR' // Update chart title
                },

                accessibility: {
                    announceNewData: {
                        enabled: false
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total numbers of Benefactor'
                    }
                },
                legend: {
                    enabled: true, // Enable legend for pie chart
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                        }
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },
                // ... (rest of the Highcharts configuration remains the same)

                // Add or update the series data with the fetched data
                series: [{
                    name: 'Total Number of Benefactor',
                    colorByPoint: true,
                    data: data // Use the actual property from your data
                }]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });



});



//Print Functions
$(document).ready(function () {
    $('#print').click(function () {
        var employmentStatus = $('#employmentStatusSelect').val();

        // Check if employmentStatus is the default value "Employment Status"
        if (employmentStatus === "Employment Status" || employmentStatus === null) {
            // Display failed modal
            const failed_toast = document.getElementById('failed-toast');
            bootstrap.Toast.getOrCreateInstance(failed_toast).show();
        } else {
            // If employmentStatus is not the default value, proceed with the AJAX request
            console.log(employmentStatus); // Log the selected value
            $.post('../php/printGraduate.php', { employmentStatus: employmentStatus }, function (data) {
                // Trigger a download of the generated CSV file
                var link = document.createElement('a');
                link.href = 'data:text/csv;charset=utf-8,' + encodeURI(data);
                link.target = '_blank';
                link.download = 'graduate_data.csv';
                link.click();
                dismissModal();
                document.getElementById('graduateSelect').reset();
                // Display success modal
                const succes_toast = document.getElementById('success-toast');
                bootstrap.Toast.getOrCreateInstance(succes_toast).show();
            });
        }
    });
});



var graduate_modal = document.getElementById('graduateModal');
var graduateModalInstance = new bootstrap.Modal(graduate_modal);
function dismissModal() {

    graduateModalInstance.hide();
}
//Graduates

//Per Campus Scholars
$(document).ready(function () {
    $('#campusPrint').click(function () {
        var campusStatus = $('#campusSelect').val();

        // Check if employmentStatus is the default value "Employment Status"
        if (campusStatus === "Campus Status" || campusStatus === null) {
            // Display failed modal
            const failed_toast = document.getElementById('failed-toast');
            bootstrap.Toast.getOrCreateInstance(failed_toast).show();
        } else {
            // If employmentStatus is not the default value, proceed with the AJAX request
            console.log(campusStatus);
            // Make an AJAX request to the export.php script
            $.post('../php/printPerCampus.php', { campusStatus: campusStatus }, function (data) {
                // Trigger a download of the generated CSV file
                var link = document.createElement('a');
                link.href = 'data:text/csv;charset=utf-8,' + encodeURI(data);
                link.target = '_blank';
                link.download = 'scholars_per_campus_data.csv';
                link.click();
                dismissCampusModal();
                document.getElementById('perCampusSelect').reset();
                // Display success modal
                const succes_toast = document.getElementById('success-toast');
                bootstrap.Toast.getOrCreateInstance(succes_toast).show();

            });


        }


    });
});

var campus_modal = document.getElementById('perCampusModal');
var campusModalInstance = new bootstrap.Modal(campus_modal);
function dismissCampusModal() {

    campusModalInstance.hide();
}
//Per Campus Scholars

//Benefactor
$(document).ready(function () {
    $('#benefactorPrint').click(function () {
        var benefactorStatus = $('#benefactorSelect').val();

        // Check if employmentStatus is the default value "Employment Status"
        if (benefactorStatus === "Benefactor" || benefactorStatus === null) {
            // Display failed modal
            const failed_toast = document.getElementById('failed-toast');
            bootstrap.Toast.getOrCreateInstance(failed_toast).show();
        } else {
            // If employmentStatus is not the default value, proceed with the AJAX request
            console.log(benefactorStatus);
            // Make an AJAX request to the export.php script
            $.post('../php/printBenefactorParticular.php', { benefactorStatus: benefactorStatus }, function (data) {
                // Trigger a download of the generated CSV file
                var link = document.createElement('a');
                link.href = 'data:text/csv;charset=utf-8,' + encodeURI(data);
                link.target = '_blank';
                link.download = 'benefactor_particulars_data.csv';
                link.click();
                dismissBenefactorModal();
                document.getElementById('benefactorFormSelect').reset();
                // Display success modal
                const succes_toast = document.getElementById('success-toast');
                bootstrap.Toast.getOrCreateInstance(succes_toast).show();

            });


        }


    });
});

var benefactormodal = document.getElementById('benefactorModal');
var benefactorModalInstance = new bootstrap.Modal(benefactormodal);
function dismissBenefactorModal() {

    benefactorModalInstance.hide();
}
//Benefactor

//Scholars Per Benefactor
$(document).ready(function () {
    $('#perScholarsPrint').click(function () {
        var benefactor = $('#perScholarsSelect').val();

        // Check if employmentStatus is the default value "Employment Status"
        if (benefactor === "Benefactor" || benefactor === null) {
            // Display failed modal
            const failed_toast = document.getElementById('failed-toast');
            bootstrap.Toast.getOrCreateInstance(failed_toast).show();
        } else {
            // If employmentStatus is not the default value, proceed with the AJAX request
            console.log(benefactor);
            // Make an AJAX request to the export.php script
            $.post('../php/printScholarsPerBenefactor.php', { benefactor: benefactor }, function (data) {
                // Trigger a download of the generated CSV file
                var link = document.createElement('a');
                link.href = 'data:text/csv;charset=utf-8,' + encodeURI(data);
                link.target = '_blank';
                link.download = 'scholars_per_benefactor_data.csv';
                link.click();
                dismissPerScholarsModal();
                document.getElementById('perScholarsFormSelect').reset();
                // Display success modal
                const succes_toast = document.getElementById('success-toast');
                bootstrap.Toast.getOrCreateInstance(succes_toast).show();

            });


        }


    });
});

var perscholarsmodal = document.getElementById('perScholarsModal');
var perscholarsModalInstance = new bootstrap.Modal(perscholarsmodal);
function dismissPerScholarsModal() {

    perscholarsModalInstance.hide();
}
//Scholars Per Benefactor






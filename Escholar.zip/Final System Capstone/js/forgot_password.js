
// SEARCH STUDENT NO.+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function searchStudentNo() {
    var studNo = document.getElementById("student_number").value;
    var studNoInput = document.getElementById("student_number");
    var result = document.getElementById("result");
    var sendBtn = document.getElementById("sendBtn");

    if (studNo.length != 10) {
        studNoInput.classList.remove('is-valid');
        studNoInput.classList.add('is-invalid');

        result.classList.remove('valid-feedback');
        result.classList.add('invalid-feedback');
        document.getElementById('result').innerText = "Please enter a correct student number!";

        // Disable the "Send OTP" button
        sendBtn.disabled = true;
    } else {
        // Show the loading indicator
        document.getElementById("loader").style.display = "inline";

        var formData = new FormData();
        formData.append('student_number', studNo);

        fetch('../php/checkRegistered.php', { // Replace 'your_php_script.php' with the actual path to your PHP script
            method: 'POST',
            body: formData
        })
            .then(function (response) {
                return response.text();
            })
            .then(function (data) {

                console.log('data is:', data);
                // Display the response from the PHP script
                document.getElementById("loader").style.display = "none";

                if (data === "not registered") {
                    studNoInput.classList.remove('is-valid');
                    studNoInput.classList.add('is-invalid');

                    result.classList.remove('valid-feedback');
                    result.classList.add('invalid-feedback');

                    document.getElementById('result').innerText = studNo + " is not registered";
                    // Disable the "Send OTP" button
                    sendBtn.disabled = true;
                } else if (data === "registered") {
                    studNoInput.classList.remove('is-invalid');
                    studNoInput.classList.add('is-valid');

                    result.classList.remove('invalid-feedback');
                    result.classList.add('valid-feedback');

                    document.getElementById('result').innerText = studNo + " is registered";
                    // Enable the "Send OTP" button
                    sendBtn.disabled = false;
                }
                else {
                    // Handle other cases as needed
                    console.log('Data:', data);
                }
            })
            .catch(function (error) {
                console.error('Error:', error);
            });
    }
}

//To copy the studentno input from the first form 
function copyStudentNumber() {
    // Get the student_number value from the visible form field
    const studentNumberField = document.getElementById('student_number');
    const studentNumberValue = studentNumberField.value;

    // Set the student_number value in the hidden input field in the password_form
    const passwordFormStudentNumberField = document.getElementById('password_form_student_number');
    passwordFormStudentNumberField.value = studentNumberValue;
}

//Password Validation
function validatePasswordMatch() {
    var password = document.getElementById("password");
    var conPassword = document.getElementById("con_password");
    var passwordResult = document.getElementById("password_result");

    if (password.value !== conPassword.value) {
        passwordResult.innerHTML = "Password do not match";
        passwordResult.classList.add("text-danger");
        document.getElementById("submit-btn").disabled = true;
    } else {
        passwordResult.innerHTML = "Password match";
        passwordResult.classList.remove("text-danger");
        passwordResult.classList.add("text-success");
        document.getElementById("submit-btn").disabled = false;
    }
}
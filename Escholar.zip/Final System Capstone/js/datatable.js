new DataTable('#table-benefactor');
// new DataTable('#pending-table');

// $(document).ready(function () {
//     $('#pending-table').DataTable(); // Replace 'pending-table' with the actual ID of your table
//   });
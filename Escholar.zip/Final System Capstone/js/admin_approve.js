
var full_name;
function actLogs(firstname, lastname) {

    full_name = firstname + ' ' + lastname;

}
function fetchTableCount(table_name) {
    const tableBody = document.getElementById("benefactor-table-body");

    const displayData = (data) => {
        // Update the counts in HTML spans
        document.getElementById("complete-count").innerText = data.approved_count || 0;
        document.getElementById("process-count").innerText = data.processed_count || 0;
        document.getElementById("claim-count").innerText = data.claim_count || 0;
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr class='text-center'><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    var formData = new FormData();
    formData.append('table-name', table_name);

    fetch("../php/getTableCount.php", {
        method: 'POST',
        body: formData
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            //console.log("Received data:", data); // Log received data
            displayData(data);
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}




function fetchApproveScholars(table_name) {
    $('#approve-table').DataTable().destroy();
    console.log(table_name);
    const tableBody = document.getElementById("approve-table-body");
    const nextProcessButton = document.getElementById("toProcess");

    nextProcessButton.disabled = true;

    // Function to display data in the table

    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            tableBody.innerHTML += `
                <tr>
                    <td><input type="checkbox" class="select-checkbox"></td>
                    <td>${row.student_number}</td>
                    <td>${row.last_name}</td>
                    <td>${row.first_name}</td>
                    <td>${row.middle_name}</td>
                    <td>${row.email}</td>
                    <td>${row.contact}</td>
                    <td>${row.campus}</td>
                    <td>${row.college}</td>
                    <td nowrap>${row.course}</td>
                    <td>${row.year_level}</td>
                    <td>${row.gwa}</td>
                    <td>${row.units}</td>
                </tr>
            `;
        });

        // Enable multiple selection with checkboxes
        const dataTable = $('#approve-table').DataTable({
            select: {
                style: 'multi',
                selector: 'td:first-child input[type="checkbox"]',
            },
            searching: true,
            language: {
                info: "Showing _START_ to _END_ of _TOTAL_ entries "
            }
        });

        // Add an event listener to handle row selection changes
        dataTable.on('select', function (e, dt, type, indexes) {
            // You can access the selected rows using dt.rows({ selected: true }) API
            const selectedRows = dt.rows({ selected: true }).data();
            console.log("Selected Rows:", selectedRows);
            // Update button state based on selectedRows
            nextProcessButton.disabled = selectedRows.length === 0;
            // Call the onChange function
            onChange(selectedRows.length);


        });

        // Add an event listener to handle row deselection changes
        dataTable.on('deselect', function (e, dt, type, indexes) {
            // You can access the selected rows using dt.rows({ selected: true }) API
            const selectedRows = dt.rows({ selected: true }).data();
            console.log("Selected Rows:", selectedRows);
            // Update button state based on selectedRows
            nextProcessButton.disabled = selectedRows.length === 0;
            // Call the onChange function
            onChange(selectedRows.length);
        });

        // Add an event listener to the "Select All" checkbox in the thead
        $('#selectAllApprove').on('change', function () {
            const checkboxes = dataTable.rows().nodes().to$().find('td:first-child input[type="checkbox"]');

            if (this.checked) {
                console.log("Select All checkbox checked");
                dataTable.rows().select();
                checkboxes.prop('checked', true); // Check all checkboxes in the selected rows
            } else {
                console.log("Select All checkbox unchecked");
                dataTable.rows().deselect();
                checkboxes.prop('checked', false); // Uncheck all checkboxes
                nextProcessButton.disabled = true;

            }
        });

        // Function to handle the change in selected rows count
        const onChange = (selectedCount) => {
            // Disable the nextProcessButton if the selected rows count is 0
            console.log("onchangeselect: ", selectedCount);
            nextProcessButton.disabled = selectedCount === 0;
        };


    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='13'>An error occurred while fetching data.</td></tr>";
    };

    var formData = new FormData();
    formData.append('table-name', table_name);

    // AJAX fetch request
    fetch("../php/getApprovedScholars.php", {
        method: 'POST',
        body: formData
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data
            displayData(data);
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}
function fetchProcessedScholars(table_name) {
    $('#processed-table').DataTable().destroy();
    console.log(table_name);
    const tableBody = document.getElementById("processed-table-body");
    const nextClaimButton = document.getElementById("toClaim");

    nextClaimButton.disabled = true;

    // Function to display data in the table

    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            tableBody.innerHTML += `
                <tr>
                  <td><input type="checkbox" class="select-checkbox"></td>
                  <td>${row.student_number}</td>
                  <td>${row.last_name}</td>
                  <td>${row.first_name}</td>
                  <td>${row.middle_name}</td>
                  <td>${row.email}</td>
                  <td>${row.contact}</td>
                  <td>${row.campus}</td>
                  <td>${row.college}</td>
                  <td nowrap>${row.course}</td>
                  <td>${row.year_level}</td>
                  <td>${row.gwa}</td>
                  <td>${row.units}</td>
                </tr>
            `;
        });


        // Enable multiple selection
        const dataTable = $('#processed-table').DataTable({
            select: {
                style: 'multi',
                selector: 'td:first-child input[type="checkbox"]',
            },
            searching: true,
            language: {
                info: "Showing _START_ to _END_ of _TOTAL_ entries "
            }

        });

        // Add an event listener to handle row selection changes
        dataTable.on('select', function (e, dt, type, indexes) {
            // You can access the selected rows using dt.rows({ selected: true }) API
            const selectedRows = dt.rows({ selected: true }).data();
            console.log("Selected Rows:", selectedRows);
            nextClaimButton.disabled = selectedRows.length === 0;
            // Call the onChange function
            onChange(selectedRows.length);

        });

        // Add an event listener to handle row deselection changes
        dataTable.on('deselect', function (e, dt, type, indexes) {
            // You can access the selected rows using dt.rows({ selected: true }) API
            const selectedRows = dt.rows({ selected: true }).data();
            console.log("Selected Rows:", selectedRows);
            // Update button state based on selectedRows
            nextClaimButton.disabled = selectedRows.length === 0;
            // Call the onChange function
            onChange(selectedRows.length);
        });

        // Add an event listener to the "Select All" checkbox in the thead
        $('#selectAllProcess').on('change', function () {
            console.log("Change event triggered for Select All checkbox");
            const checkboxes = dataTable.rows().nodes().to$().find('td:first-child input[type="checkbox"]');

            if (this.checked) {
                console.log("Select All checkbox checked");
                dataTable.rows().select();
                checkboxes.prop('checked', true); // Check all checkboxes in the selected rows
            } else {
                console.log("Select All checkbox unchecked");
                dataTable.rows().deselect();
                checkboxes.prop('checked', false); // Uncheck all checkboxes
                nextClaimButton.disabled = true;
            }
        });

        // Function to handle the change in selected rows count
        const onChange = (selectedCount) => {
            // Disable the nextProcessButton if the selected rows count is 0
            console.log("onchangeselect: ", selectedCount);
            nextClaimButton.disabled = selectedCount === 0;
        };



    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    var formData = new FormData();
    formData.append('table-name', table_name);

    // AJAX fetch request
    fetch("../php/getProcessedScholars.php", {
        method: 'POST',
        body: formData
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            // console.log("Received data:", data); // Log received data
            displayData(data);
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

function fetchClaimScholars(table_name) {
    $('#claim-table').DataTable().destroy();
    console.log(table_name);
    nameTable = table_name;
    const tableBody = document.getElementById("claim-table-body");

    // Function to display data in the table

    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data
        data.forEach((row) => {
            tableBody.innerHTML += `
                <tr>
                  <td><input type="checkbox" class="select-checkbox"></td>
                  <td>${row.student_number}</td>
                  <td>${row.last_name}</td>
                  <td>${row.first_name}</td>
                  <td>${row.middle_name}</td>
                  <td>${row.email}</td>
                  <td>${row.contact}</td>
                  <td>${row.campus}</td>
                  <td>${row.college}</td>
                  <td nowrap>${row.course}</td>
                  <td>${row.year_level}</td>
                  <td>${row.gwa}</td>
                  <td>${row.units}</td>
                </tr>
            `;
        });



        // Enable multiple selection
        const dataTable = $('#claim-table').DataTable({
            select: {
                style: 'multi',
                selector: 'td:first-child input[type="checkbox"]',
            },
            searching: true,
            language: {
                info: "Showing _START_ to _END_ of _TOTAL_ entries "
            }


        });
        // Add an event listener to the "Select All" checkbox in the thead
        $('#selectAllClaim').on('change', function () {
            console.log("Change event triggered for Select All checkbox");
            const checkboxes = dataTable.rows().nodes().to$().find('td:first-child input[type="checkbox"]');

            if (this.checked) {
                console.log("Select All checkbox checked");
                dataTable.rows().select();
                checkboxes.prop('checked', true); // Check all checkboxes in the selected rows
            } else {
                console.log("Select All checkbox unchecked");
                dataTable.rows().deselect();
                checkboxes.prop('checked', false); // Uncheck all checkboxes

            }
        });



    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    var formData = new FormData();
    formData.append('table-name', table_name);

    // AJAX fetch request
    fetch("../php/getClaimScholars.php", {
        method: 'POST',
        body: formData
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            //console.log("Received data:", data); // Log received data
            displayData(data);
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

// Attach CSV export functionality to your existing button
const exportButton = document.getElementById("exportToCSVButton");
exportButton.addEventListener("click", () => {
    // Get the DataTable API instance
    const dataTable = $('#claim-table').DataTable();

    // Extract the part of the table name before the last underscore
    const lastUnderscoreIndex = nameTable.lastIndexOf('_');
    const displayName = lastUnderscoreIndex !== -1 ? nameTable.substring(0, lastUnderscoreIndex) : nameTable;
    // Replace remaining underscores with spaces
    const formattedName = displayName.replace(/_/g, ' ');


    // Get the selected rows from the DataTable
    const selectedRows = dataTable.rows({ selected: true }).data();

    // Check if there are selected rows
    if (selectedRows.length === 0) {
        const success_move_toast = document.getElementById('select-failed-toast');
        bootstrap.Toast.getOrCreateInstance(success_move_toast).show();

        return; // Do not proceed with download
    }

    // Get the DataTable headers (thead)
    const headers = dataTable.columns().header().toArray().map(header => header.textContent);

    // Find the index of the first column to exclude (checkbox column)
    const excludeIndex = headers.indexOf('');

    // Exclude the first column from both headers and data
    const filteredHeaders = headers.filter((header, index) => index !== excludeIndex);
    const filteredData = selectedRows.toArray().map(row => Array.from(row).filter((cell, index) => index !== excludeIndex));

    // Create a CSV string that includes filtered headers and data
    const csvContent = [filteredHeaders.join(','), ...filteredData.map(row => row.join(','))].join('\n');

    // Create and trigger the CSV download
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = `Claimed_${formattedName}_Scholars.csv`;
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    document.body.removeChild(a);
});

// Export to PDF
function exportToPDF() {
    console.log("pindot");

    // Get the DataTable API instance
    const dataTable = $('#claim-table').DataTable();

    // Get the selected rows from the DataTable
    const selectedRows = dataTable.rows({ selected: true }).data();

    // Check if there are selected rows
    if (selectedRows.length === 0) {
        const success_move_toast = document.getElementById('select-failed-toast');
        bootstrap.Toast.getOrCreateInstance(success_move_toast).show();

        return; // Do not proceed with export
    }

    // Create a new jsPDF instance
    const doc = new jsPDF('landscape');

    // Extract the part of the table name before the last underscore
    const lastUnderscoreIndex = nameTable.lastIndexOf('_');
    const displayName = lastUnderscoreIndex !== -1 ? nameTable.substring(0, lastUnderscoreIndex) : nameTable;
    // Replace remaining underscores with spaces
    const formattedName = displayName.replace(/_/g, ' ');

    // Set the title for the PDF
    doc.text(`Claimed - ${formattedName}`, 10, 10);

    // Define the columns to be included in the PDF
    const columns = ["Student No.", "Surname", "Firstname", "M.I", "Email", "Contact", "Campus", "College", "Course", "Year"];
    const data = [];

    // Iterate through the selected rows and add data to the PDF
    selectedRows.each(function (rowData) {
        // Exclude the first column (checkbox column) from the data
        data.push(rowData.slice(1));
    });

    // Generate the table in the PDF using jspdf-autotable
    doc.autoTable({
        head: [columns],
        body: data,
        // Use "auto" for column width to let the plugin automatically adjust
        columnStyles: {
            0: { cellWidth: 'auto' },
            1: { cellWidth: 'auto' }, 2: { cellWidth: 'auto' }
        },
        margin: { top: 20 },  // Add margin to ensure content is not too close to the top
    });

    // Save the PDF with a file name
    doc.save(`Claimed_${formattedName}_Scholars.pdf`);
}


function moveToProcess(table_name, email, fname, lname, approve_studNo) {



    var user = full_name;
    // Create a FormData object to send the form data
    let formData = new FormData();
    formData.append('table-name', table_name);
    formData.append('approve-studNo', approve_studNo);
    formData.append('user', user);

    fetch('../php/toProcessScholar.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.text();
        })
        .then(function (data) {

            // SUCCESSFULLY ADDED
            const success_move_toast = document.getElementById('success-move-toast');
            bootstrap.Toast.getOrCreateInstance(success_move_toast).show();

            sendEmailProcess(email, fname, lname);
            fetchApproveScholars(table_name);
            fetchProcessedScholars(table_name);
            fetchClaimScholars(table_name);
            fetchTableCount(table_name);




        })
        .catch(function (error) {
            console.error('Error:', error);

            const failed_move_toast = document.getElementById('failed-move-toast');
            bootstrap.Toast.getOrCreateInstance(failed_move_toast).show();
        });
}


// Function to move selected rows to process
function moveSelectedToProcess(table_name) {
    // Get the DataTable instance
    console.log("Table Name: ", table_name);
    var dataTable = $('#approve-table').DataTable(); // Replace 'yourDataTableID' with your actual DataTable ID

    // Get the selected rows using DataTable's API
    var selectedRows = dataTable.rows('.selected').data().toArray();
    var selectedCount = selectedRows.length; // Count of selected rows
    var user = full_name;

    if (selectedRows.length === 0) {
        // No rows are selected, handle this case if needed
        console.log("No rows selected.");
        const failed_move_toast = document.getElementById('failed-move-toast');
        bootstrap.Toast.getOrCreateInstance(failed_move_toast).show();
        return;
    }
    console.log("Selected Data to Passed:", selectedRows);

    // Create an array to store the selected student numbers
    const selectedStudentNumbers = selectedRows.map(row => row[0]); // Assuming student numbers are in the second column

    // Create a FormData object to send the form data
    let formData = new FormData();
    formData.append('table-name', table_name);
    formData.append('user', user);
    formData.append('selectedCount', selectedCount);

    // Initialize arrays to store email, fname, and lname
    const selectedEmails = [];
    const selectedFnames = [];
    const selectedLnames = [];

    selectedRows.forEach(row => {
        // Exclude the first element (checkbox) and start from index 1
        selectedEmails.push(row.slice(1)[4]); // Assuming email is in the second column
        selectedFnames.push(row.slice(1)[2]); // Assuming fname is in the third column
        selectedLnames.push(row.slice(1)[1]); // Assuming lname is in the fourth column
    });

    // Append each selected student number as a separate field
    selectedStudentNumbers.forEach((studentNumber, index) => {
        // Assuming studentNumber is a single value and index 1 corresponds to the second column
        const valueFromSecondColumn = selectedRows[index][1];

        formData.append('approve-studNo[]', valueFromSecondColumn);
        console.log("Approve: ", valueFromSecondColumn);
    });
    // Now, call the EmailProcess function with the selected email, fname, and lname for each row
    selectedEmails.forEach((email, index) => {
        const fname = selectedFnames[index];
        const lname = selectedLnames[index];
        sendEmailProcess(email, fname, lname);
        console.log("Sending Process Email to Selected");
    });

    // Append all selected rows as JSON
    formData.append('selectedRows', JSON.stringify(selectedRows));

    fetch('../php/toMoveSelectedToProcess.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.text();
        })
        .then(function (data) {
            // SUCCESSFULLY ADDED
            const success_move_toast = document.getElementById('success-move-toast');
            bootstrap.Toast.getOrCreateInstance(success_move_toast).show();

            // Fetch other data as needed
            fetchApproveScholars(table_name);
            fetchProcessedScholars(table_name);
            fetchClaimScholars(table_name);
            fetchTableCount(table_name);
            dismissToProcessModal();
        })
        .catch(function (error) {
            console.error('Error:', error);

            const failed_move_toast = document.getElementById('failed-move-toast');
            bootstrap.Toast.getOrCreateInstance(failed_move_toast).show();
        });
}
//Hide the Confirmation for move to Process
var toProcess_modal = document.getElementById('toProcessModal');
var ToProcessModalInstance = new bootstrap.Modal(toProcess_modal);


function dismissToProcessModal() {
    ToProcessModalInstance.hide();
}



function moveToClaim(table_name, email, fname, lname, studNo) {
    var user = full_name;
    // Create a FormData object to send the form data
    let formData = new FormData();
    formData.append('table-name', table_name);
    formData.append('approve-studNo', studNo);
    formData.append('user', user);

    fetch('../php/toClaimScholar.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.text();
        })
        .then(function (data) {

            // SUCCESSFULLY ADDED
            const success_move_toast = document.getElementById('success-move-toast');
            bootstrap.Toast.getOrCreateInstance(success_move_toast).show();
            sendEmailClaim(email, fname, lname);
            fetchApproveScholars(table_name);
            fetchProcessedScholars(table_name);
            fetchClaimScholars(table_name);
            fetchTableCount(table_name);



        })
        .catch(function (error) {
            console.error('Error:', error);

            const failed_move_toast = document.getElementById('failed-move-toast');
            bootstrap.Toast.getOrCreateInstance(failed_move_toast).show();
        });
}

// Function to move selected rows to claim
function moveSelectedToClaim(table_name) {
    // Get the DataTable instance
    console.log("Table Name: ", table_name);
    var dataTable = $('#processed-table').DataTable(); // Replace 'yourDataTableID' with your actual DataTable ID

    // Get the selected rows using DataTable's API
    var selectedRows = dataTable.rows('.selected').data().toArray();
    var selectedCount = selectedRows.length; // Count of selected rows
    var user = full_name;


    if (selectedRows.length === 0) {
        // No rows are selected, handle this case if needed
        console.log("No rows selected.");
        const failed_move_toast = document.getElementById('failed-move-toast');
        bootstrap.Toast.getOrCreateInstance(failed_move_toast).show();
        return;
    }
    console.log("Selected Data to Passed:", selectedRows);

    // Create an array to store the selected student numbers
    const selectedStudentNumbers = selectedRows.map(row => row[0]); // Assuming student numbers are in the second column

    // Create a FormData object to send the form data
    let formData = new FormData();
    formData.append('table-name', table_name);
    formData.append('user', user);
    formData.append('selectedCount', selectedCount);


    // Initialize arrays to store email, fname, and lname
    const selectedEmails = [];
    const selectedFnames = [];
    const selectedLnames = [];

    // Extract email, fname, and lname from selected rows
    selectedRows.forEach(row => {
        // Exclude the first element (checkbox) and start from index 1
        selectedEmails.push(row.slice(1)[4]); // Assuming email is in the second column
        selectedFnames.push(row.slice(1)[2]); // Assuming fname is in the third column
        selectedLnames.push(row.slice(1)[1]); // Assuming lname is in the fourth column
    });

    // Append each selected student number as a separate field
    selectedStudentNumbers.forEach((studentNumber, index) => {
        // Assuming studentNumber is a single value and index 1 corresponds to the second column
        const valueFromSecondColumn = selectedRows[index][1];

        formData.append('approve-studNo[]', valueFromSecondColumn);
        console.log("Approve: ", valueFromSecondColumn);
    });
    // Now, call the EmailClaim function with the selected email, fname, and lname
    selectedEmails.forEach((email, index) => {
        const fname = selectedFnames[index];
        const lname = selectedLnames[index];
        sendEmailClaim(email, fname, lname);

        console.log("Sending Claim Email to Selected ");
    });


    // Append all selected rows as JSON
    formData.append('selectedRows', JSON.stringify(selectedRows));

    fetch('../php/toMoveSelectedToClaim.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.text();
        })
        .then(function (data) {
            // SUCCESSFULLY ADDED
            const success_move_toast = document.getElementById('success-move-toast');
            bootstrap.Toast.getOrCreateInstance(success_move_toast).show();

            // Fetch other data as needed
            fetchApproveScholars(table_name);
            fetchProcessedScholars(table_name);
            fetchClaimScholars(table_name);
            fetchTableCount(table_name);
            dismissToClaimModal();
        })
        .catch(function (error) {
            console.error('Error:', error);

            const failed_move_toast = document.getElementById('failed-move-toast');
            bootstrap.Toast.getOrCreateInstance(failed_move_toast).show();
        });
}

//Hide the Confirmation for move to Claim
var toClaim_modal = document.getElementById('toClaimModal');
var ToClaimModalInstance = new bootstrap.Modal(toClaim_modal);


function dismissToClaimModal() {
    ToClaimModalInstance.hide();
}


//Export CSV
function convertToCSV(data) {
    const csvArray = [];

    // Add CSV header
    const header = [
        "Student Number",
        "Last Name",
        "First Name",
        "Middle Name",
        "Email",
        "Contact",
        "Campus",
        "College",
        "Course",
        "Year Level",
        "GWA",
        "Units"
    ];
    csvArray.push(header.join(','));

    // Add data rows
    data.forEach((row) => {
        const rowData = [
            row.student_number,
            row.last_name,
            row.first_name,
            row.middle_name,
            row.email,
            row.contact,
            row.campus,
            row.college,
            row.course,
            row.year_level,
            row.gwa,
            row.units
        ];
        csvArray.push(rowData.join(','));
    });

    return csvArray.join('\n');
}








// IMPORT PENDING SCHOLARS+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function importApprovedScholar(table_name) {
    var fileInput = document.getElementById('excel-file');
    var file = fileInput.files[0]; // Assuming it's a single file input
    var user = full_name;

    let formData = new FormData();
    formData.append('table-name', table_name);
    formData.append('excel-file', file);
    formData.append('user', user);
    console.log("Data", formData);

    // Send the form data to a PHP script using AJAX
    fetch('../php/toImportApproved.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json(); // assuming the response is in JSON format
        })
        .then(function (responseData) {

            console.log(responseData);


            // Check if the response indicates success
            if (responseData.success) {
                // Parse the JSON response to get the skipped record count and imported records
                var skippedRecordCount = responseData.skippedRecordCount;
                var importedRecords = responseData.recordsData; // Use 'recordsData' here
                var addedRecordCount = responseData.AddedRecordCount;
                var failed = responseData.error;

                if (failed === "Incorrect Column Format") {

                    // Display failed modal
                    const failed_toast = document.getElementById('failed-toast');
                    bootstrap.Toast.getOrCreateInstance(failed_toast).show();
                    dismissImportModal();
                    document.getElementById('import-approved-form').reset();

                }
                else if (failed === "Incorrect Data Format") {
                    // Display failed modal
                    const incorrect_toast = document.getElementById('incorrect-toast');
                    bootstrap.Toast.getOrCreateInstance(incorrect_toast).show();
                    dismissImportModal();
                    document.getElementById('import-approved-form').reset();

                }
                else {

                    // SUCCESSFULLY ADDED
                    const success_toast = document.getElementById('success-add-toast');
                    bootstrap.Toast.getOrCreateInstance(success_toast).show();
                    dismissImportModal();

                    // Display the response from the PHP script
                    document.getElementById('alert-result').innerHTML = responseData.text;




                    // console.log("afaaf", failed);
                    // Use the skippedRecordCount as needed
                    console.log("Skipped Record Count: " + skippedRecordCount);
                    document.getElementById('record-count').textContent = skippedRecordCount;
                    document.getElementById('added-count').textContent = addedRecordCount;

                    // Check if importedRecords is defined and an array
                    if (Array.isArray(importedRecords)) {
                        // Extract email, first name, and last name from the response
                        var importedEmails = [];
                        var importedFirstNames = [];
                        var importedLastNames = [];

                        importedRecords.forEach(function (record) {
                            importedEmails.push(record.email);
                            importedFirstNames.push(record.firstname);
                            importedLastNames.push(record.lastname);

                            // Send email for each record
                            // let emailbody = ApproveEmailBody([record.firstname], [record.lastname]);
                            sendEmailApproveAdd([record.email], [record.firstname], [record.lastname]);

                        });
                    } else {
                        console.error('importedRecords is not defined or not an array');
                    }

                    // Check if skippedRecordCount is greater than 0
                    if (skippedRecordCount > 0) {
                        const success_toast = document.getElementById('skipped-toast');
                        bootstrap.Toast.getOrCreateInstance(success_toast).show();
                    }

                    document.getElementById('import-approved-form').reset();
                    fetchTableCount(table_name);
                    fetchApproveScholars(table_name);

                }




            }

        })
        .catch(function (error) {
            console.error('Error:', error);
        });
}

// IMPORT PENDING SCHOLARS+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

var collegeSelect = document.getElementById("add-college");
var courseSelect = document.getElementById("add-course");
// const table = new DataTable('#pending-table');

// $(document).ready(function () {
//   $('#pending-table').DataTable(); // Replace '#example' with your table's ID or selector
// });

courseSelect.disabled = true;

function changeCollege() {
    // Clear existing options in the course dropdown
    courseSelect.innerHTML = "";


    // Populate the course dropdown based on the selected college
    var selectedCollege = collegeSelect.value;
    if (selectedCollege === "CAFA") {
        var courses = [
            "Bachelor of Science in Architecture",
            "Bachelor of Landscape Architecture",
            "Bachelor of Fine Arts Major in Visual Communication"
        ];

        var courseIds = [
            "BSA",
            "BLA",
            "BFA"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CAL") {
        var courses = [
            "Bachelor of Arts in Broadcasting",
            "Bachelor of Arts in Journalism",
            "Bachelor of Performing Arts (Theater Track)",
            "Batsilyer ng Sining sa Malikhaing Pagsulat"
        ];

        var courseIds = [
            "BAB",
            "BAJ",
            "BPA",
            "BSMP"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CBA") {
        var courses = [
            "Bachelor of Science in Business Administration Major in Business Economics",
            "Bachelor of Science in Business Administration Major in Financial Management",
            "Bachelor of Science in Business Administration Major in Marketing Management",
            "Bachelor of Science in Entrepreneurship",
            "Bachelor of Science in Accountancy"
        ];

        var courseIds = [
            "BSBABE",
            "BSBAFM",
            "BSBAMM",
            "BSE",
            "BSA"
        ];


        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CCJE") {
        var courses = [
            "Bachelor of Arts in Legal Management",
            "Bachelor of Science in Criminology"
        ];

        var courseIds = [
            "BALM",
            "BSC"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CHTM") {
        var courses = [
            "Bachelor of Science in Hospitality Management",
            "Bachelor of Science in Tourism Management"
        ];

        var courseIds = [
            "BSHM",
            "BSTM"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CICT") {
        var courses = [
            "Bachelor of Science in Information Technology",
            "Bachelor of Library and Information Science",
            "Bachelor of Science in Information System"
        ];

        var courseIds = [
            "BSIT",
            "BLIS",
            "BSIS"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CIT") {
        var courses = [
            "Bachelor of Industrial Technology with specialization in Automotive",
            "Bachelor of Industrial Technology with specialization in Drafting",
            "Bachelor of Industrial Technology with specialization in Computer",
            "Bachelor of Industrial Technology with specialization in Electrical",
            "Bachelor of Industrial Technology with specialization in Electronics & Communication Technology",
            "Bachelor of Industrial Technology with specialization in Electronics Technology",
            "Bachelor of Industrial Technology with specialization in Food Processing Technology",
            "Bachelor of Industrial Technology with specialization in Mechanical",
            "Bachelor of Industrial Technology with specialization in Heating, Ventilation, Air Conditioning and Refrigeration Technology (HVACR)",
            "Bachelor of Industrial Technology with specialization in Mechatronics Technology",
            "Bachelor of Industrial Technology with specialization in Welding Technology"
        ];

        var courseIds = [
            "BIT AUTOMOTIVE",
            "BIT Drafting",
            "BIT Computer",
            "BIT Electrical",
            "BIT Electronics & Communication Technology",
            "BIT Electronics Technology",
            "BIT Food Processing Technology",
            "BIT Mechanical",
            "BIT HVACR",
            "BIT Mechatronics Technology",
            "BIT Welding Technology"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CLAW") {
        var courses = [
            "Bachelor of Laws",
            "Juris Doctor"
        ];

        var courseIds = [
            "BOL",
            "Juris Doctor"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CN") {
        var courses = [
            "Bachelor of Science in Nursing"
        ];

        var courseIds = [
            "BSN"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "COE") {
        var courses = [
            "Bachelor of Science in Civil Engineering",
            "Bachelor of Science in Computer Engineering",
            "Bachelor of Science in Electrical Engineering",
            "Bachelor of Science in Electronics Engineering",
            "Bachelor of Science in Industrial Engineering",
            "Bachelor of Science in Manufacturing Engineering",
            "Bachelor of Science in Mechanical Engineering",
            "Bachelor of Science in Mechatronics Engineering",
        ];

        var courseIds = [
            "BSCE",
            "BSCE",
            "BS Electrical Engineering",
            "BS Electronics Engineering",
            "BS Industrial Engineering",
            "BS Manufacturing Engineering",
            "BS Mechanical Engineering",
            "Bachelor of Science in Mechatronics Engineering"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "COED") {
        var courses = [
            "Bachelor of Elementary Education",
            "Bachelor of Early Childhood Education",
            "Bachelor of Secondary Education Major in English minor in Mandarin",
            "Bachelor of Secondary Education Major in Filipino",
            "Bachelor of Secondary Education Major in Sciences",
            "Bachelor of Secondary Education Major in Mathematics",
            "Bachelor of Secondary Education Major in Social Studies",
            "Bachelor of Secondary Education Major in Values Education",
            "Bachelor of Physical Education",
            "Bachelor of Technology and Livelihood Education Major in Industrial Arts",
            "Bachelor of Technology and Livelihood Education Major in Information and Communication Technology",
            "Bachelor of Technology and Livelihood Education Major in Home Economics"
        ];

        var courseIds = [
            "BEE",
            "BECE",
            "BSEM English minor in Mandarin",
            "BSEM Filipino",
            "BSEM Sciences",
            "BSEM Mathematics",
            "BSEM Social Studies",
            "BSEM Values Education",
            "BPE",
            "BTLEM Industrial Arts",
            "BTLEM Information and Communication Technology",
            "BTLEM Home Economics"
        ];


        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CS") {
        var courses = [
            "Bachelor of Science in Biology",
            "Bachelor of Science in Environmental Science",
            "Bachelor of Science in Food Technology",
            "Bachelor of Science in Math with Specialization in Computer Science",
            "Bachelor of Science in Math with Specialization in Applied Statistics",
            "Bachelor of Science in Math with Specialization in Business Applications"
        ];

        var courseIds = [
            "BSB",
            "BSES",
            "BSFT",
            "BSMS Computer Science",
            "BSMS Applied Statistics",
            "BSMS Business Applications"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CSER") {
        var courses = [
            "Bachelor of Science in Exercise and Sports Sciences with specialization in Fitness and Sports Coaching",
            "Bachelor of Science in Exercise and Sports Sciences with specialization in Fitness and Sports Management",
            "Certificate of Physical Education"
        ]

        var courseIds = [
            "BSESS Fitness and Sports Coaching",
            "BSESS Fitness and Sports Management",
            "CPE"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CSSP") {
        var courses = [
            "Bachelor of Public Administration",
            "Bachelor of Science in Social Work",
            "Bachelor of Science in Psychology"
        ];

        var courseIds = [
            "BPA",
            "BSS",
            "BSP"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
}

// Assuming you have a reference to the "add-course" and "year-level" dropdowns


function checkArchi() {
    var courseSelect = document.getElementById('add-course');
    var yearLevelSelect = document.getElementById('year-level');

    console.log(courseSelect.value);
    // Check if the selected course is "BSA"
    if (courseSelect.value === "BSA") {
        // If it is, add the option for 5th Year if it doesn't exist
        if (!yearLevelSelect.querySelector('option[value="5"]')) {
            var fifthYearOption = document.createElement('option');
            fifthYearOption.value = "5";
            fifthYearOption.text = "5th Year";
            yearLevelSelect.add(fifthYearOption);
        }
    } else {
        // If it's not "BSA," remove the option for 5th Year if it exists
        var fifthYearOption = yearLevelSelect.querySelector('option[value="5"]');
        if (fifthYearOption) {
            yearLevelSelect.remove(fifthYearOption.index);
        }
    }
}



function addCourses(courses, courseIds) {

    if (courses.length !== courseIds.length) {
        console.error("The number of courses and customIds must be the same.");
        return;
    }

    for (var i = 0; i < courses.length; i++) {
        var option = document.createElement("option");
        option.text = courses[i];
        option.value = courseIds[i];
        courseSelect.appendChild(option);
    }
    checkArchi();
}

// ADD PENDING SCHOLARS+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
var studNoFlag = false;
function addApprovedScholar(table_name, particular) {
    // console.log(studNoFlag);
    // console.log("PARTICULAR: ", particular);
    var studentNumber = document.getElementById('student-number').value.trim();
    var lastName = document.getElementById('last-name').value.trim().charAt(0).toUpperCase() +
        document.getElementById('last-name').value.trim().slice(1).toLowerCase();

    var firstName = document.getElementById('first-name').value.trim().charAt(0).toUpperCase() +
        document.getElementById('first-name').value.trim().slice(1).toLowerCase();

    var middleName = document.getElementById('middle-name').value.trim().charAt(0).toUpperCase() +
        document.getElementById('middle-name').value.trim().slice(1).toLowerCase();
    var email = document.getElementById('email').value.trim().toLowerCase();
    var contact = document.getElementById('contact').value.trim();
    var campus = document.getElementById('add-campus').value.trim();
    var college = document.getElementById('add-college').value.trim();
    var course = document.getElementById('add-course').value.trim();
    var yearLevel = document.getElementById('year-level').value.trim();
    var gwa = parseFloat(document.getElementById('gwa').value.trim()).toFixed(2);
    var units = document.getElementById('units').value.trim();
    var user = full_name;

    var alert = document.getElementById('alert-result');

    // Regular expression for the contact number
    var contactRegex = /^09\d{9}$/;

    // console.log("UNITS: ", units);

    if (!studentNumber || !lastName || !firstName || !email || !contact || !campus || !college || !course || !yearLevel || !gwa || !units) {
        alert.innerHTML = '<div class="alert alert-danger" role="alert">Please fill out all required fields.</div>';
    }
    else if (studentNumber.length !== 10) {
        alert.innerHTML = '<div class="alert alert-danger" role="alert">Please enter a correct student number.</div>';
    }
    else if (!/^[a-zA-Z ]+$/.test(lastName)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Last name should only contain letters.</div>';
    }
    else if (!/^[a-zA-Z ]+$/.test(firstName)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">First name should only contain letters.</div>';
    }
    else if (!/^[a-zA-Z ]*$/.test(middleName)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">sMiddle name should only contain letters.</div>';
    }
    else if (!contactRegex.test(contact)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Please enter a valid contact number in the format 09XXXXXXXXX.</div>';
    }
    else if (isNaN(parseFloat(gwa)) || parseFloat(gwa) < 1 || parseFloat(gwa) > 5) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Please enter a valid GWA between 1.00 and 5.00</div>';
    }
    else if (isNaN(parseInt(units)) || parseInt(units) < 1 || parseInt(units) > 100) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Please enter a valid whole number for the unit between 1 and 100.</div>';
    }
    else if (!validateEmail(email)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Please enter a valid email address.</div>';
    }
    else if (!studNoFlag) {
        alert.innerHTML = '<div class="alert alert-danger" role="alert">Student Number already exist!</div>';
    }
    else {

        if (particular == "GOVERNMENT") {

            let formValidate = new FormData();
            formValidate.append('student-number', studentNumber);

            fetch('../php/toValidateGovernment.php', {
                method: 'POST',
                body: formValidate
            })
                .then(function (response) {
                    return response.json();
                })
                .then(function (data) {
                    // console.log("TUTE");
                    console.log(data);
                    console.log("EXIST: ", data.exist);

                    if (!data.exist) {
                        // Create a FormData object to send the form data
                        let formData = new FormData();
                        formData.append('table-name', table_name);
                        formData.append('student-number', studentNumber);
                        formData.append('last-name', lastName);
                        formData.append('first-name', firstName);
                        formData.append('middle-name', middleName);
                        formData.append('email', email);
                        formData.append('contact', contact);
                        formData.append('campus', campus);
                        formData.append('college', college);
                        formData.append('course', course);
                        formData.append('year-level', yearLevel);
                        formData.append('gwa', gwa);
                        formData.append('units', units);
                        formData.append('user', user);


                        // Send the form data to a PHP script using AJAX
                        fetch('../php/toAddApprovedScholar.php', {
                            method: 'POST',
                            body: formData
                        })
                            .then(function (response) {
                                // SUCCESSFULLY ADDED
                                const success_toast = document.getElementById('success-add-toast');
                                bootstrap.Toast.getOrCreateInstance(success_toast).show();

                                dismissAddModal(); //alisin ko muna to kasi nagloloko modal kaso di naman magsasara kapag wala neto


                                return response.text();
                            })
                            .then(function (data) {
                                // Display the response from the PHP script
                                document.getElementById('alert-result').innerHTML = data;

                                let studNoInput = document.getElementById("student-number");
                                let result = document.getElementById("result");

                                studNoInput.classList.remove('is-valid');
                                result.classList.remove('valid-feedback');
                                document.getElementById('result').innerText = "";
                                document.getElementById('add-pending-form').reset();
                                fetchTableCount(table_name);
                                fetchApproveScholars(table_name);

                                // Send email for each record
                                sendEmailApproveAdd(email, firstName, lastName);



                            })
                            .catch(function (error) {
                                console.error('Error:', error);
                            });
                    }
                    else {
                        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">' + studentNumber + ' already exist in other Government Scholarship.</div>';
                    }
                })
                .catch(function (error) {
                    console.error('Error:', error);
                    alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">' + error + '</div>';
                });

        }
        else {


            // Create a FormData object to send the form data
            let formData = new FormData();
            formData.append('table-name', table_name);
            formData.append('student-number', studentNumber);
            formData.append('last-name', lastName);
            formData.append('first-name', firstName);
            formData.append('middle-name', middleName);
            formData.append('email', email);
            formData.append('contact', contact);
            formData.append('campus', campus);
            formData.append('college', college);
            formData.append('course', course);
            formData.append('year-level', yearLevel);
            formData.append('gwa', gwa);
            formData.append('units', units);
            formData.append('user', user);
            console.log('Add: ', user);

            // Send the form data to a PHP script using AJAX
            fetch('../php/toAddApprovedScholar.php', {
                method: 'POST',
                body: formData
            })
                .then(function (response) {
                    // SUCCESSFULLY ADDED
                    const success_toast = document.getElementById('success-add-toast');
                    bootstrap.Toast.getOrCreateInstance(success_toast).show();

                    dismissAddModal(); //alisin ko muna to kasi nagloloko modal kaso di naman magsasara kapag wala neto


                    return response.text();
                })
                .then(function (data) {
                    // Display the response from the PHP script
                    document.getElementById('alert-result').innerHTML = data;

                    let studNoInput = document.getElementById("student-number");
                    let result = document.getElementById("result");

                    studNoInput.classList.remove('is-valid');
                    result.classList.remove('valid-feedback');
                    document.getElementById('result').innerText = "";
                    document.getElementById('add-pending-form').reset();
                    fetchTableCount(table_name);
                    fetchApproveScholars(table_name);

                    // Send email for each record
                    sendEmailApproveAdd(email, firstName, lastName);




                })
                .catch(function (error) {
                    console.error('Error:', error);
                });

        }





    }
}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

//Email for Approve Add & Import
function sendEmailApproveAdd(email, fname, lname) {
    let formData = new FormData();
    formData.append('email', email);
    formData.append('fname', fname);
    formData.append('lname', lname);

    fetch('../php/sendEmailApproveAdd.php', { // Correct the URL path
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            if (response.ok) {
                return response.text();
            } else {
                throw new Error('Failed to send email');
            }
        })
        .then(function (responseText) {
            // You can handle the responseText here if needed
            console.log('Email sent:', responseText);
        })
        .catch(function (error) {
            console.error('Error:', error);
        });

}

//Email for Process by Accounting
function sendEmailProcess(email, fname, lname) {
    let formData = new FormData();
    formData.append('email', email);
    formData.append('fname', fname);
    formData.append('lname', lname);

    fetch('../php/sendEmailProcess.php', { // Correct the URL path
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            if (response.ok) {
                return response.text();
            } else {
                throw new Error('Failed to send email');
            }
        })
        .then(function (responseText) {
            // You can handle the responseText here if needed
            console.log('Email sent:', responseText);
        })
        .catch(function (error) {
            console.error('Error:', error);
        });

}
//Email for Scholarship Grant Claim
function sendEmailClaim(email, fname, lname) {
    let formData = new FormData();
    formData.append('email', email);
    formData.append('fname', fname);
    formData.append('lname', lname);

    fetch('../php/sendEmailClaim.php', { // Correct the URL path
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            if (response.ok) {
                return response.text();
            } else {
                throw new Error('Failed to send email');
            }
        })
        .then(function (responseText) {
            // You can handle the responseText here if needed
            console.log('Email sent:', responseText);
        })
        .catch(function (error) {
            console.error('Error:', error);
        });

}




// MODAL

// Get a reference to the modal element
var add_modal = document.getElementById('add-approved');
var import_modal = document.getElementById('import-approved');
// Create a Bootstrap modal instance
var AddModalInstance = new bootstrap.Modal(add_modal);
var ImportModalInstance = new bootstrap.Modal(import_modal);
// Hide the modal

function dismissAddModal() {
    AddModalInstance.hide();
}
function dismissImportModal() {
    ImportModalInstance.hide();
}

// MODAL

// SEARCH STUDENT NO.+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function searchStudentNo(table_name) {
    var studNo = document.getElementById("student-number").value;
    var studNoInput = document.getElementById("student-number");
    var result = document.getElementById("result");

    if (studNo.length != 10) {
        studNoInput.classList.remove('is-valid');
        studNoInput.classList.add('is-invalid');

        result.classList.remove('valid-feedback');
        result.classList.add('invalid-feedback');
        document.getElementById('result').innerText = "Please enter a correct student number!";
    }
    else {
        // Show the loading indicator
        document.getElementById("loader").style.display = "inline";

        var formData = new FormData();
        formData.append('student-number', studNo);
        formData.append('table-name', table_name);


        fetch('../php/toSearchStudentNo.php', {
            method: 'POST',
            body: formData
        })
            .then(function (response) {
                return response.text();
            })
            .then(function (data) {

                // Display the response from the PHP script
                document.getElementById("loader").style.display = "none";

                if (data == "existing") {

                    studNoFlag = false;
                    // document.getElementById('result').innerHTML = "<span class='text-danger'>"+studNo+" exist on the table</span>";
                    studNoInput.classList.remove('is-valid');
                    studNoInput.classList.add('is-invalid');

                    result.classList.remove('valid-feedback');
                    result.classList.add('invalid-feedback');

                    document.getElementById('result').innerText = studNo + " exist!";
                }
                else {
                    studNoFlag = true;

                    studNoInput.classList.remove('is-invalid');
                    studNoInput.classList.add('is-valid');

                    result.classList.remove('invalid-feedback');
                    result.classList.add('valid-feedback');

                    document.getElementById('result').innerText = " ";
                }
            })
            .catch(function (error) {
                console.error('Error:', error);
            });
    }


}
// SEARCH STUDENT NO.+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



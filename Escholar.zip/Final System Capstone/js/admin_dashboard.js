function fetchCounts() {
    const graduateContainer = document.getElementById("graduate");
    const scholarsContainer = document.getElementById("scholars");
    const benefactorsContainer = document.getElementById("benefactors");
    const adminContainer = document.getElementById("admin");

    // Function to display counts in HTML
    const displayCounts = (data) => {
        graduateContainer.innerText = data.graduate_count || 0;
        scholarsContainer.innerText = data.masterlist_count || 0; // Assuming masterlist_count corresponds to scholars
        benefactorsContainer.innerText = data.benefactor_count || 0;
        adminContainer.innerText = data.admin_count || 0;
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        graduateContainer.innerText = "Error"; // Update the HTML with an error message for graduate count
        scholarsContainer.innerText = "Error"; // Update the HTML with an error message for scholars count
        benefactorsContainer.innerText = "Error"; // Update the HTML with an error message for benefactors count
        adminContainer.innerText = "Error"; // Update the HTML with an error message for admin count
    };

    // var formData = new FormData();
    // formData.append('table-name', table_name);

    fetch("../php/getCounts.php", {
        method: 'POST',

    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            //console.log("Received data:", data); // Log received data
            displayCounts(data);
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

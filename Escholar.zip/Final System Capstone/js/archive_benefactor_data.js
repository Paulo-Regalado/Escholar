function fetchScholars(table_name, benefactor_name) {
    $('#archive-table').DataTable().destroy();
    console.log("" + table_name);
    nameTable = table_name;
    benefactor = benefactor_name;

    const tableBody = document.getElementById("archive-table-body");

    // Function to display data in the table
    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            tableBody.innerHTML += `
                <tr>
                    <td>${row.student_number}</td>
                    <td>${row.last_name}</td>
                    <td>${row.first_name}</td>
                    <td>${row.middle_name}</td>
                    <td>${row.email}</td>
                    <td>${row.contact}</td>
                    <td>${row.campus}</td>
                    <td>${row.college}</td>
                    <td nowrap>${row.course}</td>
                    <td>${row.year_level}</td>
                    <td>${row.gwa}</td>
                    <td>${row.units}</td>
                    <td>${row.status}</td>
                </tr>
            `;
        });

        $('#archive-table').DataTable();

    };



    // Attach CSV export functionality to your existing button
    const exportButton = document.getElementById("exportToCSVButton");
    exportButton.addEventListener("click", () => {
        // Get the DataTable API instance
        const dataTable = $('#archive-table').DataTable();

        // Get the data from the DataTable, including filtered data
        const allData = dataTable.rows({ search: 'applied' }).data();

        // Get the DataTable headers (thead)
        const headers = dataTable.columns().header().toArray().map(header => header.textContent);

        // Convert the DataTable data and headers to arrays
        const tableData = allData.toArray().map(row => {
            // Exclude the last column (buttons)
            return Object.values(row).slice(0, -1);
        });

        // Create a CSV string that includes headers and data
        const csvContent = [headers.slice(0, -1).join(','), ...tableData.map(row => row.join(','))].join('\n');

        // Create and trigger the CSV download
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = `Archived_Masterlist_${nameTable}.csv`;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    });




    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    var formData = new FormData();
    formData.append('table-name', table_name);

    // AJAX fetch request
    fetch("../php/getArchivedBenefactorData.php", {
        method: 'POST',
        body: formData
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data
            displayData(data); // Call the displayData function with the received data
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

// Call the fetchScholars function with appropriate arguments
// fetchScholars('your_table_name', 'your_benefactor_name');

//Export to PDF
function exportToPDF() {
    // Create a new jsPDF instance
    const doc = new jsPDF('landscape');

    // Extract the part of the table name before the last underscore
    const lastUnderscoreIndex = nameTable.lastIndexOf('_');
    const displayName = lastUnderscoreIndex !== -1 ? nameTable.substring(0, lastUnderscoreIndex) : nameTable;
    // Replace remaining underscores with spaces
    const formattedName = displayName.replace(/_/g, ' ');


    // Set the title for the PDF
    doc.text(`Masterlist - ${formattedName}`, 10, 10);

    // Define the columns and rows to be included in the PDF
    const columns = ["Student No.", "Surname", "Firstname", "M.I", "Email", "Contact", "Campus", "College", "Course", "Year"];
    const data = [];

    // Iterate through the table rows and add data to the PDF
    $('#archive-table').DataTable().rows().every(function (rowIdx, tableLoop, rowLoop) {
        const rowData = this.data();
        data.push(rowData);
    });

    // Generate the table in the PDF using jspdf-autotable
    doc.autoTable({
        head: [columns],
        body: data,
        // Use "auto" for column width to let the plugin automatically adjust
        columnStyles: {
            0: { cellWidth: 'auto' },
            1: { cellWidth: 'auto' }, 2: { cellWidth: 'auto' }
        },
        margin: { top: 20 },  // Add margin to ensure content is not too close to the top
    });

    // Save the PDF with a file name
    doc.save(`Archived_Masterlist_${formattedName}.pdf`);
}

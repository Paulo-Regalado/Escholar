document.addEventListener("DOMContentLoaded", () => {
    fetchAnnouncement();
});

var full_name;
function actLogs(firstname, lastname) {

    full_name = firstname + ' ' + lastname;

}

function fetchAnnouncement() {
    $('#announcement-table').DataTable().destroy();

    const tableBody = document.getElementById("announcement-table-body");

    // Function to format a timestamp
    const formatTimestamp = (timestamp) => {
        // Modify the formatting here as needed, e.g., use Moment.js for more advanced formatting
        const date = new Date(timestamp);
        return date.toLocaleString(); // Format as a local date and time string
    };

    // Function to display data in the table
    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            tableBody.innerHTML += `
      <tr>
        <td>${row.id}</td>
        <td>${row.title}</td>
        <td style="min-width: 700px; text-align: left;">${row.description}</td>
        <td>${row.url}</td>
        <td>${formatTimestamp(row.date_created)}</td>
        <td style="width: 100px; white-space: nowrap;">

        <div class="modal fade" id="modal-delete${row.id}" tabindex="-1"aria-hidden="true">
        <div class="modal-dialog  modal-dialog-centered">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Announcement</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete ${row.title}?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" onclick="deleteAnnouncement(${row.id})">Delete</button>
            </div>
            </div>
        </div>
        </div>

          <button style="width: 100%;" id="${row.id}" class="btn btn-success btn-sm my-1" type="button" onclick="restoreAnnouncement(${row.id})"><i class="bi bi-archive me-0 me-sm-1" ></i>Restore</button>
          <button style="width: 100%;" type="button" class="btn btn-danger delete-btn btn-sm  mb-2 w-100 d-flex flex-nowrap align-items-center justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-delete${row.id}" >
          <i class="bi bi-trash me-1"></i>Delete
            </button>
          </td>
      </tr>
  `;
        });

        $('#announcement-table').DataTable();
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    fetch("../php/getArchivedAnnouncement.php", {
        method: 'POST',
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data

            if (Array.isArray(data.data)) {
                displayData(data.data); // Pass the "data" property of the response
            } else {
                // Handle the case where data is not an array
                handleError("Data is not an array");
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

function restoreAnnouncement(id) {
    console.log("ID: ", id);
    var user = full_name;



    var formData = new FormData();
    formData.append('id', id);
    formData.append('user', user);

    fetch('../php/toRestoreAnnouncement.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log("ETO LUMABAS" + data);

            // Check for success and handle accordingly
            if (data.success) {
                fetchAnnouncement();
                const success_toast = document.getElementById('success-restore-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();
            } else {
                console.error('Error archiving announcement:', data.error);
            }
        })
        .catch(function (error) {
            console.error('Error archiving announcement:', error);
        });
}

function deleteAnnouncement(id) {
    console.log("ID: ", id);
    var user = full_name;

    var formData = new FormData();
    formData.append('id', id);
    formData.append('user', user);

    fetch('../php/toDeleteAnnouncement.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log(data);

            // Check for success and handle accordingly
            if (data.success) {

                const success_delete_toast = document.getElementById('success-delete-toast');
                bootstrap.Toast.getOrCreateInstance(success_delete_toast).show();

            } else {
                console.error('Error deleting announcement:', data.error);
                const failed_delete_toast = document.getElementById('failed-delete-toast');
                bootstrap.Toast.getOrCreateInstance(failed_delete_toast).show();
            }
            fetchAnnouncement();
            dismissDeleteModal(id);

        })
        .catch(function (error) {
            console.error('Error deleting announcement:', error);
        });
}



function dismissDeleteModal(id) {
    const modal = document.getElementById(`modal-delete${id}`);
    const modalInstance = bootstrap.Modal.getInstance(modal);
    modalInstance.hide();
}
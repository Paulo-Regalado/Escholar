document.addEventListener("DOMContentLoaded", function () {
    // fetchArchivedBenefactor();
    fetchArchivedBenefactorFolder();
});

var full_name;
function actLogs(firstname, lastname) {

    full_name = firstname + ' ' + lastname;

}

function fetchArchivedBenefactor() {
    $('#benefactor-table').DataTable().destroy();
    const tableBody = document.getElementById("benefactor-table-body");

    const displayData = (data) => {
        console.log(data);
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {

            console.log("ITO TITE", row.table_name);

            tableBody.innerHTML += `
    <td>${row.name}</td>
    <td>${row.particular}</td>
    <td>${row.from_sy} - ${row.to_sy}</td>
    <td>${row.semester}</td>
    <td>${row.slot}</td>
    <td>${row.amount}</td>
    <td >
    <div class="modal fade" id="modal-delete${row.id}" tabindex="-1"aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
        <div class="modal-content">
        <div class="modal-header">
            <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Benefactor</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            Are you sure you want to delete ${row.name} ${row.from_sy} - ${row.to_sy} ${row.semester}?
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-danger" onclick="deleteBenefactor(${row.id}, '${row.table_name}')">Delete</button>
        </div>
        </div>
    </div>
    </div>
    
        <a style="width: 100%; background-color: #008000;" href="archive_benefactor_data.php?id=${row.id}" id="${row.id}" class="btn btn-success btn-sm mb-1"><i class="bi bi-eye me-1"></i>View</a>
      <button style="width: 100%;" type="button" class="btn btn-danger delete-btn btn-sm  mb-2 w-100 d-flex flex-nowrap align-items-center justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-delete${row.id}" >
      <i class="bi bi-trash me-1"></i>Delete
        </button>
    </td>

`;
        });

        $('#benefactor-table').DataTable();
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr class='text-center'><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };


    fetch("../php/getArchivedBenefactor.php")
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data
            displayData(data);
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

function restoreBenefactor(id) {
    console.log("ID: ", id);
    var user = full_name;


    var formData = new FormData();
    formData.append('id', id);
    formData.append('user', user);

    fetch('../php/toRestoreBenefactor.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {

            // Check for success and handle accordingly
            if (data.success) {
                fetchArchivedBenefactor();
                const success_toast = document.getElementById('success-restore-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();
            } else {
                console.error('Error restoring benefactor:', data.error);
            }
        })
        .catch(function (error) {
            console.error('Error restoring benefactor:', error);
        });
}


function deleteBenefactor(id, delete_table) {
    console.log("ID: ", id);
    var user = full_name;

    var formData = new FormData();
    formData.append('id', id);
    formData.append('delete_table', delete_table);
    formData.append('user', user);

    fetch('../php/toDeleteBenefactor.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log(data);

            // Check for success and handle accordingly
            if (data.success) {
                fetchArchivedBenefactor();
                const success_delete_toast = document.getElementById('success-delete-toast');
                bootstrap.Toast.getOrCreateInstance(success_delete_toast).show();
            } else {
                console.error('Error deleting benefactor:', data.error);
            }

            dismissDeleteModal(id);


        })
        .catch(function (error) {
            console.error('Error deleting benefactor:', error);
        });
}



function dismissDeleteModal(id) {
    const modal = document.getElementById(`modal-delete${id}`);
    const modalInstance = bootstrap.Modal.getInstance(modal);
    modalInstance.hide();
}


function fetchArchivedBenefactorFolder() {

    $('#benefactor-table').DataTable().destroy();
    const tableBody = document.getElementById("benefactor-table-body");

    const displayData = (data) => {
        console.log(data);
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {

            tableBody.innerHTML += `
                <td>${row}</td>
                <td >
                    <a style="width: 150px; background-color: #008000;" href="archive_benefactor_table.php?name=${row}" id="${row}" class="btn btn-success btn-sm mb-1"><i class="bi bi-eye me-1"></i>View</a>
                </td>
            `;
        });

        $('#benefactor-table').DataTable();
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr class='text-center'><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    fetch("../php/getArchivedBenefactorFolder.php")
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            displayData(data);
            console.log("Received Folder data:", data); // Log received data
        })
        .catch((error) => {
            handleError(error);
            console.error("Fetch Folder error:", error); // Log fetch error
        });
}
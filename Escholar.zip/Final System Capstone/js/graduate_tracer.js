var employmentSelect = document.getElementById("employment");
var orgSelect = document.getElementById("org_type");
var reasonInput = document.getElementById("reasons")
var companyInput = document.getElementById("company_name");
var companyAddInput = document.getElementById("company_address");
var positionInput = document.getElementById("position");
var yearInput = document.getElementById("year_in_company");


orgSelect.disabled = true;
companyInput.disabled = true;
companyAddInput.disabled = true;
positionInput.disabled = true;
yearInput.disabled = true;
reasonInput.disabled = true;

function selectOrganization() {
    orgSelect.innerHTML = "";

    var selectedEmployment = employmentSelect.value;
    if (selectedEmployment === "Employed, Locally") {
        var org = [
            "Public/Government",
            "NGO",
            "Non-profit",
            "Private",
            "Owned"
        ];

        var orgIds = [
            "Public/Government",
            "NGO",
            "Non-profit",
            "Private",
            "Owned"
        ];
        addOrg(org, orgIds);
        orgSelect.disabled = false;
        companyInput.disabled = false;
        companyAddInput.disabled = false;
        positionInput.disabled = false;
        yearInput.disabled = false;
        reasonInput.disabled = true;
    }
    else if (selectedEmployment === "Employed, Abroad") {
        var org = [
            "Public/Government",
            "NGO",
            "Non-profit",
            "Private",
            "Owned"
        ];

        var orgIds = [
            "Public/Government",
            "NGO",
            "Non-profit",
            "Private",
            "Owned"
        ];
        addOrg(org, orgIds);
        orgSelect.disabled = false;
        companyInput.disabled = false;
        companyAddInput.disabled = false;
        positionInput.disabled = false;
        yearInput.disabled = false;
        reasonInput.disabled = true;
    }
    else if (selectedEmployment === "Self-employed") {
        var org = [
            "Public/Government",
            "NGO",
            "Non-profit",
            "Private",
            "Owned"
        ];

        var orgIds = [
            "Public/Government",
            "NGO",
            "Non-profit",
            "Private",
            "Owned"
        ];
        addOrg(org, orgIds);
        orgSelect.disabled = false;
        companyInput.disabled = false;
        companyAddInput.disabled = false;
        positionInput.disabled = false;
        yearInput.disabled = false;
        reasonInput.disabled = true;
    }
    else {

        orgSelect.disabled = true;
        companyInput.disabled = true;
        companyAddInput.disabled = true;
        positionInput.disabled = true;
        yearInput.disabled = true;
        reasonInput.disabled = false;
    }
}

function addOrg(org, orgIds) {

    if (org.length !== orgIds.length) {
        console.error("The number of courses and customIds must be the same.");
        return;
    }

    for (var i = 0; i < org.length; i++) {
        var option = document.createElement("option");
        option.text = org[i];
        option.value = orgIds[i];
        orgSelect.appendChild(option);
    }
}

document.addEventListener('DOMContentLoaded', function () {
    const requirementForm = document.getElementById('tracer_form');

    requirementForm.addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent the default form submission

        var student_number = document.getElementById('student_number').value;
        var full_name = document.getElementById('full_name').value;
        var birthday = document.getElementById('birthday').value;
        var gender = document.getElementById('gender').value;
        var civil_status = document.getElementById('civil_status').value;
        var current_address = document.getElementById('current_address').value;
        var contact = document.getElementById('contact').value;
        var email = document.getElementById('email').value;
        var course = document.getElementById('course').value;
        var year_graduated = document.getElementById('year_graduated').value;
        var benefactor = document.getElementById('benefactor').value;
        var campus = document.getElementById('campus').value;
        var employment = document.getElementById('employment').value;
        var org_type = document.getElementById('org_type').value;
        var company_name = document.getElementById('company_name').value;
        var company_address = document.getElementById('company_address').value;
        var position = document.getElementById('position').value;
        var year_in_company = document.getElementById('year_in_company').value;
        var reasons = document.getElementById('reasons').value;

        // Get the file input
        var gradPicInput = document.getElementById('grad_pic');
        var gradPicFile = gradPicInput.files[0]; // Get the selected file


        console.log("Contact: ", contact);
        // Create a FormData object to send the form data
        let formData = new FormData();
        formData.append('grad_pic', gradPicFile);
        formData.append('student_number', student_number);
        formData.append('full_name', full_name);
        formData.append('birthday', birthday);
        formData.append('gender', gender);
        formData.append('civil_status', civil_status);
        formData.append('current_address', current_address);
        formData.append('contact', contact);
        formData.append('email', email);
        formData.append('course', course);
        formData.append('year_graduated', year_graduated);
        formData.append('benefactor', benefactor);
        formData.append('campus', campus);
        formData.append('employment', employment);
        formData.append('org_type', org_type);
        formData.append('company_name', company_name);
        formData.append('company_address', company_address);
        formData.append('position', position);
        formData.append('year_in_company', year_in_company);
        formData.append('reasons', reasons);



        // Send the form data to a PHP script using AJAX
        fetch('../php/toGraduateTracer.php', {
            method: 'POST',
            body: formData
        })
            .then(function (response) {

                // SUCCESSFULLY ADDED
                const success_toast = document.getElementById('success-add-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();

                dismissSubmitModal()
                return response.text();
            })
            .then(function (data) {

                console.log(data);

                document.getElementById('tracer_form').reset();
                window.location.href = 'dashboard.php'


            })
            .catch(function (error) {
                console.error('Error:', error);
            });
    });
});



//Modal Instance
var submit_modal = document.getElementById('term');
var SubmitModalInstance = new bootstrap.Modal(submit_modal);
function dismissSubmitModal() {
    SubmitModalInstance.hide();
}



document.addEventListener("DOMContentLoaded", function () {
    // Select the Save button by its id
    var saveButton = document.getElementById("saveButton");

    // Add a click event listener to the Save button
    saveButton.addEventListener("click", function () {
        // Call your validation function
        if (validate()) {
            // If validation succeeds, show the modal
            $('#term').modal('show');
        }
        // If validation fails, you can add an else statement here to handle it as needed.
    });
    //Validation
    function validate() {

        const validationError = document.getElementById('validation-error');
        const student_number = document.getElementById('student_number');
        const full_name = document.getElementById('full_name');
        const birthday = document.getElementById('birthday');
        const gender = document.getElementById('gender');
        const civil_status = document.getElementById('civil_status');
        const current_address = document.getElementById('current_address');
        const contact = document.getElementById('contact');
        const email = document.getElementById('email');
        const course = document.getElementById('course');
        const year_graduated = document.getElementById('year_graduated');
        const benefactor = document.getElementById('benefactor');
        const campus = document.getElementById('campus');
        const employment = document.getElementById('employment');
        const org_type = document.getElementById('org_type');
        const company_name = document.getElementById('company_name');
        const company_address = document.getElementById('company_address');
        const position = document.getElementById('position');
        const year_in_company = document.getElementById('year_in_company');
        const reasons = document.getElementById('reasons');
        const gradPicInput = document.getElementById('grad_pic');

        if (student_number.value.length !== 10) {
            validationError.textContent = 'Please enter a valid 10-digit number for the student number.';
            validationError.style.display = 'block';
            console.log("std");
            return;
        }

        if (!/^[A-Za-z. ]+$/.test(full_name.value)) {
            validationError.textContent = 'Please enter a valid full name with letters, periods, and spaces only.';
            validationError.style.display = 'block';
            return;
        }

        if (!/^\d{4}-\d{2}-\d{2}$/.test(birthday.value)) {
            validationError.textContent = 'Please enter a valid date in the format yyyy-mm-dd.';
            validationError.style.display = 'block';
            return;
        }

        if (gender.value === "") {
            validationError.textContent = 'Please select gender.';
            validationError.style.display = 'block';
            return;

        }

        if (civil_status.value === "") {
            validationError.textContent = 'Please select civil status.';
            validationError.style.display = 'block';
            return;
        }

        if (current_address.value.trim() === '') {
            validationError.textContent = 'Address cannot be empty.';
            validationError.style.display = 'block';
            return;
        }

        var contactRegex = /^09\d{9}$/;
        if (!contactRegex.test(contact.value)) {
            validationError.textContent = 'Please enter a valid contact number in the format 09XXXXXXXXX.';
            validationError.style.display = 'block';
            return;

        }

        const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
        if (!emailRegex.test(email.value)) {
            validationError.textContent = 'Please enter a valid email address.';
            validationError.style.display = 'block';
            return;
        }


        if (!/^[A-Za-z ]+$/.test(course.value)) {
            validationError.textContent = 'Please enter a valid course with letters and spaces only.';
            validationError.style.display = 'block';
            return;
        }

        if (!/^\d{4}$/.test(year_graduated.value)) {
            validationError.textContent = 'Please enter a valid year (4 digits).';
            validationError.style.display = 'block';
            return;
        }

        if (!/^[A-Za-z ]+$/.test(benefactor.value)) {
            validationError.textContent = 'Please enter a valid benefactor with letters and spaces only.';
            validationError.style.display = 'block';
            return;
        }

        if (campus.value === "") {
            validationError.textContent = 'Please select a campus.';
            validationError.style.display = 'block';
            return;
        }

        if (employment.value === "") {
            validationError.textContent = 'Please select a employment status.';
            validationError.style.display = 'block';
            return;
        }

        if (employment.value !== "Unemployed" && org_type.value === "") {
            validationError.textContent = 'Please select an organization type.';
            validationError.style.display = 'block';
            return;
        }

        if (employment.value !== "Unemployed" && company_name.value === "") {
            validationError.textContent = 'Please enter company name.';
            validationError.style.display = 'block';
            return;
        }

        if (employment.value !== "Unemployed" && company_address.value === "") {
            validationError.textContent = 'Please enter company address.';
            validationError.style.display = 'block';
            return;
        }

        if (employment.value !== "Unemployed" && !/^[A-Za-z0-9 ]+$/.test(position.value)) {
            validationError.textContent = 'Please enter a valid position with letters and numbers only.';
            validationError.style.display = 'block';
            return;
        }

        if (employment.value !== "Unemployed" && !/^\d+$/.test(year_in_company.value)) {
            validationError.textContent = 'Please enter a valid number for the years in the company.';
            validationError.style.display = 'block';
            return;
        }

        if (employment.value === "Unemployed") {
            if (reasons.value.trim() === '') {
                validationError.textContent = 'Please provide reasons for unemployment.';
                validationError.style.display = 'block';
                return;
            }
        }

        const maxFileSizeInBytes = 2097152; // 2 MB

        if (gradPicInput.files.length > 0) {
            const file = gradPicInput.files[0]; // Assuming it's a single file input
            if (file.size > maxFileSizeInBytes) {
                validationError.textContent = 'The selected file exceeds the 2MB limit.';
                validationError.style.display = 'block';
                return;
            }
        }

        // If all validation checks pass, return true
        return true;


    }




}
);




var collegeSelect = document.getElementById("add-college");
var courseSelect = document.getElementById("add-course");
// const table = new DataTable('#pending-table');


var full_name;
function actLogs(firstname, lastname) {

    full_name = firstname + ' ' + lastname;

}
function changeCollege() {
    // Clear existing options in the course dropdown
    courseSelect.innerHTML = "";


    // Populate the course dropdown based on the selected college
    var selectedCollege = collegeSelect.value;
    if (selectedCollege === "CAFA") {
        var courses = [
            "Bachelor of Science in Architecture",
            "Bachelor of Landscape Architecture",
            "Bachelor of Fine Arts Major in Visual Communication"
        ];

        var courseIds = [
            "BSA",
            "BLA",
            "BFA"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CAL") {
        var courses = [
            "Bachelor of Arts in Broadcasting",
            "Bachelor of Arts in Journalism",
            "Bachelor of Performing Arts (Theater Track)",
            "Batsilyer ng Sining sa Malikhaing Pagsulat"
        ];

        var courseIds = [
            "BAB",
            "BAJ",
            "BPA",
            "BSMP"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CBA") {
        var courses = [
            "Bachelor of Science in Business Administration Major in Business Economics",
            "Bachelor of Science in Business Administration Major in Financial Management",
            "Bachelor of Science in Business Administration Major in Marketing Management",
            "Bachelor of Science in Entrepreneurship",
            "Bachelor of Science in Accountancy"
        ];

        var courseIds = [
            "BSBABE",
            "BSBAFM",
            "BSBAMM",
            "BSE",
            "BSA"
        ];


        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CCJE") {
        var courses = [
            "Bachelor of Arts in Legal Management",
            "Bachelor of Science in Criminology"
        ];

        var courseIds = [
            "BALM",
            "BSC"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CHTM") {
        var courses = [
            "Bachelor of Science in Hospitality Management",
            "Bachelor of Science in Tourism Management"
        ];

        var courseIds = [
            "BSHM",
            "BSTM"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CICT") {
        var courses = [
            "Bachelor of Science in Information Technology",
            "Bachelor of Library and Information Science",
            "Bachelor of Science in Information System"
        ];

        var courseIds = [
            "BSIT",
            "BLIS",
            "BSIS"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CIT") {
        var courses = [
            "Bachelor of Industrial Technology with specialization in Automotive",
            "Bachelor of Industrial Technology with specialization in Drafting",
            "Bachelor of Industrial Technology with specialization in Computer",
            "Bachelor of Industrial Technology with specialization in Electrical",
            "Bachelor of Industrial Technology with specialization in Electronics & Communication Technology",
            "Bachelor of Industrial Technology with specialization in Electronics Technology",
            "Bachelor of Industrial Technology with specialization in Food Processing Technology",
            "Bachelor of Industrial Technology with specialization in Mechanical",
            "Bachelor of Industrial Technology with specialization in Heating, Ventilation, Air Conditioning and Refrigeration Technology (HVACR)",
            "Bachelor of Industrial Technology with specialization in Mechatronics Technology",
            "Bachelor of Industrial Technology with specialization in Welding Technology"
        ];

        var courseIds = [
            "BIT AUTOMOTIVE",
            "BIT Drafting",
            "BIT Computer",
            "BIT Electrical",
            "BIT Electronics & Communication Technology",
            "BIT Electronics Technology",
            "BIT Food Processing Technology",
            "BIT Mechanical",
            "BIT HVACR",
            "BIT Mechatronics Technology",
            "BIT Welding Technology"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CLAW") {
        var courses = [
            "Bachelor of Laws",
            "Juris Doctor"
        ];

        var courseIds = [
            "BOL",
            "Juris Doctor"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CN") {
        var courses = [
            "Bachelor of Science in Nursing"
        ];

        var courseIds = [
            "BSN"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "COE") {
        var courses = [
            "Bachelor of Science in Civil Engineering",
            "Bachelor of Science in Computer Engineering",
            "Bachelor of Science in Electrical Engineering",
            "Bachelor of Science in Electronics Engineering",
            "Bachelor of Science in Industrial Engineering",
            "Bachelor of Science in Manufacturing Engineering",
            "Bachelor of Science in Mechanical Engineering",
            "Bachelor of Science in Mechatronics Engineering",
        ];

        var courseIds = [
            "BSCE",
            "BSCE",
            "BS Electrical Engineering",
            "BS Electronics Engineering",
            "BS Industrial Engineering",
            "BS Manufacturing Engineering",
            "BS Mechanical Engineering",
            "Bachelor of Science in Mechatronics Engineering"
        ];

        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "COED") {
        var courses = [
            "Bachelor of Elementary Education",
            "Bachelor of Early Childhood Education",
            "Bachelor of Secondary Education Major in English minor in Mandarin",
            "Bachelor of Secondary Education Major in Filipino",
            "Bachelor of Secondary Education Major in Sciences",
            "Bachelor of Secondary Education Major in Mathematics",
            "Bachelor of Secondary Education Major in Social Studies",
            "Bachelor of Secondary Education Major in Values Education",
            "Bachelor of Physical Education",
            "Bachelor of Technology and Livelihood Education Major in Industrial Arts",
            "Bachelor of Technology and Livelihood Education Major in Information and Communication Technology",
            "Bachelor of Technology and Livelihood Education Major in Home Economics"
        ];

        var courseIds = [
            "BEE",
            "BECE",
            "BSEM English minor in Mandarin",
            "BSEM Filipino",
            "BSEM Sciences",
            "BSEM Mathematics",
            "BSEM Social Studies",
            "BSEM Values Education",
            "BPE",
            "BTLEM Industrial Arts",
            "BTLEM Information and Communication Technology",
            "BTLEM Home Economics"
        ];


        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CS") {
        var courses = [
            "Bachelor of Science in Biology",
            "Bachelor of Science in Environmental Science",
            "Bachelor of Science in Food Technology",
            "Bachelor of Science in Math with Specialization in Computer Science",
            "Bachelor of Science in Math with Specialization in Applied Statistics",
            "Bachelor of Science in Math with Specialization in Business Applications"
        ];

        var courseIds = [
            "BSB",
            "BSES",
            "BSFT",
            "BSMS Computer Science",
            "BSMS Applied Statistics",
            "BSMS Business Applications"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CSER") {
        var courses = [
            "Bachelor of Science in Exercise and Sports Sciences with specialization in Fitness and Sports Coaching",
            "Bachelor of Science in Exercise and Sports Sciences with specialization in Fitness and Sports Management",
            "Certificate of Physical Education"
        ]

        var courseIds = [
            "BSESS Fitness and Sports Coaching",
            "BSESS Fitness and Sports Management",
            "CPE"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }
    else if (selectedCollege === "CSSP") {
        var courses = [
            "Bachelor of Public Administration",
            "Bachelor of Science in Social Work",
            "Bachelor of Science in Psychology"
        ];

        var courseIds = [
            "BPA",
            "BSS",
            "BSP"
        ];
        addCourses(courses, courseIds);
        courseSelect.disabled = false;
    }

}

function checkArchi() {
    var courseSelect = document.getElementById('edit-add-course');
    var yearLevelSelect = document.getElementById('edit-year-level');

    // Check if the selected course is "BSA"
    if (courseSelect.value === "BSA") {
        // Remove all existing options
        yearLevelSelect.options.length = 0;

        // Add options for 1st through 5th Year and "Graduate"
        for (var i = 1; i <= 5; i++) {
            var yearOption = document.createElement('option');
            yearOption.value = i.toString();
            yearOption.text = i + (i === 1 ? "st" : i === 2 ? "nd" : i === 3 ? "rd" : "th") + " Year";
            yearLevelSelect.add(yearOption);
        }

        // Add the option for "Graduate"
        var graduateOption = document.createElement('option');
        graduateOption.value = "graduate";
        graduateOption.text = "Graduate";
        yearLevelSelect.add(graduateOption);

    } else {
        // If it's not "BSA," reset to the default options
        yearLevelSelect.options.length = 0;

        // Add default options
        var defaultOptions = ["Year Level", "1st Year", "2nd Year", "3rd Year", "4th Year", "Graduate"];
        for (var i = 0; i < defaultOptions.length; i++) {
            var defaultOption = document.createElement('option');
            defaultOption.value = i.toString();
            defaultOption.text = defaultOptions[i];
            yearLevelSelect.add(defaultOption);
        }
    }
}



function addCourses(courses, courseIds) {

    if (courses.length !== courseIds.length) {
        console.error("The number of courses and customIds must be the same.");
        return;
    }

    for (var i = 0; i < courses.length; i++) {
        var option = document.createElement("option");
        option.text = courses[i];
        option.value = courseIds[i];
        courseSelect.appendChild(option);
    }
    checkArchi();
}

function archiveMasterlist(student_number, status, table_name, benefactor_name) {
    console.log("STUDENT NUMBER: ", student_number);
    console.log("STATUS: ", status);
    console.log("BENEFACTOR NAME:", benefactor_name);
    console.log("TABLE NAME:", table_name);
    var user = full_name;

    var formData = new FormData();
    formData.append('student-number', student_number);
    formData.append('status', status);
    formData.append('benefactor-name', benefactor_name);
    formData.append('table-name', table_name);
    formData.append('user', user);

    fetch('../php/toArchiveMasterlist.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log("ETO LUMABAS" + data);

            // Check for success and handle accordingly
            if (data.success) {
                fetchScholars(table_name, benefactor_name);
                const success_toast = document.getElementById('success-archived-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();
            } else {
                fetchScholars(table_name, benefactor_name);
                const failed_toast = document.getElementById('archive-failed-toast');
                bootstrap.Toast.getOrCreateInstance(failed_toast).show();
                console.error('Error archiving masterlist:', data.error);
            }
        })
        .catch(function (error) {
            console.error('Error archiving masterlist:', error);
        });
}

function fetchScholars(table_name, benefactor_name) {
    $('#pending-table').DataTable().destroy();
    console.log("" + table_name);
    nameTable = table_name;

    const tableBody = document.getElementById("pending-table-body");

    // Function to display data in the table

    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            tableBody.innerHTML += `
              <tr>
                <td>${row.student_number}</td>
                <td>${row.last_name}</td>
                <td>${row.first_name}</td>
                <td>${row.middle_name}</td>
                <td>${row.email}</td>
                <td>${row.contact}</td>
                <td>${row.campus}</td>
                <td>${row.college}</td>
                <td nowrap>${row.course}</td>
                <td>${row.year_level}</td>
                <td>${row.gwa}</td>
                <td>${row.units}</td>
                <td>${row.status}</td>
                <td style="width: 100px; white-space: nowrap;">
                <button type="button" nowrap id="${row.student_number}" class="btn btn-save text-light btn-sm my-1" data-bs-toggle="modal" data-bs-target="#edit-modal" onclick="assignData('${row.student_number}', '${table_name}', '${row.status}'), getOldStudNo('${row.student_number}')"><i class="bi bi-pencil-square me-0 me-sm-1"></i>Edit</button>
                <button id="${row.student_number}"  class="btn btn-del btn-sm my-1" type="button" onclick="archiveMasterlist('${row.student_number}', '${row.status}', '${table_name}', '${benefactor_name}')"><i class="bi bi-archive me-0 me-sm-1"></i>Archive</button>
                </td>
              </tr>
          `;
        });


        const modal_container = document.getElementById("modal-container");
        modal_container.innerHTML = "";


        $('#pending-table').DataTable();
    };
    // Attach CSV export functionality to your existing button
    const exportButton = document.getElementById("exportToCSVButton");
    exportButton.addEventListener("click", () => {
        // Get the DataTable API instance
        const dataTable = $('#pending-table').DataTable();

        // Get the data from the DataTable, including filtered data
        const allData = dataTable.rows({ search: 'applied' }).data();

        // Get the DataTable headers (thead)
        const headers = dataTable.columns().header().toArray().map(header => header.textContent);

        // Convert the DataTable data and headers to arrays
        const tableData = allData.toArray().map(row => {
            // Exclude the last column (buttons)
            return Object.values(row).slice(0, -1);
        });

        // Create a CSV string that includes headers and data
        const csvContent = [headers.slice(0, -1).join(','), ...tableData.map(row => row.join(','))].join('\n');

        // Create and trigger the CSV download
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = `Masterlist_${nameTable}.csv`;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    });


    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    var formData = new FormData();
    formData.append('table-name', table_name);

    // AJAX fetch request
    fetch("../php/getAllMasterlist.php", {
        method: 'POST',
        body: formData
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data
            displayData(data);
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}


function exportToPDF() {
    // Create a new jsPDF instance
    const doc = new jsPDF('landscape');

    // Extract the part of the table name before the last underscore
    const lastUnderscoreIndex = nameTable.lastIndexOf('_');
    const displayName = lastUnderscoreIndex !== -1 ? nameTable.substring(0, lastUnderscoreIndex) : nameTable;
    // Replace remaining underscores with spaces
    const formattedName = displayName.replace(/_/g, ' ');


    // Set the title for the PDF
    doc.text(`Masterlist - ${formattedName}`, 10, 10);

    // Define the columns and rows to be included in the PDF
    const columns = ["Student No.", "Surname", "Firstname", "M.I", "Email", "Contact", "Campus", "College", "Course", "Year"];
    const data = [];

    // Iterate through the table rows and add data to the PDF
    $('#pending-table').DataTable().rows().every(function (rowIdx, tableLoop, rowLoop) {
        const rowData = this.data();
        data.push(rowData);
    });

    // Generate the table in the PDF using jspdf-autotable
    doc.autoTable({
        head: [columns],
        body: data,
        // Use "auto" for column width to let the plugin automatically adjust
        columnStyles: {
            0: { cellWidth: 'auto' },
            1: { cellWidth: 'auto' }, 2: { cellWidth: 'auto' }
        },
        margin: { top: 20 },  // Add margin to ensure content is not too close to the top
    });

    // Save the PDF with a file name
    doc.save(`Masterlist_${formattedName}.pdf`);
}




var studNoFlag = false;


function searchStudentNo(table_name) {
    var studNo = document.getElementById("student-number").value;
    var studNoInput = document.getElementById("student-number");
    var result = document.getElementById("result");

    if (studNo.length != 10) {
        studNoInput.classList.remove('is-valid');
        studNoInput.classList.add('is-invalid');

        result.classList.remove('valid-feedback');
        result.classList.add('invalid-feedback');
        document.getElementById('result').innerText = "Please enter a correct student number!";
    }
    else {
        // Show the loading indicator
        document.getElementById("loader").style.display = "inline";

        var formData = new FormData();
        formData.append('student-number', studNo);
        formData.append('table-name', table_name);


        fetch('../php/pending_add_getStudentNo.php', {
            method: 'POST',
            body: formData
        })
            .then(function (response) {
                return response.text();
            })
            .then(function (data) {

                // Display the response from the PHP script
                document.getElementById("loader").style.display = "none";

                if (data == "existing") {

                    studNoFlag = false;
                    // document.getElementById('result').innerHTML = "<span class='text-danger'>"+studNo+" exist on the table</span>";
                    studNoInput.classList.remove('is-valid');
                    studNoInput.classList.add('is-invalid');

                    result.classList.remove('valid-feedback');
                    result.classList.add('invalid-feedback');

                    document.getElementById('result').innerText = studNo + " exist!";
                }
                else {
                    studNoFlag = true;

                    studNoInput.classList.remove('is-invalid');
                    studNoInput.classList.add('is-valid');

                    result.classList.remove('invalid-feedback');
                    result.classList.add('valid-feedback');

                    document.getElementById('result').innerText = studNo + " looks good!";
                }
            })
            .catch(function (error) {
                console.error('Error:', error);
            });
    }


}

var edit_collegeSelect = document.getElementById("edit-add-college");
var edit_courseSelect = document.getElementById("edit-add-course");
edit_courseSelect.disabled = true;
function addEditCourses(courses, courseIds) {

    if (courses.length !== courseIds.length) {
        console.error("The number of courses and customIds must be the same.");
        return;
    }

    for (var i = 0; i < courses.length; i++) {
        var option = document.createElement("option");
        option.text = courses[i];
        option.value = courseIds[i];
        edit_courseSelect.appendChild(option);
    }
}

function changeEditCollege() {


    edit_courseSelect.innerHTML = "";


    // Populate the course dropdown based on the selected college
    var selectedCollege = edit_collegeSelect.value;
    if (selectedCollege === "CAFA") {
        var courses = [
            "Bachelor of Science in Architecture",
            "Bachelor of Landscape Architecture",
            "Bachelor of Fine Arts Major in Visual Communication"
        ];

        var courseIds = [
            "BSA",
            "BLA",
            "BFA"
        ];

        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CAL") {
        var courses = [
            "Bachelor of Arts in Broadcasting",
            "Bachelor of Arts in Journalism",
            "Bachelor of Performing Arts (Theater Track)",
            "Batsilyer ng Sining sa Malikhaing Pagsulat"
        ];

        var courseIds = [
            "BAB",
            "BAJ",
            "BPA",
            "BSMP"
        ];

        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CBA") {
        var courses = [
            "Bachelor of Science in Business Administration Major in Business Economics",
            "Bachelor of Science in Business Administration Major in Financial Management",
            "Bachelor of Science in Business Administration Major in Marketing Management",
            "Bachelor of Science in Entrepreneurship",
            "Bachelor of Science in Accountancy"
        ];

        var courseIds = [
            "BSBABE",
            "BSBAFM",
            "BSBAMM",
            "BSE",
            "BSA"
        ];


        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CCJE") {
        var courses = [
            "Bachelor of Arts in Legal Management",
            "Bachelor of Science in Criminology"
        ];

        var courseIds = [
            "BALM",
            "BSC"
        ];
        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CHTM") {
        var courses = [
            "Bachelor of Science in Hospitality Management",
            "Bachelor of Science in Tourism Management"
        ];

        var courseIds = [
            "BSHM",
            "BSTM"
        ];

        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CICT") {
        var courses = [
            "Bachelor of Science in Information Technology",
            "Bachelor of Library and Information Science",
            "Bachelor of Science in Information System"
        ];

        var courseIds = [
            "BSIT",
            "BLIS",
            "BSIS"
        ];
        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CIT") {
        var courses = [
            "Bachelor of Industrial Technology with specialization in Automotive",
            "Bachelor of Industrial Technology with specialization in Drafting",
            "Bachelor of Industrial Technology with specialization in Computer",
            "Bachelor of Industrial Technology with specialization in Electrical",
            "Bachelor of Industrial Technology with specialization in Electronics & Communication Technology",
            "Bachelor of Industrial Technology with specialization in Electronics Technology",
            "Bachelor of Industrial Technology with specialization in Food Processing Technology",
            "Bachelor of Industrial Technology with specialization in Mechanical",
            "Bachelor of Industrial Technology with specialization in Heating, Ventilation, Air Conditioning and Refrigeration Technology (HVACR)",
            "Bachelor of Industrial Technology with specialization in Mechatronics Technology",
            "Bachelor of Industrial Technology with specialization in Welding Technology"
        ];

        var courseIds = [
            "BIT AUTOMOTIVE",
            "BIT Drafting",
            "BIT Computer",
            "BIT Electrical",
            "BIT Electronics & Communication Technology",
            "BIT Electronics Technology",
            "BIT Food Processing Technology",
            "BIT Mechanical",
            "BIT HVACR",
            "BIT Mechatronics Technology",
            "BIT Welding Technology"
        ];

        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CLAW") {
        var courses = [
            "Bachelor of Laws",
            "Juris Doctor"
        ];

        var courseIds = [
            "BOL",
            "Juris Doctor"
        ];

        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CN") {
        var courses = [
            "Bachelor of Science in Nursing"
        ];

        var courseIds = [
            "BSN"
        ];

        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "COE") {
        var courses = [
            "Bachelor of Science in Civil Engineering",
            "Bachelor of Science in Computer Engineering",
            "Bachelor of Science in Electrical Engineering",
            "Bachelor of Science in Electronics Engineering",
            "Bachelor of Science in Industrial Engineering",
            "Bachelor of Science in Manufacturing Engineering",
            "Bachelor of Science in Mechanical Engineering",
            "Bachelor of Science in Mechatronics Engineering",
        ];

        var courseIds = [
            "BSCE",
            "BSCE",
            "BS Electrical Engineering",
            "BS Electronics Engineering",
            "BS Industrial Engineering",
            "BS Manufacturing Engineering",
            "BS Mechanical Engineering",
            "Bachelor of Science in Mechatronics Engineering"
        ];

        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "COED") {
        var courses = [
            "Bachelor of Elementary Education",
            "Bachelor of Early Childhood Education",
            "Bachelor of Secondary Education Major in English minor in Mandarin",
            "Bachelor of Secondary Education Major in Filipino",
            "Bachelor of Secondary Education Major in Sciences",
            "Bachelor of Secondary Education Major in Mathematics",
            "Bachelor of Secondary Education Major in Social Studies",
            "Bachelor of Secondary Education Major in Values Education",
            "Bachelor of Physical Education",
            "Bachelor of Technology and Livelihood Education Major in Industrial Arts",
            "Bachelor of Technology and Livelihood Education Major in Information and Communication Technology",
            "Bachelor of Technology and Livelihood Education Major in Home Economics"
        ];

        var courseIds = [
            "BEE",
            "BECE",
            "BSEM English minor in Mandarin",
            "BSEM Filipino",
            "BSEM Sciences",
            "BSEM Mathematics",
            "BSEM Social Studies",
            "BSEM Values Education",
            "BPE",
            "BTLEM Industrial Arts",
            "BTLEM Information and Communication Technology",
            "BTLEM Home Economics"
        ];


        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CS") {
        var courses = [
            "Bachelor of Science in Biology",
            "Bachelor of Science in Environmental Science",
            "Bachelor of Science in Food Technology",
            "Bachelor of Science in Math with Specialization in Computer Science",
            "Bachelor of Science in Math with Specialization in Applied Statistics",
            "Bachelor of Science in Math with Specialization in Business Applications"
        ];

        var courseIds = [
            "BSB",
            "BSES",
            "BSFT",
            "BSMS Computer Science",
            "BSMS Applied Statistics",
            "BSMS Business Applications"
        ];
        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CSER") {
        var courses = [
            "Bachelor of Science in Exercise and Sports Sciences with specialization in Fitness and Sports Coaching",
            "Bachelor of Science in Exercise and Sports Sciences with specialization in Fitness and Sports Management",
            "Certificate of Physical Education"
        ]

        var courseIds = [
            "BSESS Fitness and Sports Coaching",
            "BSESS Fitness and Sports Management",
            "CPE"
        ];
        addEditCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }
    else if (selectedCollege === "CSSP") {
        var courses = [
            "Bachelor of Public Administration",
            "Bachelor of Science in Social Work",
            "Bachelor of Science in Psychology"
        ];

        var courseIds = [
            "BPA",
            "BSS",
            "BSP"
        ];
        addEdCourses(courses, courseIds);
        edit_courseSelect.disabled = false;
    }



}

function displayData(data, status) {

    var studentNumber_edit = document.getElementById('edit-student-number');
    var lastName_edit = document.getElementById('edit-last-name');
    var firstName_edit = document.getElementById('edit-first-name');
    var middleName_edit = document.getElementById('edit-middle-name');

    var email_edit = document.getElementById('edit-email');
    var contact_edit = document.getElementById('edit-contact');

    var campus_edit = document.getElementById('edit-add-campus');
    var college_edit = document.getElementById('edit-add-college');
    var course_edit = document.getElementById('edit-add-course');
    var yearLevel_edit = document.getElementById('edit-year-level');
    var status_edit = document.getElementById('edit-status');

    console.log("ETO DATA", data, status);


    data.forEach((row) => {
        studentNumber_edit.value = `${row.student_number}`;
        lastName_edit.value = `${row.last_name}`;
        firstName_edit.value = `${row.first_name}`;
        middleName_edit.value = `${row.middle_name}`;

        email_edit.value = `${row.email}`;
        contact_edit.value = `${row.contact}`;

        campus_edit.value = `${row.campus}`;
        college_edit.value = `${row.college}`;
        changeEditCollege();
        course_edit.value = `${row.course}`;
        yearLevel_edit.value = `${row.year_level}`;
        status_edit.value = `${status}`;

    });
}

function assignData(studentNumber, table_name, status) {


    console.log("NYIHIHIHI" + studentNumber);

    var formData = new FormData();
    formData.append('table-name', table_name);
    formData.append('student-number', studentNumber);

    fetch('../php/getStudentMasterlist.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log("ETO LUMABAS" + data);
            displayData(data, status);

        })
        .catch(function (error) {
            console.error('Error assignData:', error);
        });
}

function getOldStudNo(oldStudNo) {
    edit_getOldStudNo = oldStudNo;
    console.log("TITE OLD STUD NO" + oldStudNo);
}


function editMasterlist(table_name, benefactor_name) {
    var edit_studentNumber = document.getElementById('edit-student-number').value;
    var edit_lastName = document.getElementById('edit-last-name').value;
    var edit_firstName = document.getElementById('edit-first-name').value;
    var edit_middleName = document.getElementById('edit-middle-name').value;
    var edit_email = document.getElementById('edit-email').value;
    var edit_contact = document.getElementById('edit-contact').value;
    var edit_campus = document.getElementById('edit-add-campus').value;
    var edit_college = document.getElementById('edit-add-college').value;
    var edit_course = document.getElementById('edit-add-course').value;
    var edit_yearLevel = document.getElementById('edit-year-level').value;
    var edit_status = document.getElementById('edit-status').value;
    var user = full_name;

    console.log("TITE AND DATING MONG OLD STUD AY ", edit_getOldStudNo);

    let edit_error = document.getElementById('edit-error-result');
    let studNo = document.getElementById("edit-student-number").value;

    if (studNo == edit_getOldStudNo) {
        edit_studNoFlag = true;
    }

    // Regular expression for the contact number
    var contactRegex = /^09\d{9}$/;

    if (!edit_studentNumber || !edit_lastName || !edit_firstName || !edit_middleName || !edit_email || !edit_contact || !edit_campus || !edit_college || !edit_yearLevel || !edit_status) {
        edit_error.innerHTML = '<div class="alert alert-danger" role="alert">Please fill out all required fields.</div>';
    }
    else if (edit_studentNumber.length !== 10) {
        edit_error.innerHTML = '<div class="alert alert-danger" role="alert">Please enter a correct student number.</div>';
    }
    else if (!/^[a-zA-Z ]+$/.test(edit_lastName)) {
        edit_error.innerHTML = '<div class="alert alert-danger m-0" role="alert">Last name should only contain letters.</div>';
    }
    else if (!/^[a-zA-Z ]+$/.test(edit_firstName)) {
        edit_error.innerHTML = '<div class="alert alert-danger m-0" role="alert">First name should only contain letters.</div>';
    }
    else if (!/^[a-zA-Z ]+$/.test(edit_middleName)) {
        edit_error.innerHTML = '<div class="alert alert-danger m-0" role="alert">Middle name should only contain letters.</div>';
    }
    else if (!contactRegex.test(edit_contact)) {
        edit_error.innerHTML = '<div class="alert alert-danger m-0" role="alert">Please enter a valid contact number in the format 09XXXXXXXXX.</div>';
    }
    else if (!validateEmail(edit_email)) {
        edit_error.innerHTML = '<div class="alert alert-danger m-0" role="alert">Please enter a valid email address.</div>';
    }
    else {
        // Create a FormData object to send the form data
        let formData = new FormData();
        formData.append('table-name', table_name);
        formData.append('student_number', edit_studentNumber);
        formData.append('last_name', edit_lastName);
        formData.append('first_name', edit_firstName);
        formData.append('middle_name', edit_middleName);
        formData.append('contact', edit_contact);
        formData.append('email', edit_email);
        formData.append('campus', edit_campus);
        formData.append('college', edit_college);
        formData.append('course', edit_course);
        formData.append('year_level', edit_yearLevel);
        formData.append('status', edit_status);
        formData.append('user', user);

        // Send the form data to a PHP script using AJAX
        fetch('../php/toEditMasterlist.php', {
            method: 'POST',
            body: formData
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (data.success) {
                    const success_update_toast = document.getElementById('success-update-toast');
                    bootstrap.Toast.getOrCreateInstance(success_update_toast).show();

                }
                else {
                    const failed_update_toast = document.getElementById('failed-update-toast');
                    bootstrap.Toast.getOrCreateInstance(failed_update_toast).show();
                }
                console.log("Successful")
                console.log(data);

                document.getElementById('edit-masterlist-form').reset();
                edit_error.innerHTML = data.message;
                dismissEditModal();
                fetchScholars(table_name, benefactor_name);

            })
            .catch(function (error) {
                console.error('Error:', error);
            });

    }

}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Get a reference to the modal element
var edit_modal = document.getElementById('edit-modal');
var EditModalInstance = new bootstrap.Modal(edit_modal);

function dismissEditModal() {
    EditModalInstance.hide();
}


//Export CSV
function convertToCSV(data) {
    const csvArray = [];

    // Add CSV header
    const header = [
        "Student Number",
        "Last Name",
        "First Name",
        "Middle Name",
        "Email",
        "Contact",
        "Campus",
        "College",
        "Course",
        "Year Level",
        "GWA",
        "Units"
    ];
    csvArray.push(header.join(','));

    // Add data rows
    data.forEach((row) => {
        const rowData = [
            row.student_number,
            row.last_name,
            row.first_name,
            row.middle_name,
            row.email,
            row.contact,
            row.campus,
            row.college,
            row.course,
            row.year_level,
            row.gwa,
            row.units
        ];
        csvArray.push(rowData.join(','));
    });

    return csvArray.join('\n');
}





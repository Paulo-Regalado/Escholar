var full_name;
function actLogs(firstname, lastname) {

  full_name = firstname + ' ' + lastname;

}
// FETCH DATA+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Function to fetch and display data using Ajax
function fetchPendingScholars(table_name) {
  $('#pending-table').DataTable().destroy();
  console.log("TITE" + table_name);
  const tableBody = document.getElementById("pending-table-body");

  // Function to display data in the table

  const displayData = (data) => {
    tableBody.innerHTML = ""; // Clear previous data

    data.forEach((row) => {
      tableBody.innerHTML += `
              <tr>
                <td>${row.student_number}</td>
                <td>${row.last_name}</td>
                <td>${row.first_name}</td>
                <td>${row.middle_name}</td>
                <td>${row.email}</td>
                <td>${row.contact}</td>
                <td>${row.campus}</td>
                <td>${row.college}</td>
                <td nowrap>${row.course}</td>
                <td>${row.year_level}</td>
                <td>${row.gwa}</td>
                <td>${row.units}</td>
                <td style="width: 100px; white-space: nowrap;">
                  <button id="${row.student_number}" class="btn btn-save btn-sm my-1" type="button" data-bs-toggle="modal" data-bs-target="#modal-${row.student_number}"><i class="fa-regular fa-newspaper"></i>Approve</button>
                </td>
              </tr>
          `;
    });

    const modal_container = document.getElementById("modal-container");
    modal_container.innerHTML = "";
    data.forEach((row) => {
      modal_container.innerHTML += `
      <div class='modal fade' id='modal-${row.student_number}' data-bs-backdrop="static" data-bs-keyboard="false" tabindex='-1' aria-hidden="true">
      <div class='modal-dialog modal-lg modal-dialog-centered'>
        <div class='modal-content'>
          <div class='modal-header'>
            <h1 class='modal-title fs-5' id='importModalLabel'>${row.last_name}, ${row.first_name} ${row.middle_name} - ${row.student_number}</h1>
             <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
          </div>       

          <div class='modal-body'>

          <ul class='nav nav-tabs' id='myTab' role='tablist'>
            <li class='nav-item' role='presentation'>
             <button class='nav-link active' id='cor-tab-${row.student_number}' data-bs-toggle='tab' data-bs-target='#home-tab-pane-${row.student_number}' type='button' role='tab' aria-controls='home-tab-pane-${row.student_number}' aria-selected='true'>Certificate of Registration</button>
            </li>
            <li class='nav-item' role='presentation'>
            <button class='nav-link' id='cog-tab-${row.student_number}' data-bs-toggle='tab' data-bs-target='#profile-tab-pane-${row.student_number}' type='button' role='tab' aria-controls='profile-tab-pane-${row.student_number}' aria-selected='false'>Certificate of Grade</button>
            </li>
            <li class='nav-item' role='presentation'>
            <button class='nav-link' id='cog-tab-${row.student_number}' data-bs-toggle='tab' data-bs-target='#id-tab-pane-${row.student_number}' type='button' role='tab' aria-controls='profile-tab-pane-${row.student_number}' aria-selected='false'>School ID</button>
            </li>
          </ul>
          <div class='tab-content' id='myTabContent'>
            <div class='tab-pane fade show active' id='home-tab-pane-${row.student_number}' role='tabpanel' aria-labelledby='cor-tab-${row.student_number}' tabindex='0'>
              <div class='ratio ratio-4x3 mt-2'>
                <iframe src='../Uploaded_Files/${row.student_number}_COR.pdf'></iframe>
              </div>
            </div>
            <div class='tab-pane fade' id='profile-tab-pane-${row.student_number}' role='tabpanel' aria-labelledby='cog-tab-${row.student_number}' tabindex='0'>
              <div class='ratio ratio-4x3 mt-2'>
                <iframe src='../Uploaded_Files/${row.student_number}_COG.pdf' ></iframe>
              </div>
            </div>
            <div class='tab-pane fade' id='id-tab-pane-${row.student_number}' role='tabpanel' aria-labelledby='id-tab-${row.student_number}' tabindex='0'>
            <div class='ratio ratio-4x3 mt-2'>
              <iframe src='../Uploaded_Files/${row.student_number}_ID.pdf' ></iframe>
            </div>
          </div>
          </div>
            </div>      
            <div class='modal-footer'>
              <button type='button' class='btn btn-del' data-bs-toggle="modal" data-bs-target="#rejectReasonModal" onclick='rejectData("${table_name}","${row.email}", "${row.first_name}","${row.last_name}", "${row.student_number}")'>Reject</button>
              <button type='button' class='btn btn-save' data-bs-toggle='modal' data-bs-target="#confirmationModal" onclick='approveData("${table_name}", "${row.email}", "${row.first_name}", "${row.last_name}", "${row.student_number}")'>Approve</button>
              </div>
              </div>
            </div>
          </div>
      `;

    });
    $('#pending-table').DataTable();
  };

  // Function to handle errors
  const handleError = (error) => {
    console.error("Error:", error);
    tableBody.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
  };

  var formData = new FormData();
  formData.append('table-name', table_name);

  // AJAX fetch request
  fetch("../php/getMasterlist.php", {
    method: 'POST',
    body: formData
  })
    .then((response) => {
      if (!response.ok) {
        console.log("Response status:", response.status); // Log response status
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then((data) => {
      console.log("Received data:", data); // Log received data
      displayData(data);
    })
    .catch((error) => {
      console.error("Fetch error:", error); // Log fetch error
      handleError(error);
    });
}

// FETCH DATA+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// APPROVE SCHOLAR
function approveScholar(table_name, email, fname, lname, approve_studNo) {

  // Trim unnecessary spaces from the email

  var user = full_name;

  console.log("the email is ", email);

  // Send email for each record
  sendEmailApprove(email, fname, lname);
  // Create a FormData object to send the form data
  let formData = new FormData();
  formData.append('table-name', table_name);
  formData.append('approve-studNo', approve_studNo);
  formData.append('user', user);


  fetch('../php/toApproveScholar.php', {
    method: 'POST',
    body: formData
  })
    .then(function (response) {
      return response.text();
    })
    .then(function (data) {

      // SUCCESSFULLY ADDED
      const success_approve_toast = document.getElementById('success-approve-toast');
      bootstrap.Toast.getOrCreateInstance(success_approve_toast).show();

      dismissCertificateModal(approve_studNo);
      fetchPendingScholars(table_name);
      dismissConfirmModal();

      // 

    })
    .catch(function (error) {
      console.error('Error:', error);
    });
}


//Email for Approved
function sendEmailApprove(email, fname, lname) {
  let formData = new FormData();
  formData.append('email', email);
  formData.append('fname', fname);
  formData.append('lname', lname);

  fetch('../php/sendEmailApprove.php', { // Correct the URL path
    method: 'POST',
    body: formData
  })
    .then(function (response) {
      if (response.ok) {
        return response.text();
      } else {
        throw new Error('Failed to send OTP email');
      }
    })
    .then(function (responseText) {
      // You can handle the responseText here if needed
      console.log('Email sent:', responseText);
    })
    .catch(function (error) {
      console.error('Error:', error);
    });
}



function dismissCertificateModal(approve_studNo) {

  new bootstrap.Modal(document.getElementById('modal-' + approve_studNo)).hide();
}

//Approve Confirmation
var approveEmail;
var approveFname;
var approveLname;
var approveTable;
var approveStudentNo;
function approveData(table, email, fname, lname, studNo) {

  console.log("Approve Clicked");

  approveEmail = email;
  approveFname = fname;
  approveLname = lname;
  approveStudentNo = studNo;
  approveTable = table;


}
function toApprove() {

  //Eto ilalagay sa ok sa modal
  approveScholar(approveTable, approveEmail, approveFname, approveLname, approveStudentNo)
  console.log("Approved Scholars");


}

//Modal Instance Confirm
var confirmation_modal = document.getElementById('confirmationModal');
var confirmationModalInstance = new bootstrap.Modal(confirmation_modal);
function dismissConfirmModal() {
  confirmationModalInstance.hide();
}

function getReason() {

  reason = document.getElementById('reason-input').value;

  rejectScholar(rejectTable, rejectEmail, rejectFname, rejectLname, rejectStudentNo, reason);
  console.log("Send");




}
var rejectEmail;
var rejectFname;
var rejectLname;
var rejectTable;
var rejectStudentNo;
function rejectData(table, email, fname, lname, studNo) {

  rejectTable = table;
  rejectEmail = email;
  rejectFname = fname;
  rejectLname = lname;
  rejectStudentNo = studNo;

  console.log("rejectData", rejectEmail, rejectFname, rejectLname, rejectStudentNo);


}
// REJECT SCHOLAR
function rejectScholar(table_name, email, fname, lname, rejected_studNo, reasons) {
  console.log(table_name, rejected_studNo);


  // Create a FormData object to send the form data
  let formData = new FormData();
  formData.append('table-name', table_name);
  formData.append('rejected-studNo', rejected_studNo);


  fetch('../php/toRejectScholar.php', {
    method: 'POST',
    body: formData
  })
    .then(function (response) {
      return response.text();
    })
    .then(function (data) {

      // SUCCESSFULLY ADDED
      const reject_toast = document.getElementById('reject-toast');
      bootstrap.Toast.getOrCreateInstance(reject_toast).show();

      dismissCertificateModal(rejected_studNo);
      fetchPendingScholars(table_name);
      sendEmailReject(email, fname, lname, reasons);
      dismissReasonModal();
      var textarea = document.getElementById("reason-input");
      textarea.value = "";


    })
    .catch(function (error) {
      console.error('Error:', error);
    });
}

function dismissCertificateModal(approve_studNo) {

  new bootstrap.Modal(document.getElementById('modal-' + approve_studNo)).hide();
}


//Modal Instance
var reason_modal = document.getElementById('rejectReasonModal');
var ReasonModalInstance = new bootstrap.Modal(reason_modal);
function dismissReasonModal() {
  ReasonModalInstance.hide();
}


//Email for Reject
function sendEmailReject(email, fname, lname, emailReason) {
  let formData = new FormData();
  formData.append('email', email);
  formData.append('fname', fname);
  formData.append('lname', lname);
  formData.append('emailReason', emailReason);



  fetch('../php/sendEmailReject.php', { // Correct the URL path
    method: 'POST',
    body: formData
  })
    .then(function (response) {
      if (response.ok) {
        return response.text();
      } else {
        throw new Error('Failed to send OTP email');
      }
    })
    .then(function (responseText) {
      // You can handle the responseText here if needed
      console.log('Email sent:', responseText);
    })
    .catch(function (error) {
      console.error('Error:', error);
    });

}


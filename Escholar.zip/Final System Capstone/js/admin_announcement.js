var full_name;
function actLogs(firstname, lastname) {

    full_name = firstname + ' ' + lastname;

}

function fetchAnnouncement() {
    $('#announcement-table').DataTable().destroy();

    const tableBody = document.getElementById("announcement-table-body");

    // Function to format a timestamp
    const formatTimestamp = (timestamp) => {
        const date = new Date(timestamp);
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString(undefined, options);
    };



    // Function to display data in the table
    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            tableBody.innerHTML += `
              <tr>
                <td>${row.id}</td>
                <td>${row.title}</td>
                <td style="min-width: 700px; text-align: left;">${row.description}</td>
                <td>${row.url}</td>
                <td>${formatTimestamp(row.date_created)}</td>
                <td style="width: 100px; white-space: nowrap;">
                  <button id="${row.id}" style="width: 100px;" class="btn btn-save text-light btn-sm w-100 mb-2 d-flex flex-nowrap align-items-center justify-content-center" data-bs-toggle="modal" data-bs-target="#editModal" onclick="editAnnouncement('${row.id}')"><i class="bi bi-pencil-square me-1"></i>Edit</button>
                  <button id="${row.id}" style="width: 100px;"  class="btn btn-del text-light btn-sm w-100 mb-2 d-flex flex-nowrap align-items-center justify-content-center" type="button" onclick="archiveAnnouncement(${row.id})"><i class="bi bi-archive me-0 me-sm-1" ></i>Archive</button>
                </td>
              </tr>
          `;
        });

        // Now, after adding data to the table, you can set the width of the description column using DataTables' API.
        $('#announcement-table').DataTable();
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    fetch("../php/getAnnouncement.php", {
        method: 'POST',
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data

            if (Array.isArray(data.data)) {
                displayData(data.data); // Pass the "data" property of the response
            } else {
                // Handle the case where data is not an array
                handleError("Data is not an array");
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}


function fetchGallery() {
    $('#gallery-table').DataTable().destroy();

    const tableBody = document.getElementById("gallery-table-body");

    // Function to display data in the table
    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            tableBody.innerHTML += `
              <tr>
                <td>${row.stack_order}</td>
                <td>${row.file_name}</td>
                <td  style="width: 100px; white-space: nowrap;">

                <div class="modal fade" id="delete-gallery-modal${row.id}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Gallery</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Are you sure you want to delete ${row.file_name}?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal" onclick="deleteGallery(${row.id})">Delete</button>
                        </div>
                        </div>
                    </div>
                </div>

                        <button id="${row.id}" class="btn btn-del text-light btn-sm w-100 mb-2 d-flex flex-nowrap align-items-center justify-content-center" type="button" data-bs-toggle="modal" data-bs-target="#delete-gallery-modal${row.id}"><i class="bi bi-trash me-0 me-sm-1" ></i>Delete</button>
                </td>
              </tr>
          `;
        });

        // Now, after adding data to the table, you can set the width of the description column using DataTables' API.
        $('#gallery-table').DataTable();
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10'>An error occurred while fetching data.</td></tr>";
    };

    fetch("../php/getGallery.php", {
        method: 'POST',
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data

            if (Array.isArray(data.data)) {
                displayData(data.data); // Pass the "data" property of the response
            } else {
                // Handle the case where data is not an array
                handleError("Data is not an array");
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

function deleteGallery(id) {
    console.log("ID: ", id);

    var formData = new FormData();
    formData.append('id', id);

    fetch('../php/toDeleteGallery.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log(data);

            // Check for success and handle accordingly
            if (data.success) {

                const success_delete_toast = document.getElementById('success-delete-toast');
                bootstrap.Toast.getOrCreateInstance(success_delete_toast).show();

            } else {
                console.error('Error deleting announcement:', data.error);
                const failed_delete_toast = document.getElementById('failed-delete-toast');
                bootstrap.Toast.getOrCreateInstance(failed_delete_toast).show();
            }
            fetchAnnouncement();
            fetchGallery();

        })
        .catch(function (error) {
            console.error('Error deleting announcement:', error);
        });
}



// Add Announcement
function addAnnouncement() {
    var title = document.getElementById('title').value;
    var description = document.getElementById('description').value;
    var url = document.getElementById('url').value;
    var filesInput = document.getElementById('file-announcement');
    var supportingDocu = document.getElementById('supporting-document');
    var user = full_name;

    console.log("fullname", user);
    console.log(filesInput);
    console.log("HELLO");

    // Validate inputs
    // Validate inputs
    if (title.trim() === '' || description.trim() === '') {
        // Display validation error
        const alertContainer = document.getElementById('alert-container');
        const alertText = document.getElementById('alert-text');
        alertText.innerText = 'Please fill in title and description.';
        alertContainer.style.display = 'block';
        return;
    }

    // Additional custom validation for title (e.g., minimum length)
    if (title.length < 5) {
        // Display validation error for title length
        const alertContainer = document.getElementById('alert-container');
        const alertText = document.getElementById('alert-text');
        alertText.innerText = 'Title must be at least 5 characters.';
        alertContainer.style.display = 'block';
        return;
    }

    // Additional custom validation for description (e.g., minimum length)
    if (description.length < 10) {
        // Display validation error for description length
        const alertContainer = document.getElementById('alert-container');
        const alertText = document.getElementById('alert-text');
        alertText.innerText = 'Description must be at least 10 characters.';
        alertContainer.style.display = 'block';
        return;
    }


    // Validate URL format if it's not empty
    if (url.trim() !== '') {
        const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;

        if (!url.match(urlRegex)) {
            // Display validation error for incorrect URL format
            const alertContainer = document.getElementById('alert-container');
            const alertText = document.getElementById('alert-text');
            alertText.innerText = 'Please enter a valid URL.';
            alertContainer.style.display = 'block';
            return;
        }
    }

    // Create FormData object and append data
    let formData = new FormData();
    formData.append('title', title);

    // Preserve line breaks in description
    formData.append('description', description.replace(/\n/g, '<br>'));

    formData.append('url', url);
    formData.append('user', user);


    // Append the file, if selected
    if (filesInput.files.length > 0) {
        const file = filesInput.files[0];
        formData.append('file', file);
        formData.append('fileType', file.type); // Append file type
    }
    // Append the file, if selected
    if (supportingDocu.files.length > 0) {
        const supportingFile = supportingDocu.files[0];
        formData.append('supporting-file', supportingFile);
        formData.append('supporting-file-type', supportingFile.type); // Append file type
    }



    // Send the form data to a PHP script using AJAX
    fetch('../php/toAddAnnouncement.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            // SUCCESSFULLY ADDED
            const success_toast = document.getElementById('success-add-toast');
            bootstrap.Toast.getOrCreateInstance(success_toast).show();

            // Reset announcement elements to default values
            document.getElementById('announcement_title').innerText = 'Title';
            document.getElementById('announcement_description').innerHTML = 'Description<br>'; // Preserve line breaks
            document.getElementById('announcement_link').innerText = '...';
            document.getElementById('announcement_link').href = '#';

            // Log the FormData content
            const formDataArray = [];
            formData.forEach((value, key) => {
                formDataArray.push(`${key}: ${value}`);
            });
            console.log(formDataArray);

            // Hide the alert
            const alertContainer = document.getElementById('alert-container');
            alertContainer.style.display = 'none';

            dismissAnnouncementModal(); // alisin ko muna to kasi nagloloko modal kaso di naman magsasara kapag wala neto

            return response.text();
        })
        .then(function (data) {
            // Display the response from the PHP script
            // document.getElementById('alert-result').innerHTML = data;

            // document.getElementById('result').innerText = "";
            document.getElementById('form-announcement').reset();
            fetchAnnouncement();
            getAllEmails();
        })
        .catch(function (error) {
            console.error('Error:', error);
        });
}


//Send Email When Add an Announcement
function getAllEmails() {
    return fetch('../php/getAllEmails.php', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    })
        .then(response => {
            console.log('Response status:', response.status); // Log the status code
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Assuming the emails are stored in an array under the 'emails' key in the response
                const emails = data.emails;

                // Loop through the emails and call sendEmail for each
                emails.forEach(email => {
                    sendEmail(email);
                });

                return emails;
            } else {
                // Handle the case where the request was successful but the response indicates an error
                throw new Error('Error getting emails: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            // Handle the error, e.g., display an error message to the user
            throw error; // Rethrow the error to be caught further up the promise chain
        });
}

function sendEmail(emails) {
    let formData = new FormData();
    formData.append('emails', emails);

    console.log("sending email to ", emails);

    fetch('../php/sendAnnouncementEmail.php', { // Correct the URL path
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            if (response.ok) {
                return response.text();
            } else {
                throw new Error('Failed to send email');
            }
        })
        .then(function (responseText) {
            // You can handle the responseText here if needed
            console.log('Email sent:', responseText);
        })
        .catch(function (error) {
            console.error('Error:', error);
        });
}

// Add Announcement

//Modal Instance
var announcement_modal = document.getElementById('add-announcement');
var AnnouncementModalInstance = new bootstrap.Modal(announcement_modal);
function dismissAnnouncementModal() {
    AnnouncementModalInstance.hide();
}




function editAnnouncement(id) {
    // Fetch data for the specific announcement to be edited
    fetch(`../php/getAnnouncementID.php?id=${id}`, {
        method: 'GET',
    })
        .then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            // Populate the edit modal with the retrieved data
            const editModal = document.getElementById("editModal");
            const modalTitle = editModal.querySelector(".modal-title");
            const modalBody = editModal.querySelector(".modal-body");

            // Set modal title and input values with retrieved data
            modalTitle.textContent = "Edit Announcement";
            modalBody.innerHTML = `
                <input type="hidden" id="editId" value="${data.id}">
                <div class="alert alert-danger mb-2" role="alert" id="edit-alert-container" style="display: none;">
                    <i class="bi bi-exclamation-circle me-2"></i><span id="edit-alert-text"></span>
                </div>
                <div class="mb-3">
                    <label for="editTitle" class="form-label">Title:</label>
                    <input type="text" class="form-control" id="editTitle" value="${data.title}">
                </div>
                <div class="mb-3">
                    <label for="editDescription" class="form-label">Description:</label>
                    <textarea class="form-control" id="editDescription" style="height: 100px">${data.description.replace(/<br>/g, '\n')}</textarea>

                </div>
                <div class="mb-3">
                    <label for="editUrl" class="form-label">URL:</label>
                    <input type="text" class="form-control" id="editUrl" value="${data.url}">
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-floating mb-2">
                            <input type="file" id="edit-file-announcement" class="form-control" placeholder="${data.file_name}" accept=".jpeg, .jpg, .png" onchange="handleFileSelect(event)" />
                            <label class="form-label" for="file-announcement">Image</label>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-floating mb-2">
                            <input type="file" id="edit-supporting-document" class="form-control" placeholder=" " accept=".pdf, .xlsx, .xls, .doc, .docx" onchange="handleSupportingSelect(event)" />
                            <label class="form-label" for="supporting-document">Upload Supporting Documents</label>
                        </div>
                    </div>
                </div>
            `;

            // Show the edit modal
            const saveButton = editModal.querySelector(".save-btn");
            saveButton.addEventListener("click", () => saveEditedData());
            $('#editModal').modal('show');
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            // Handle the error
        });
}


function saveEditedData() {
    const editId = document.getElementById("editId").value;
    const editTitle = document.getElementById("editTitle").value;
    const editDescriptionElement = document.getElementById("editDescription");
    const editUrl = document.getElementById("editUrl").value;
    const filesInput = document.getElementById("edit-file-announcement");
    const supportingDocu = document.getElementById("edit-supporting-document");
    const user = full_name;

    // Get the value of the description field and replace newline characters with <br> tags
    const editDescription = editDescriptionElement.value.replace(/\n/g, '<br>');

    // Validate inputs
    if (editTitle.trim() === '' || editDescription.trim() === '') {
        // Display validation error
        const alertContainer = document.getElementById('edit-alert-container');
        const alertText = document.getElementById('edit-alert-text');
        alertText.innerText = 'Please fill in title and description.';
        alertContainer.style.display = 'block';
        return;
    }

    // Additional custom validation for title (e.g., minimum length)
    if (editTitle.length < 5) {
        // Display validation error for title length
        const alertContainer = document.getElementById('edit-alert-container');
        const alertText = document.getElementById('edit-alert-text');
        alertText.innerText = 'Title must be at least 5 characters.';
        alertContainer.style.display = 'block';
        return;
    }

    // Additional custom validation for description (e.g., minimum length)
    if (editDescription.length < 10) {
        // Display validation error for description length
        const alertContainer = document.getElementById('edit-alert-container');
        const alertText = document.getElementById('edit-alert-text');
        alertText.innerText = 'Description must be at least 10 characters.';
        alertContainer.style.display = 'block';
        return;
    }

    // Create FormData object and append data
    let formData = new FormData();
    formData.append('id', editId);
    formData.append('title', editTitle);
    formData.append('description', editDescription);
    formData.append('url', editUrl);
    formData.append('user', user);

    // Append the main file, if selected
    if (filesInput.files.length > 0) {
        const file = filesInput.files[0];
        formData.append('file', file);
        formData.append('fileType', file.type); // Append file type
    }

    // Append the supporting file, if selected
    if (supportingDocu.files.length > 0) {
        const supportingFile = supportingDocu.files[0];
        formData.append('supporting-file', supportingFile);
        formData.append('supporting-file-type', supportingFile.type); // Append file type
    }

    // Send the form data to a PHP script using AJAX
    fetch('../php/toUpdateAnnouncement.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // SUCCESSFULLY ADDED
            const success_toast = document.getElementById('success-update-toast');
            bootstrap.Toast.getOrCreateInstance(success_toast).show();
            return response.json();
        })
        .then(function (data) {
            // Handle the response from the server after saving
            // You can show a success message or update the table with the edited data
            console.log("Data saved:", data);
            $('#editModal').modal('hide');
            fetchAnnouncement(); // Refresh the table with updated data
        })
        .catch(function (error) {
            console.error("Fetch error:", error);
            // Handle the error
        });
}



function archiveAnnouncement(id) {
    console.log("ID: ", id);
    var user = full_name;


    var formData = new FormData();
    formData.append('id', id);
    formData.append('user', user);

    fetch('../php/toArchiveAnnouncement.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log("ETO LUMABAS" + data);

            // Check for success and handle accordingly
            if (data.success) {
                fetchAnnouncement();
                const success_toast = document.getElementById('success-archive-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();
            } else {
                console.error('Error archiving announcement:', data.error);
            }
        })
        .catch(function (error) {
            console.error('Error archiving announcement:', error);
        });
}

//Modal Instance
var gallery_modal = document.getElementById('add-gallery');
var galleryModalInstance = new bootstrap.Modal(gallery_modal);
function dismissGalleryModal() {
    galleryModalInstance.hide();
}


// GALLERY
function addGallery() {

    var filesInput = document.getElementById('file-gallery');
    var user = full_name;

    console.log("fullname", user);
    console.log(filesInput);
    console.log("HELLO");

    // Validate file input
    if (filesInput.files.length === 0) {
        // Display validation error for no selected file
        const alertContainer = document.getElementById('alert-container-gallery');
        const alertText = document.getElementById('alert-text-gallery');
        alertText.innerText = 'Please select an image file.';
        alertContainer.style.display = 'block';
        return;
    }

    let formData = new FormData();
    formData.append('file', filesInput.files[0]);
    formData.append('user', user);

    // Send the form data to a PHP script using AJAX
    fetch('../php/toAddGallery.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {

            // Log the FormData content
            const formDataArray = [];
            formData.forEach((value, key) => {
                formDataArray.push(`${key}: ${value}`);
            });
            console.log(formDataArray);
            return response.json();
        })
        .then(function (data) {
            console.log("GALLERY DATA: " + data);

            if (data.success) {
                const success_toast = document.getElementById('success-add-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();

                // Hide the alert
                const alertContainer = document.getElementById('alert-container-gallery');
                alertContainer.style.display = 'none';

                dismissGalleryModal();
            }
            else {
                const alertContainer = document.getElementById('alert-container-gallery');
                const alertText = document.getElementById('alert-text-gallery');
                alertText.innerText = 'Error adding gallery.';
                alertContainer.style.display = 'block';
            }
            // document.getElementById('result').innerText = "";

            const preview = document.getElementById('image-gallery-preview');
            preview.style.display = 'none';

            document.getElementById('form-gallery').reset();
            fetchGallery();
        })
        .catch(function (error) {
            console.error('Error:', error);
        });
}
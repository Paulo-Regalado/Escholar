document.addEventListener('DOMContentLoaded', function () {
    const requirementForm = document.getElementById('renewal-form');
    const successToast = new bootstrap.Toast(document.getElementById('success-add-toast'));

    requirementForm.addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent the default form submission

        var student_number = document.getElementById('student_number').value;
        var unit = document.getElementById('unit').value;
        var gwa = document.getElementById('gwa').value;
        var cor = document.getElementById('cor');
        var cor_file = cor.files[0];
        var cog = document.getElementById('cog');
        var cog_file = cog.files[0];
        var id = document.getElementById('id');
        var id_file = id.files[0];


        // Create a FormData object to send the form data
        let formData = new FormData();

        formData.append('student_number', student_number);
        formData.append('unit', unit);
        formData.append('gwa', gwa);
        formData.append('cor_file', cor_file);
        formData.append('cog_file', cog_file);
        formData.append('id_file', id_file);



        // Send the form data to a PHP script using AJAX
        fetch('../php/toSendRequirement.php', {
            method: 'POST',
            body: formData
        })
            .then(function (response) {

                successToast.show(); // Show the toast
                dismissModal();
                return response.text();

            })
            .then(function (data) {
                // Display the response from the PHP script
                // document.getElementById('alert-result').innerHTML = data;


                console.log(data);
                // document.getElementById('renewal-form').reset();
                window.location.href = 'dashboard.php';


            })
            .catch(function (error) {
                console.error('Error:', error);
            });


    });
});


var term_modal = document.getElementById('term');
var TermModalInstance = new bootstrap.Modal(term_modal);

function dismissModal() {
    TermModalInstance.hide();
}
// Initialize the DataTable when the page loads
var table = $('#pending-table').DataTable({
    "paging": true,
    "lengthChange": false,
    "searching": true,
    "info": false,
    "autoWidth": true
});

function fetchPendingScholars() {
    $.ajax({
        type: "POST",
        url: "../php/pendingAPI.php", // Corrected the file extension
        data: {},
        success: function (response) {
            // Clear the existing table rows and add new rows
            table.clear().draw();
            table.rows.add($(response)).draw();
        },
        error: function () {
            alert('Something went wrong with the AJAX request.');
        }
    });
}

// Call the function to initially populate the table
fetchPendingScholars();

// ADD ACCOUNT+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

function addAdminAccount() {

    const alert = document.getElementById('account-alert');

    var lastName = document.getElementById('account-lastname').value;
    var firstName = document.getElementById('account-firstname').value;
    var middleName = document.getElementById('account-middle').value;
    var username = document.getElementById('account-username').value;
    var password = document.getElementById('account-password').value;
    var retype_password = document.getElementById('account-retype').value;

    // Trim input values
    var lastName = lastName.trim();
    var firstName = firstName.trim();
    var middleName = middleName.trim();
    var username = username.trim();
    var password = password.trim();
    var retype_password = retype_password.trim();

    // Convert names to uppercase
    // Convert last name to sentence case (first letter uppercase, rest lowercase)
    lastName = lastName.charAt(0).toUpperCase() + lastName.slice(1).toLowerCase();

    // Convert first letter of first name to uppercase and the rest to lowercase
    firstName = firstName.charAt(0).toUpperCase() + firstName.slice(1).toLowerCase();

    // Convert first letter of middle name to uppercase and the rest to lowercase
    middleName = middleName.charAt(0).toUpperCase() + middleName.slice(1).toLowerCase();

    if (!lastName || !firstName || !username || !password) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Please fill out all required fields.</div>';
    }
    else if (!/^[a-zA-Z ]+$/.test(lastName)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Last name should only contain letters.</div>';
    }
    else if (!/^[a-zA-Z ]+$/.test(firstName)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">First name should only contain letters.</div>';
    }
    else if (username.length != 10) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Account Number must be 10 digits.</div>';
    }
    else if (!/^\d+$/.test(username)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Username should only contain numbers.</div>';
    }
    else if (/\s/.test(username)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Username should not contain empty spaces.</div>';
    }
    else if (password !== retype_password) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Passwords do not match.</div>';
    }
    else if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/\d/.test(password)) {
        alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">Password must be at least 8 characters long and include both letters and numbers.</div>';
    }
    else {


        // Reset the alert if there were previous error messages
        alert.innerHTML = '';

        let formData = new FormData();
        formData.append('lastname', lastName);
        formData.append('firstname', firstName);
        formData.append('middlename', middleName);
        formData.append('account-username', username);
        formData.append('account-password', password);

        // Send the form data to a PHP script using AJAX
        fetch('../php/toAddAccount.php', {
            method: 'POST',
            body: formData
        })
            .then(function (response) {
                return response.json(); // Parse the response as JSON
            })
            .then(function (data) {
                console.log(data);
                if (data.success) {
                    // If the server response indicates success
                    alert.innerHTML = '<div class="alert alert-success m-0" role="alert">' + data.message + '</div>';
                    // Optionally, you can reset the form or perform other actions upon successful addition
                    const success_add_toast = document.getElementById('success-add-toast');
                    bootstrap.Toast.getOrCreateInstance(success_add_toast).show();
                    dismissAddModal();
                } else {
                    // If the server response indicates an error
                    alert.innerHTML = '<div class="alert alert-danger m-0" role="alert">' + data.message + '</div>';
                    const failed_add_toast = document.getElementById('failed-add-toast');
                    bootstrap.Toast.getOrCreateInstance(failed_add_toast).show();
                }
                document.getElementById('form-add').reset();
                fetchAdmin();
                fetchUser();

            })
            .catch(function (error) {
                console.error('Error:', error);
            });

    }
}

//Modal Instance
var add_modal = document.getElementById('addaccount');
var AddModalInstance = new bootstrap.Modal(add_modal);
function dismissAddModal() {
    AddModalInstance.hide();
}

function fetchAdmin() {
    $('#table-admin').DataTable().destroy();
    const tableBody = document.getElementById("table-admin-body");

    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            const newRow = document.createElement("tr");
            tableBody.innerHTML += `
            <td class="text-center">${row.account_number}</td>
              <td>${row.last_name}</td>
              <td>${row.first_name}</td>
              <td>${row.middle_name}</td>
              <td>

              <div class="modal fade" id="modal-remove-admin${row.account_id}" tabindex="-1"aria-hidden="true">
              <div class="modal-dialog  modal-dialog-centered">
                  <div class="modal-content">
                  <div class="modal-header">
                      <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Account</h1>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <div class="container-fluid">
                    Are you sure you want to delete <strong class="text-danger">${row.account_number}</strong>?
                    </div>
                      
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-del" onclick="deleteAdminAccount(${row.account_id})">Delete</button>
                  </div>
                  </div>
              </div>
              </div>

                  <div class="d-flex justify-content-center">
                      <button class="btn btn-del text-light btn-sm mb-1 mx-1" style="max-width: 150px;" data-bs-toggle="modal" data-bs-target="#modal-remove-admin${row.account_id}"><i class="bi bi-x-circle me-0 me-md-1 "></i><span class="d-none d-md-inline">Remove</span></button>
                  </div>
              </td>
          `;
        });
        $('#table-admin').DataTable();
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10' class='text-center'>An error occurred while fetching data.</td></tr>";
    };

    // AJAX fetch request
    fetch("../php/getAdminAccount.php")
        .then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();

        })
        .then((data) => {
            console.log(data);
            displayData(data);

        })
        .catch((error) => {
            handleError(error);
        });
}


function fetchUser() {

    $('#table-user').DataTable().destroy();
    const tableBody = document.getElementById("table-user-body");

    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            const newRow = document.createElement("tr");
            tableBody.innerHTML += `
            <td class="d-flex justify-content-center">${row.student_number}</td>
            <td>
                <div class="d-flex justify-content-center">

                <div class="modal fade" id="modal-remove-user${row.student_number}" tabindex="-1"aria-hidden="true">
            <div class="modal-dialog  modal-dialog-centered">
                <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Account</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <div class="container-fluid">
                  Are you sure you want to delete <strong class="text-danger">${row.student_number}</strong>?
                  </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-del" onclick="deleteUserAccount(${row.student_number})">Delete</button>
                </div>
                </div>
            </div>
            </div>

                    <button class="btn btn-del text-light btn-sm mb-1 mx-1" style="max-width: 150px;" data-bs-toggle="modal" data-bs-target="#modal-remove-user${row.student_number}"><i class="bi bi-x-circle me-0 me-md-1 "></i><span class="d-none d-md-inline">Remove</span></button>
                </div>
            </td>
        `;
        });
        $('#table-user').DataTable();
    };

    // Function to handle errors
    const handleError = (error) => {
        console.error("Error:", error);
        tableBody.innerHTML = "<tr><td colspan='10' class='text-center'>An error occurred while fetching data.</td></tr>";
    };

    // AJAX fetch request
    fetch("../php/getUserAccount.php")
        .then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();

        })
        .then((data) => {
            console.log(data);
            displayData(data);

        })
        .catch((error) => {
            handleError(error);
        });



}


function deleteAdminAccount(account_id) {
    console.log("account_id: ", account_id);
    // var user = full_name;

    var formData = new FormData();
    formData.append('account_id', account_id);
    // formData.append('user', user);

    fetch('../php/toDeleteAdminAccount.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log(data);

            // Check for success and handle accordingly
            if (data.success) {

                const success_delete_toast = document.getElementById('success-delete-toast');
                bootstrap.Toast.getOrCreateInstance(success_delete_toast).show();

            } else {
                console.error('Error deleting admin:', data.error);
                const failed_delete_toast = document.getElementById('failed-delete-toast');
                bootstrap.Toast.getOrCreateInstance(failed_delete_toast).show();
            }
            fetchAdmin();
            fetchUser();
            dismissDeleteAdminModal(account_id);

        })
        .catch(function (error) {
            console.error('Error deleting admin:', error);
        });
}

function deleteUserAccount(student_number) {
    console.log("student_number: ", student_number);
    // var user = full_name;

    var formData = new FormData();
    formData.append('student_number', student_number);
    // formData.append('user', user);

    fetch('../php/toDeleteUserAccount.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log(data);

            // Check for success and handle accordingly
            if (data.success) {

                const success_delete_toast = document.getElementById('success-delete-toast');
                bootstrap.Toast.getOrCreateInstance(success_delete_toast).show();

            } else {
                console.error('Error deleting user:', data.error);
                const failed_delete_toast = document.getElementById('failed-delete-toast');
                bootstrap.Toast.getOrCreateInstance(failed_delete_toast).show();
            }
            fetchAdmin();
            fetchUser();
            dismissDeleteUserModal(student_number);

        })
        .catch(function (error) {
            console.error('Error deleting admin:', error);
        });
}

function dismissDeleteAdminModal(account_id) {
    const modal = document.getElementById(`modal-remove-admin${account_id}`);
    const modalInstance = bootstrap.Modal.getInstance(modal);
    modalInstance.hide();
}

function dismissDeleteUserModal(student_number) {
    const modal = document.getElementById(`modal-remove-user${account_id}`);
    const modalInstance = bootstrap.Modal.getInstance(modal);
    modalInstance.hide();
}
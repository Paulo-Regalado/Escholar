document.addEventListener("DOMContentLoaded", function () {
    fetchScholars();
});

var full_name;
function actLogs(firstname, lastname) {

    full_name = firstname + ' ' + lastname;

}


function fetchScholars() {
    $('#masterlist-table').DataTable().destroy();

    const tableBody = document.getElementById("masterlist-table-body");

    // Function to display data in the table
    const displayData = (data) => {
        tableBody.innerHTML = ""; // Clear previous data

        data.forEach((row) => {
            tableBody.innerHTML += `
              <tr>
                <td>${row.benefactor_name}</td>
                <td>${row.status}</td>
                <td>${row.student_number}</td>
                <td>${row.last_name}</td>
                <td>${row.first_name}</td>
                <td>${row.middle_name}</td>
                <td>${row.email}</td>
                <td>${row.contact}</td>
                <td>${row.campus}</td>
                <td>${row.college}</td>
                <td nowrap>${row.course}</td>
                <td>${row.year_level}</td>
                <td>${row.gwa}</td>
                <td>${row.units}</td>
                <td style="width: 100px; white-space: nowrap;">

                <div class="modal fade" id="modal-delete${row.id}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Masterlist Data</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
                      
                        Are you sure you want to delete ${row.benefactor_name} - ${row.student_number}?
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-danger" onclick="deleteMasterlist(${row.id})">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
            

                    <button style="width: 100%;" id="${row.student_number}"  class="btn btn-success btn-sm my-1" type="button" onclick="restoreMasterlist('${row.id}', '${row.table_name}', '${row.student_number}', '${row.status}')"><i class="bi bi-archive me-0 me-sm-1"></i>Restore</button>
                    <button style="width: 100%;" type="button" class="btn btn-danger delete-btn btn-sm  mb-2 w-100 d-flex flex-nowrap align-items-center justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-delete${row.id}" >
                    <i class="bi bi-trash me-1"></i>Delete
                      </button>
                    </td>
              </tr>
          `;
        });
        $('#masterlist-table').DataTable({
            "columnDefs": [
                {
                    "targets": 0,
                    "width": "1000px"
                }
            ]
        });
    };

    // AJAX fetch request
    fetch("../php/getArchivedMasterlist.php", {
        method: 'POST',
        // Commenting out the 'body' attribute to send an empty POST request
        // body: formData
    })
        .then((response) => {
            if (!response.ok) {
                console.log("Response status:", response.status); // Log response status
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log("Received data:", data); // Log received data
            displayData(data);
        })
        .catch((error) => {
            console.error("Fetch error:", error); // Log fetch error
            handleError(error);
        });
}

function restoreMasterlist(id, table_name, student_number, status) {
    console.log("ID: ", id);
    console.log("Student No: ", table_name);
    console.log("Table Name: ", student_number);
    console.log("Status: ", status);
    var user = full_name;

    var formData = new FormData();
    formData.append('id', id);
    formData.append('table_name', table_name);
    formData.append('student_number', student_number);
    formData.append('status', status);
    formData.append('user', user);

    fetch('../php/toRestoreMasterlist.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {

            // Check for success and handle accordingly
            if (data.success) {
                fetchScholars();
                const success_toast = document.getElementById('success-restore-toast');
                bootstrap.Toast.getOrCreateInstance(success_toast).show();
            } else {
                fetchScholars();
                const failed_toast = document.getElementById('failed-restore-toast');
                bootstrap.Toast.getOrCreateInstance(failed_toast).show();
                console.error('Error restoring benefactor:', data.error);
            }
        })
        .catch(function (error) {
            console.error('Error restoring benefactor:', error);
        });

}


function deleteMasterlist(id) {
    console.log("ID: ", id);
    var user = full_name;

    var formData = new FormData();
    formData.append('id', id);
    formData.append('user', user);

    fetch('../php/toDeleteMasterlist.php', {
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log(data);

            // Check for success and handle accordingly
            if (data.success) {

                const success_delete_toast = document.getElementById('success-delete-toast');
                bootstrap.Toast.getOrCreateInstance(success_delete_toast).show();

            } else {
                console.error('Error deleting masterlist:', data.error);
                const failed_delete_toast = document.getElementById('failed-delete-toast');
                bootstrap.Toast.getOrCreateInstance(failed_delete_toast).show();
            }
            fetchScholars();
            dismissDeleteModal(id);

        })
        .catch(function (error) {
            console.error('Error deleting masterlist:', error);
        });
}



function dismissDeleteModal(id) {
    const modal = document.getElementById(`modal-delete${id}`);
    const modalInstance = bootstrap.Modal.getInstance(modal);
    modalInstance.hide();
}

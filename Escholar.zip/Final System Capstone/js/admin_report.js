document.addEventListener('DOMContentLoaded', () => {

    // Fetch data using the Fetch API
    fetch('../php/getScholarsReport.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            Highcharts.chart('total-scholars', {
                chart: {
                    type: 'column'
                },
                title: {
                    align: 'center',
                    text: 'TOTAL SCHOLARS PER BENEFACTOR'
                },
                subtitle: {
                    align: 'center',
                    text: ''
                },
                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total numbers of scholars'
                    }

                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    series: {
                        borderWidth: 0,
                        dataLabels: {
                            enabled: true,
                            format: '{point.y}'
                        }
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },

                series: [
                    {
                        name: 'Benefactor',
                        colorByPoint: true,
                        data: data
                    }
                ]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });


    // Fetch Graduates
    fetch('../php/getGraduateReport.php') // Update the URL to the correct endpoint
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            Highcharts.chart('total-graduates', {
                chart: {
                    type: 'pie'
                },
                title: {
                    align: 'center',
                    text: 'TOTAL GRADUATES PER BATCH' // Update chart title
                },

                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total numbers of Graduate'
                    }
                },
                legend: {
                    enabled: true, // Enable legend for pie chart
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.y} ({point.percentage:.0f}%)' // Show whole number percentage
                        },
                        showInLegend: true // Display in legend
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },
                // ... (rest of the Highcharts configuration remains the same)

                // Add or update the series data with the fetched data
                series: [{
                    name: 'Total Graduates',
                    colorByPoint: true,
                    data: data // Use the actual property from your data
                }]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });


    // Fetch Scholars Per College
    fetch('../php/getScholarsPerCollege.php') // Update the URL to the correct endpoint
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            Highcharts.chart('total-college-scholar', {
                chart: {
                    type: 'pie'
                },
                title: {
                    align: 'center',
                    text: 'TOTAL SCHOLARS PER COLLEGE' // Update chart title
                },

                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total numbers of Scholars'
                    }
                },
                legend: {
                    enabled: true, // Enable legend for pie chart
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.y} ({point.percentage:.0f}%)' // Show whole number percentage
                        },
                        showInLegend: true // Display in legend
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },
                // ... (rest of the Highcharts configuration remains the same)

                // Add or update the series data with the fetched data
                series: [{
                    name: 'Total Scholars',
                    colorByPoint: true,
                    data: data // Use the actual property from your data
                }]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });

});
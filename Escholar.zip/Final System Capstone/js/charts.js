// JavaScript to populate the select options from PHP
let selectedOption;
document.addEventListener('DOMContentLoaded', function () {
    populateSelect();



});


// JavaScript to filter the select options
function filterSelect() {
    // Get the selected option value
    var select = document.getElementById("mySelect");
    selectedOption = select.options[select.selectedIndex].value;

    // Call getBenefactor function with the selected option value
    getBenefactor(selectedOption);
    getScholarsCollege(selectedOption)
    getGraduate();
    getTotalBenefactor(selectedOption);
}
// JavaScript to filter the select options

// JavaScript to populate select options in filter
function populateSelect() {
    var select = document.getElementById("mySelect");

    // Make an AJAX request to fetch data from PHP
    fetch('../php/getSelectData.php')
        .then(response => response.json())
        .then(data => {
            // Loop through the data and create options
            data.forEach(item => {
                var option = document.createElement("option");
                option.value = item.from_sy + '-' + item.to_sy + '-' + item.semester;
                option.text = item.from_sy + '-' + item.to_sy + ' ' + item.semester + ' Semester';
                select.appendChild(option);
            });

            // Set the first option as selected by default
            select.options[0].selected = true;

            // Call getBenefactor function with the selected option value
            selectedOption = select.options[select.selectedIndex].value;
            getBenefactor(selectedOption);
            getScholarsCollege(selectedOption)
            getGraduate();
            getTotalBenefactor(selectedOption);
        })
        .catch(error => console.error('Error fetching data:', error));

    // // Now, add an event listener to the filter button
    // var filterButton = document.getElementById("filterButton");
    // filterButton.addEventListener('click', function () {
    //     // Call getBenefactor function with the selected option value
    //     var selectedOption = select.options[select.selectedIndex].value;
    //     getBenefactor(selectedOption);
    //     getScholarsCollege(selectedOption);
    //     getGraduate();
    //     getTotalBenefactor(selectedOption);
    // });
}
// JavaScript to populate select options in filter


/*Download Selected in Approve Scholars Per benefactor*/
const benefactorSelect = document.getElementById('benefactorSelect');

// Function to get Approve Scholar per benefactor
function getBenefactor(selectedOption) {
    // Make an AJAX request to fetch scholars per campus from PHP
    fetch('../php/getApprovedScholarsReport.php?selectedOption=' + selectedOption)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            // Identify the select element


            // Remove existing options
            benefactorSelect.innerHTML = '<option selected disabled hidden>Benefactor</option>';

            // Loop through the data and append new options
            data.forEach(item => {
                const benefactorName = item.name.toUpperCase(); // Access 'name' property
                const option = document.createElement('option');
                option.value = benefactorName;
                option.textContent = benefactorName;
                benefactorSelect.appendChild(option);
            });

            Highcharts.chart('approve-per-benefactor', {
                chart: {
                    type: 'pie'
                },
                title: {
                    align: 'center',
                    text: 'APPROVE SCHOLARS PER BENEFACTOR' // Update chart title
                },

                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total approve per benefactor'
                    }
                },
                legend: {
                    enabled: true, // Enable legend for pie chart
                    layout: 'horizontal',
                    align: 'center', // Align center to position at the bottom
                    verticalAlign: 'bottom' // Position at the bottom
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.y} ({point.percentage:.0f}%)'
                        },
                        showInLegend: true // Display in legend
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },

                // Add or update the series data with the fetched data
                series: [{
                    name: 'Approve Scholars Per Benefactor',
                    colorByPoint: true,
                    data: data // Use the actual property from your data
                }]
            });

        })


        .catch(error => {
            console.error('Error fetching data:', error);
        });


}

const approvePrintButton = document.getElementById('approvePrint');
approvePrintButton.addEventListener('click', function () {
    const selectedBenefactor = benefactorSelect.value;
    // Trigger download or printing based on the selected benefactor
    downloadOrPrintData(selectedBenefactor, selectedOption);
});

// Function to download or print data based on the selected benefactor
function downloadOrPrintData(selectedBenefactor, selectedOption) {

    console.log(selectedBenefactor, selectedOption)
    // Check if benefactor is selected
    if (selectedBenefactor !== "Benefactor" && selectedBenefactor !== null) {
        // Make an AJAX request to fetch data for the selected benefactor
        $.post('../php/printApproveSelected.php', {
            benefactor: selectedBenefactor,
            selectedOption: selectedOption
        }, function (data) {
            // Trigger a download of the generated CSV file
            var link = document.createElement('a');
            link.href = 'data:text/csv;charset=utf-8,' + encodeURI(data);
            link.target = '_blank';
            link.download = 'approve_data.csv';
            link.click();
            dismissBenefactorModal();
            const succes_toast = document.getElementById('success-toast');
            bootstrap.Toast.getOrCreateInstance(succes_toast).show();

        });

    } else {
        const failed_toast = document.getElementById('failed-toast');
        bootstrap.Toast.getOrCreateInstance(failed_toast).show();
    }
}

var approvemodal = document.getElementById('approveBenefactorModal');
var approveModalInstance = new bootstrap.Modal(approvemodal);
function dismissBenefactorModal() {

    approveModalInstance.hide();
}
/*Download Selected in Approve Scholars Per benefactor*/



/*Download Selected College Scholars*/
// Function to get  Scholar per College
const collegeSelect = document.getElementById('collegeSelect');
function getScholarsCollege(selectedOption) {
    // Make an AJAX request to fetch scholars per campus from PHP
    fetch('../php/getScholarCollegeReport.php?selectedOption=' + selectedOption)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            // Remove existing options
            collegeSelect.innerHTML = '<option selected disabled hidden>College</option>';

            // Loop through the data and append new options
            data.forEach(item => {
                const collegeScholarsName = item.name.toUpperCase(); // Access 'name' property
                const option = document.createElement('option');
                option.value = collegeScholarsName;
                option.textContent = collegeScholarsName;
                collegeSelect.appendChild(option);
            });

            Highcharts.chart('scholars-per-college', {
                chart: {
                    type: 'pie'
                },
                title: {
                    align: 'center',
                    text: 'SCHOLARS PER COLLEGE' // Update chart title
                },

                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total approve per benefactor'
                    }
                },
                legend: {
                    enabled: true, // Enable legend for pie chart
                    layout: 'horizontal',
                    align: 'center', // Align center to position at the bottom
                    verticalAlign: 'bottom'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>:{point.y} ({point.percentage:.0f}%)'

                        },
                        showInLegend: true
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },

                // Add or update the series data with the fetched data
                series: [{
                    name: 'Total Scholars Per College',
                    colorByPoint: true,
                    data: data // Use the actual property from your data
                }]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
}
// Function to get  Scholar per College
const perCollegePrintButton = document.getElementById('perCollegePrint');
perCollegePrintButton.addEventListener('click', function () {
    const selectedCollege = collegeSelect.value;
    // Trigger download or printing based on the selected benefactor
    downloadCollege(selectedCollege, selectedOption);
});

function downloadCollege(selectedCollege, selectedOption) {

    console.log("downloading ", selectedCollege, selectedOption);
    // Check if benefactor is selected
    if (selectedCollege !== "College" && selectedCollege !== null) {
        // Make an AJAX request to fetch data for the selected benefactor
        $.post('../php/printCollegeSelected.php', {
            college: selectedCollege,
            selectedOption: selectedOption
        }, function (data) {
            // Trigger a download of the generated CSV file
            var link = document.createElement('a');
            link.href = 'data:text/csv;charset=utf-8,' + encodeURI(data);
            link.target = '_blank';
            link.download = 'scholarPerCollege_data.csv';
            link.click();
            dismissPerCollegeModal();
            const succes_toast = document.getElementById('success-toast');
            bootstrap.Toast.getOrCreateInstance(succes_toast).show();

        });

    } else {
        const failed_toast = document.getElementById('failed-toast');
        bootstrap.Toast.getOrCreateInstance(failed_toast).show();
    }


}
var perCollegeModal = document.getElementById('perCollegeModal');
var perCollegeModalModalInstance = new bootstrap.Modal(perCollegeModal);
function dismissPerCollegeModal() {

    perCollegeModalModalInstance.hide();
}
/*Download Selected College Scholars*/

//Get Employment of Graduate
function getGraduate() {

    //Get Employment Status
    fetch('../php/getEmployment.php') // Update the URL to the correct endpoint
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            Highcharts.chart('graduate-status', {
                chart: {
                    type: 'pie'
                },
                title: {
                    align: 'center',
                    text: 'GRADUATE EMPLOYMENT STATUS' // Update chart title
                },

                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total numbers per Employment'
                    }
                },
                legend: {
                    enabled: true, // Enable legend for pie chart
                    layout: 'horizontal',
                    align: 'center', // Align center to position at the bottom
                    verticalAlign: 'bottom'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.y} ({point.percentage:.0f}%)'
                        },
                        showInLegend: true // Display in legend
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },
                // ... (rest of the Highcharts configuration remains the same)

                // Add or update the series data with the fetched data
                series: [{
                    name: 'Total Number Per Employment',
                    colorByPoint: true,
                    data: data // Use the actual property from your data
                }]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
}
//Print Functions
$(document).ready(function () {
    $('#graduateprint').click(function () {
        var employmentStatus = $('#employmentStatusSelect').val();

        // Check if employmentStatus is the default value "Employment Status"
        if (employmentStatus === "Employment Status" || employmentStatus === null) {
            // Display failed modal
            const failed_toast = document.getElementById('failed-toast');
            bootstrap.Toast.getOrCreateInstance(failed_toast).show();
        } else {
            // If employmentStatus is not the default value, proceed with the AJAX request
            console.log(employmentStatus); // Log the selected value
            $.post('../php/printGraduate.php', { employmentStatus: employmentStatus }, function (data) {
                // Trigger a download of the generated CSV file
                var link = document.createElement('a');
                link.href = 'data:text/csv;charset=utf-8,' + encodeURI(data);
                link.target = '_blank';
                link.download = 'graduate_data.csv';
                link.click();
                dismissModal();
                document.getElementById('graduateSelect').reset();
                // Display success modal
                const succes_toast = document.getElementById('success-toast');
                bootstrap.Toast.getOrCreateInstance(succes_toast).show();
            });
        }
    });
});



var graduate_modal = document.getElementById('graduateModal');
var graduateModalInstance = new bootstrap.Modal(graduate_modal);
function dismissModal() {

    graduateModalInstance.hide();
}
//Graduates
//Get Employment of Graduate


/*Download Selected in Total Scholars Per benefactor*/
const scholarsSelect = document.getElementById('ScholarsSelect');
// Function to get All Scholar per benefactor
function getTotalBenefactor(selectedOption) {
    // Make an AJAX request to fetch scholars per campus from PHP
    fetch('../php/getTotalScholarsReport.php?selectedOption=' + selectedOption)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            // Remove existing options
            scholarsSelect.innerHTML = '<option selected disabled hidden>Benefactor</option>';

            // Loop through the data and append new options
            data.forEach(item => {
                const benefactorScholarsName = item.name.toUpperCase(); // Access 'name' property
                const option = document.createElement('option');
                option.value = benefactorScholarsName;
                option.textContent = benefactorScholarsName;
                scholarsSelect.appendChild(option);
            });

            Highcharts.chart('total-scholars', {
                chart: {
                    type: 'column'
                },
                title: {
                    align: 'center',
                    text: 'TOTAL SCHOLARS PER BENEFACTOR'
                },
                subtitle: {
                    align: 'center',
                    text: ''
                },
                accessibility: {
                    announceNewData: {
                        enabled: true
                    }
                },
                xAxis: {
                    type: 'category'
                },
                yAxis: {
                    title: {
                        text: 'Total numbers of scholars'
                    }

                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    series: {
                        borderWidth: 0,
                        dataLabels: {
                            enabled: true,
                            format: '{point.y}'
                        }
                    }
                },

                tooltip: {
                    headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                    pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
                },

                series: [
                    {
                        name: 'Benefactor',
                        colorByPoint: true,
                        data: data
                    }
                ]
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
}
// Function to get All Scholar per benefactor

const perScholarPrintButton = document.getElementById('perScholarsPrint');
perScholarPrintButton.addEventListener('click', function () {
    const selectedScholarsBenefactor = scholarsSelect.value;
    // Trigger download or printing based on the selected benefactor
    downloadScholars(selectedScholarsBenefactor, selectedOption);
});


function downloadScholars(selectedScholarsBenefactor, selectedOption) {

    console.log("downloading: ", selectedScholarsBenefactor, selectedOption)

    // Check if benefactor is selected
    if (selectedScholarsBenefactor !== "Benefactor" && selectedScholarsBenefactor !== null) {
        // Make an AJAX request to fetch data for the selected benefactor
        $.post('../php/printScholarsSelected.php', {
            scholarsBenefactor: selectedScholarsBenefactor,
            selectedOption: selectedOption
        }, function (data) {
            // Trigger a download of the generated CSV file
            var link = document.createElement('a');
            link.href = 'data:text/csv;charset=utf-8,' + encodeURI(data);
            link.target = '_blank';
            link.download = 'scholarPerBenefactor_data.csv';
            link.click();
            dismissPerBenefactorModal();
            const succes_toast = document.getElementById('success-toast');
            bootstrap.Toast.getOrCreateInstance(succes_toast).show();
        });

    } else {
        const failed_toast = document.getElementById('failed-toast');
        bootstrap.Toast.getOrCreateInstance(failed_toast).show();
    }

}

var ScholarsPerBenefactorModal = document.getElementById('ScholarsPerBenefactorModal');
var ScholarsPerBenefactorModalInstance = new bootstrap.Modal(ScholarsPerBenefactorModal);
function dismissPerBenefactorModal() {

    ScholarsPerBenefactorModalInstance.hide();
}
/*Download Selected in Total Scholars Per benefactor*/





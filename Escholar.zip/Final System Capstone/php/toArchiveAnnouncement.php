<?php
include_once 'config.php';

// Establish a database connection
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $admin = $_POST['user'];


    // Prepare and execute the SELECT query
    $stmtSelect = $conn->prepare("SELECT * FROM announcement WHERE id = ?");
    $stmtSelect->bind_param('i', $id);
    $stmtSelect->execute();

    // Get result set
    $result = $stmtSelect->get_result();
    $announcementData = $result->fetch_assoc();

    // Prepare and execute the INSERT query
    $insertQuery = "INSERT INTO archived_announcement (title, description, url, file_name, file_type, supporting_name, supporting_type, date_created)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmtInsert = $conn->prepare($insertQuery);

    // Explicitly bind parameters
    $stmtInsert->bind_param(
        'ssssssss',
        $announcementData['title'],
        $announcementData['description'],
        $announcementData['url'],
        $announcementData['file_name'],
        $announcementData['file_type'],
        $announcementData['supporting_name'],
        $announcementData['supporting_type'],
        $announcementData['date_created']
    );

    $stmtInsert->execute();

    // Prepare and execute the DELETE query
    $deleteQuery = "DELETE FROM announcement WHERE id = ?";
    $stmtDelete = $conn->prepare($deleteQuery);
    $stmtDelete->bind_param('i', $id);
    $stmtDelete->execute();

    //Activity Logs
    $user = $admin;
    $activity = 'Announcement Management';
    $finalTableName = $announcementData['title'];
    $description = 'Archive ' . $finalTableName . ' in announcement.';
    date_default_timezone_set('Asia/Manila');
    $date = date('Y-m-d H:i:s');

    $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
    $query->bind_param("ssss", $user, $activity, $description, $date);

    $result = $query->execute();
    //Activity Logs

    // Close connections
    $stmtSelect->close();
    $stmtInsert->close();
    $stmtDelete->close();

    // Close MySQLi connection
    CloseCon($conn);

    // Return a response to the client (success or error)
    echo json_encode(['success' => true]);
} else {
    // Handle invalid request method
    echo json_encode(['error' => 'Invalid request method']);
    CloseCon($conn); // Close connection in case of an error
}
?>
<?php
include_once 'config.php';

// Establish a database connection
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $admin = $_POST['user'];

    // Prepare and execute the SELECT query
    $stmtSelect = $conn->prepare("SELECT * FROM benefactor WHERE id = ?");
    $stmtSelect->bind_param('i', $id);
    $stmtSelect->execute();

    // Get result set
    $result = $stmtSelect->get_result();
    $benefactorData = $result->fetch_assoc();

    // Prepare and execute the INSERT query
    $insertQuery = "INSERT INTO archived_benefactor (particular, semester, name, slot, amount, from_sy, to_sy, table_name)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmtInsert = $conn->prepare($insertQuery);

    // Explicitly bind parameters
    $stmtInsert->bind_param('sssiisss', $benefactorData['particular'], $benefactorData['semester'], $benefactorData['name'], $benefactorData['slot'], $benefactorData['amount'], $benefactorData['from_sy'], $benefactorData['to_sy'], $benefactorData['table_name']);

    $stmtInsert->execute();

    // Prepare and execute the DELETE query
    $deleteQuery = "DELETE FROM benefactor WHERE id = ?";
    $stmtDelete = $conn->prepare($deleteQuery);
    $stmtDelete->bind_param('i', $id);
    $stmtDelete->execute();

    //Activity Logs
    $user = $admin;
    $activity = 'Benefactor Management';
    $finalTableName = $benefactorData['name'];
    $description = 'Archive ' . $finalTableName . ' in benefactor.';
    date_default_timezone_set('Asia/Manila');
    $date = date('Y-m-d H:i:s');

    $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
    $query->bind_param("ssss", $user, $activity, $description, $date);

    $result = $query->execute();
    //Activity Logs

    // Close connections
    $stmtSelect->close();
    $stmtInsert->close();
    $stmtDelete->close();

    // Close MySQLi connection
    CloseCon($conn);

    // Return a response to the client (success or error)
    echo json_encode(['success' => true]);
} else {
    // Handle invalid request method
    echo json_encode(['error' => 'Invalid request method']);
    CloseCon($conn); // Close connection in case of an error
}
?>
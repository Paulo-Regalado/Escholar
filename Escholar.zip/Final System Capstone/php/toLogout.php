<?php
session_start();

// Unset all session variables
session_unset();
$_SESSION = array();

// Destroy the session
session_destroy();

// Regenerate session ID for enhanced security
session_regenerate_id(true);

// Redirect to the login page or any other page after logout
header("Location: http://escholar.eyjeyesdiar.com/"); // Change 'login.php' to the actual login page
exit();
?>
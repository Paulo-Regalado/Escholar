<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

if (isset($_POST['emails'])) {
    $email = $_POST['emails'];


    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'ofsasscholarshiptracker@gmail.com';
    $mail->Password = 'cnzzoctusxpxlgpa';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('ofsasscholarshiptracker@gmail.com');

    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = 'New Announcement';
    $mail->Body = '<h4>Hello Scholars! </h4><br><h4>A new announcement has been posted! We kindly request that you visit your Scholar Portal for detailed information.
    To access your Scholar Portal, please click on the provided link: http://escholar.eyjeyesdiar.com/
    <br>We highly recommend that you continue to visit your Scholar Portal regularly to stay up-to-date with the latest scholarship updates.
    <br><br>Please be guided. Thank you!</h4>';

    if ($mail->send()) {
        echo '<script>alert("Sent Successful");</script>';
    } else {
        echo '<script>alert("Sending failed: ' . $mail->ErrorInfo . '");</script>';
    }
}
?>
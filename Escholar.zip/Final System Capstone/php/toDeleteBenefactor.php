<?php

include 'config.php';
$conn = OpenCon();

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Retrieve the values sent via POST
    $id = $_POST['id'];
    $user = $_POST['user'];
    $delete_table = $_POST['delete_table'];

    // Validate input (You should perform more validation as needed)

    // Prepare the DELETE query for the archived_benefactor table
    $delete_query = "DELETE FROM archived_benefactor WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $id);

    // Execute the statement for deleting from archived_benefactor table
    if (!$stmt->execute()) {
        // If there was an error in the delete operation for archived_benefactor table
        $response = array('success' => false, 'error' => $conn->error);
    } else {
        // The delete operation for archived_benefactor table was successful

        // Now, prepare the DROP TABLE query for the specified table
        $drop_query = "DROP TABLE IF EXISTS $delete_table";

        // Execute the DROP TABLE query
        if ($conn->query($drop_query)) {
            // The drop operation for the specified table was successful
            $response = array('success' => true);
        } else {
            // There was an error in the drop operation for the specified table
            $response = array('success' => false, 'error' => $conn->error);
        }
    }

    // Close the prepared statement and database connection
    $stmt->close();
    $conn->close();

    // Send the JSON response back to the AJAX call
    echo json_encode($response);
} else {
    // If the request method is not POST, return an error
    echo json_encode(array('success' => false, 'error' => 'Invalid request method'));
}

?>

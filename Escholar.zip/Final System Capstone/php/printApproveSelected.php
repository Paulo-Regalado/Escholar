<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['benefactor']) && isset($_POST['selectedOption'])) {

    $benefactor = $_POST['benefactor'];
    $selectedOption = $_POST['selectedOption'];
    list($from_sy, $to_sy, $sem) = explode('-', $selectedOption);

    // Query the benefactor table
    $query = "SELECT name, table_name FROM benefactor WHERE from_sy = '$from_sy' AND to_sy = '$to_sy' AND name ='$benefactor' AND semester = '$sem' GROUP BY name";

    $result = $conn->query($query);

    if (!$result) {
        die('Query failed' . mysqli_error($conn));
    }

    $benefactors = [];
    while ($row = $result->fetch_assoc()) {
        // Assign the table_name from the current row
        $table_name = $row['table_name'];
        $name = $row['name'];

        // Build a new query to count the approved status in the specified table
        $countQuery = "SELECT student_number FROM $table_name WHERE  status IN ('approved', 'processed', 'claim')";

        // Execute the count query
        $countResult = $conn->query($countQuery);

        // Check if the count query was successful
        if ($countResult) {
            while ($countRow = $countResult->fetch_assoc()) {
                $student_number = $countRow['student_number'];

                // Query the masterlist table to get first name and last name
                $masterlistQuery = "SELECT student_number, first_name, last_name, middle_name, email, contact, campus,
                college, course, year_level FROM masterlist WHERE student_number = '$student_number'";
                $masterlistResult = $conn->query($masterlistQuery);

                if (!$masterlistResult) {
                    die('Masterlist query failed' . mysqli_error($conn));
                }

                // Fetch the first name and last name from the masterlist table
                while ($masterlistRow = $masterlistResult->fetch_assoc()) {
                    $name = $row['name'];
                    $studentNumber = $masterlistRow['student_number'];
                    $firstname = $masterlistRow['first_name'];
                    $lastname = $masterlistRow['last_name'];
                    $middlename = $masterlistRow['middle_name'];
                    $email = $masterlistRow['email'];
                    $contact = $masterlistRow['contact'];
                    $campus = $masterlistRow['campus'];
                    $college = $masterlistRow['college'];
                    $course = $masterlistRow['course'];
                    $yearlevel = $masterlistRow['year_level'];

                    // Add data to the benefactors array
                    $benefactors[] = array(
                        'name' => $name,
                        'student_number' => $studentNumber,
                        'first_name' => $firstname,
                        'last_name' => $lastname,
                        'middle_name' => $middlename,
                        'email' => $email,
                        'contact' => $contact,
                        'campus' => $campus,
                        'college' => $college,
                        'course' => $course,
                        'year_level' => $yearlevel,
                    );
                }
            }
        } else {
            die('Count query failed' . mysqli_error($conn));
        }
    }

    // If no benefactors found in benefactor table, query archived_benefactor table
    if (empty($benefactors)) {

        // Query the archived_benefactor table
        $archivedQuery = "SELECT name, table_name FROM archived_benefactor WHERE from_sy = '$from_sy' AND to_sy = '$to_sy' AND name ='$benefactor' AND semester = '$sem' GROUP BY name";

        $archivedResult = $conn->query($archivedQuery);

        if (!$archivedResult) {
            die('Archived query failed' . mysqli_error($conn));
        }

        $benefactors = [];
        while ($archivedRow = $archivedResult->fetch_assoc()) {
            // Assign the table_name from the current row
            $archivedTableName = $archivedRow['table_name'];
            $archivedName = $archivedRow['name'];

            // Build a new query to count the approved status in the specified table
            $archivedCountQuery = "SELECT student_number FROM $archivedTableName WHERE  status IN ('approved', 'processed', 'claim')";

            // Execute the count query
            $archivedCountResult = $conn->query($archivedCountQuery);

            // Check if the count query was successful
            if ($archivedCountResult) {
                while ($archivedCountRow = $archivedCountResult->fetch_assoc()) {
                    $archivedStudentNumber = $archivedCountRow['student_number'];

                    // Query the masterlist table to get first name and last name
                    $archivedMasterlistQuery = "SELECT student_number, first_name, last_name, middle_name, email, contact, campus,
                    college, course, year_level FROM masterlist WHERE student_number = '$archivedStudentNumber'";
                    $archivedMasterlistResult = $conn->query($archivedMasterlistQuery);

                    if (!$archivedMasterlistResult) {
                        die('Archived Masterlist query failed' . mysqli_error($conn));
                    }

                    // Fetch the first name and last name from the masterlist table
                    while ($archivedMasterlistRow = $archivedMasterlistResult->fetch_assoc()) {
                        $archivedName = $archivedRow['name'];
                        $archivedstudentNumber = $archivedMasterlistRow['student_number'];
                        $archivedfirstname = $archivedMasterlistRow['first_name'];
                        $archivedlastname = $archivedMasterlistRow['last_name'];
                        $archivedmiddlename = $archivedMasterlistRow['middle_name'];
                        $archivedemail = $archivedMasterlistRow['email'];
                        $archivedcontact = $archivedMasterlistRow['contact'];
                        $archivedcampus = $archivedMasterlistRow['campus'];
                        $archivedcollege = $archivedMasterlistRow['college'];
                        $archivedcourse = $archivedMasterlistRow['course'];
                        $archivedyearlevel = $archivedMasterlistRow['year_level'];

                        // Add data to the benefactors array
                        $benefactors[] = array(
                            'name' => $archivedName,
                            'student_number' => $archivedstudentNumber,
                            'first_name' => $archivedfirstname,
                            'last_name' => $archivedlastname,
                            'middle_name' => $archivedmiddlename,
                            'email' => $archivedemail,
                            'contact' => $archivedcontact,
                            'campus' => $archivedcampus,
                            'college' => $archivedcollege,
                            'course' => $archivedcourse,
                            'year_level' => $archivedyearlevel,
                        );
                    }
                }
            } else {
                die('Archived Count query failed' . mysqli_error($conn));
            }
        }

    }

    // Define the filename for the CSV file
    $filename = 'benefactors_data.csv';

    // Create and open the CSV file for writing
    $file = fopen($filename, 'w');

    // Add CSV header row
    $header = ['Benefactor', 'Student Number', 'First Name', 'Last Name', 'Middle Name', 'Email', 'Contact', 'Campus', 'College', 'Course', 'Year Level']; // Add more columns as needed
    fputcsv($file, $header);

    // Add data rows to the CSV file
    foreach ($benefactors as $benefactor) {
        fputcsv($file, $benefactor);
    }

    // Close the CSV file
    fclose($file);

    // Send the CSV file to the client for download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=' . $filename);
    readfile($filename);

    // Clean up and exit
    unlink($filename); // Delete the temporary CSV file
    mysqli_close($conn);
    exit();
} else {
    echo 'Invalid request.';
}

$conn->close();
?>
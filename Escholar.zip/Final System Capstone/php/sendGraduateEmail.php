<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

if (isset($_POST['emails'])) {
    $email = $_POST['emails'];


    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'ofsasscholarshiptracker@gmail.com';
    $mail->Password = 'cnzzoctusxpxlgpa';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('ofsasscholarshiptracker@gmail.com');

    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = 'Graduate Tracer';
    $mail->Body = "<h4>Hello, Graduate Scholar!

    <br><br>Kamusta ka? We hope this message finds you well. Your journey and experiences matter to us, and we're eager to learn more about your post-graduate life.
    
    We kindly request your participation in our Graduate Tracer Survey. Your valuable insights will help us understand your progress and achievements, and how we can further support you in your endeavors.
    
    Please take a few moments to complete the survey by clicking the graduate tracer form found in the portal.
    
    Your feedback is instrumental in shaping the future of our program, and your success story can inspire current and future scholars. We appreciate your time and contribution to our community.
    
    <br><br>Please be guided. Thank you!</h4>";

    if ($mail->send()) {
        echo '<script>alert("Sent Successful");</script>';
    } else {
        echo '<script>alert("Sending failed: ' . $mail->ErrorInfo . '");</script>';
    }
}
?>
<?php
include 'config.php';
$conn = OpenCon();

session_start(); // Start the PHP session

$existingRecordCount = 0; // Initialize the count of existing records
$skippedRecordCount = 0; // Initialize the count of skipped records
$AddedRecordCount = 0;
$recordsData = array(); // Array to store records data
$responseData = array(); // Initialize the response data array

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filename = $_FILES["excel-file"]["tmp_name"];
    $table_name = $_POST["table-name"];
    $name = $_POST['user'];

    // Check if the file exists and is readable
    if (is_uploaded_file($filename) && is_readable($filename)) {
        $file = fopen($filename, "r");

        if ($file !== false) {
            $firstRow = true; // Flag to skip the first row (header)

            // Validate fields before processing any records
            $validFields = true;

            while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE) {
                if ($firstRow) {
                    $firstRow = false; // Skip the first row
                    continue;
                }

                // Check if the row has exactly 10 columns
                if (count($emapData) !== 12) {
                    // $skippedRecordCount++;

                    // Log the message to the error_log
                    error_log("Skipped due to not equal number of columns: " . implode(',', $emapData));

                    $responseData['error'] = 'Incorrect Column Format';

                    continue;
                }

                $studno = mysqli_real_escape_string($conn, $emapData[0]);
                $lastname = mysqli_real_escape_string($conn, $emapData[1]);
                $firstname = mysqli_real_escape_string($conn, $emapData[2]);
                $middlename = mysqli_real_escape_string($conn, $emapData[3]);
                $email = mysqli_real_escape_string($conn, $emapData[4]);
                $contact = mysqli_real_escape_string($conn, $emapData[5]);
                $campus = mysqli_real_escape_string($conn, $emapData[6]);
                $college = mysqli_real_escape_string($conn, $emapData[7]);
                $course = mysqli_real_escape_string($conn, $emapData[8]);
                $yearlevel = mysqli_real_escape_string($conn, $emapData[9]);
                $gwa = mysqli_real_escape_string($conn, $emapData[10]);
                $units = mysqli_real_escape_string($conn, $emapData[11]);

                // Validate student number (numbers only, 10 digits, not null)
                if (!preg_match("/^[0-9]{10}$/", $studno) || $studno == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid student number: ' . $studno;
                    break;
                }

                // Validate lastname (letters and spaces only, not null)
                if (!preg_match("/^[a-zA-Z\s]+$/", $lastname) || $lastname == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid last name: ' . $lastname;
                    break;
                }

                // Validate firstname (letters and spaces only, not null)
                if (!preg_match("/^[a-zA-Z\s]+$/", $firstname) || $firstname == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid first name: ' . $firstname;
                    break;
                }

                // Validate middlename (letters and period only, can be null)
                if ($middlename !== '' && !preg_match("/^[a-zA-Z.]+$/", $middlename)) {
                    $validFields = false;
                    $responseData['error'] = 'Invalid middle name: ' . $middlename;
                    break;
                }

                // Validate email (email format, not null)
                if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $email == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid email: ' . $email;
                    break;
                }

                // Validate contact (numbers only, not null)
                if (!is_numeric($contact) || $contact == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid contact: ' . $contact;
                    break;
                }

                // Validate campus (letters and spaces only, not null)
                if (!preg_match("/^[a-zA-Z\s]+$/", $campus) || $campus == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid campus: ' . $campus;
                    break;
                }

                // Validate college (letters only, not null)
                if (!preg_match("/^[a-zA-Z]+$/", $college) || $college == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid college: ' . $college;
                    break;
                }

                // Validate course (letters only, not null)
                if (!preg_match("/^[a-zA-Z]+$/", $course) || $course == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid course: ' . $course;
                    break;
                }

                // Validate yearLevel (alphanumeric, not null)
                if (!preg_match("/^[a-zA-Z0-9]+$/", $yearlevel) || $yearlevel == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid year level: ' . $yearlevel;
                    break;
                }


                // Validate gwa (numbers and float,not null)
                if (!preg_match("/^[0-9]+(\.[0-9]+)?$/", $gwa) || $gwa == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid GWA: ' . $gwa;
                    break;
                }

                // Validate units numbers only not null
                if (!preg_match("/^[0-9]+$/", $units) || $units == '') {
                    $validFields = false;
                    $responseData['error'] = 'Invalid units: ' . $units;
                    break;
                }


                $recordsData[] = array(
                    "studno" => $studno,
                    "lastname" => $lastname,
                    "firstname" => $firstname,
                    "middlename" => $middlename,
                    "email" => $email,
                    "contact" => $contact,
                    "campus" => $campus,
                    "college" => $college,
                    "course" => $course,
                    "yearlevel" => $yearlevel,
                    "units" => $units,
                    "gwa" => $gwa,
                ); // Store record data in the array
            }

            fclose($file);

            // Check if field validations failed
            if (!$validFields) {
                $responseData['error'] = 'Incorrect Data Format';
            } else {
                // If all validations pass, proceed with insertion
                foreach ($recordsData as $record) {
                    // Check if there's an existing record in masterlist for the student_number
                    $connMasterlist = OpenCon();
                    $checkMasterlistQuery = $conn->prepare("SELECT COUNT(*) FROM masterlist WHERE student_number = ?");
                    $checkMasterlistQuery->bind_param('i', $record['studno']);
                    $checkMasterlistQuery->execute();
                    $checkMasterlistQuery->bind_result($existingMasterlistCount);
                    $checkMasterlistQuery->fetch();
                    $checkMasterlistQuery->close();

                    // Check if there's an existing record in benefactor for the student_number
                    $checkBenefactorQuery = $conn->prepare("SELECT COUNT(*) FROM $table_name WHERE student_number = ?");
                    $checkBenefactorQuery->bind_param('i', $record['studno']);
                    $checkBenefactorQuery->execute();
                    $checkBenefactorQuery->bind_result($existingBenefactorCount);
                    $checkBenefactorQuery->fetch();
                    $checkBenefactorQuery->close();

                    if ($existingMasterlistCount > 0) {
                        if ($existingBenefactorCount == 0) {
                            // Data exists in masterlist but not in benefactor, insert into benefactor
                            $status = 'approved'; // Assuming this is the default value you want to pass

                            $queryBenefactor = $conn->prepare("INSERT INTO $table_name (student_number, status) VALUES (?, ?)");
                            $queryBenefactor->bind_param('is', $record['studno'], $status);
                            $benefactorSuccess = $queryBenefactor->execute();

                            $AddedRecordCount++;



                            // MONITORING FORM
                            // Assuming $table_name is 'monitoring_form' for this case
                            $fileField = null; // Set the file field to NULL

                            // Check if there's no existing record for the student_number
                            $checkExistingQuery = $conn->prepare("SELECT COUNT(*) FROM monitoring_form WHERE student_number = ?");
                            $checkExistingQuery->bind_param('i', $record['studno']);
                            $checkExistingQuery->execute();
                            $checkExistingQuery->bind_result($existingRecordCount);
                            $checkExistingQuery->fetch();
                            $checkExistingQuery->close();

                            // Only insert a new record if there's no existing record
                            if ($existingRecordCount == 0) {
                                $queryMonitoringForm = $conn->prepare("INSERT INTO monitoring_form (student_number, gwa, units, cor_file_name, cog_file_name, id_file_name) VALUES (?, ?, ?, ?, ?, ?)");
                                $queryMonitoringForm->bind_param('idisss', $record['studno'], $record['gwa'], $record['units'], $fileField, $fileField, $fileField);

                                // Execute the query and handle errors
                                $monitoringFormSuccess = $queryMonitoringForm->execute();

                                // Add this after $benefactorSuccess condition
                                if (!$monitoringFormSuccess) {
                                    echo "<script type=\"text/javascript\">
                                    alert(\"Error: Unable to insert record into monitoring_form.\");
                                    </script>";
                                    exit; // Exit the loop if there's an error
                                }
                            }
                            // No else condition needed; the record won't be inserted if it already exists

                            // MONITORING FORM

                        } else {
                            $skippedRecordCount++;
                        }
                    } else {

                        $record['contact'] = "0" . strval($record['contact']);
                        $record['lastname'] = ucfirst(strtolower($record['lastname']));
                        $record['firstname'] = ucfirst(strtolower($record['firstname']));
                        $record['middlename'] = ucfirst(strtolower($record['middlename']));

                        //doesnt exist in both tables
                        $queryMasterlist = $conn->prepare("INSERT INTO masterlist(student_number, last_name, first_name, middle_name, email, contact, campus, college, course, year_level, gwa, units) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $queryMasterlist->bind_param('isssssssssdi', $record['studno'], $record['lastname'], $record['firstname'], $record['middlename'], $record['email'], $record['contact'], $record['campus'], $record['college'], $record['course'], $record['yearlevel'], $record['gwa'], $record['units']);
                        // Execute queries and handle errors
                        $masterlistSuccess = $queryMasterlist->execute();

                        // Data exists in masterlist but not in benefactor, insert into benefactor
                        $status = 'approved'; // Assuming this is the default value you want to pass

                        $queryBenefactor = $conn->prepare("INSERT INTO $table_name (student_number, status) VALUES (?, ?)");
                        $queryBenefactor->bind_param('is', $record['studno'], $status);
                        $benefactorSuccess = $queryBenefactor->execute();

                        $AddedRecordCount++;

                        // MONITORING FORM
                        // Assuming $table_name is 'monitoring_form' for this case
                        $fileField = null; // Set the file field to NULL

                        // Check if there's no existing record for the student_number
                        $checkExistingQuery = $conn->prepare("SELECT COUNT(*) FROM monitoring_form WHERE student_number = ?");
                        $checkExistingQuery->bind_param('i', $record['studno']);
                        $checkExistingQuery->execute();
                        $checkExistingQuery->bind_result($existingRecordCount);
                        $checkExistingQuery->fetch();
                        $checkExistingQuery->close();

                        // Only insert a new record if there's no existing record
                        if ($existingRecordCount == 0) {
                            $queryMonitoringForm = $conn->prepare("INSERT INTO monitoring_form (student_number, gwa, units, cor_file_name, cog_file_name, id_file_name) VALUES (?, ?, ?, ?, ?, ?)");
                            $queryMonitoringForm->bind_param('idisss', $record['studno'], $record['gwa'], $record['units'], $fileField, $fileField, $fileField);

                            // Execute the query and handle errors
                            $monitoringFormSuccess = $queryMonitoringForm->execute();

                            // Add this after $benefactorSuccess condition
                            if (!$monitoringFormSuccess) {
                                echo "<script type=\"text/javascript\">
                                alert(\"Error: Unable to insert record into monitoring_form.\");
                                </script>";
                                exit; // Exit the loop if there's an error
                            }
                        }
                        // No else condition needed; the record won't be inserted if it already exists

                        // MONITORING FORM

                        if (!$masterlistSuccess || !$benefactorSuccess) {
                            echo "<script type=\"text/javascript\">
                                    alert(\"Invalid File: Please Upload an Excel File.\");
                                </script>";
                            exit; // Exit the loop if there's an error
                        } else {
                            // Increment the count of existing records
                            $existingRecordCount++;
                        }
                    }






                }
            }
        } else {
            // Failed to open the file
            echo "Error: Unable to open the file.";
        }
    } else {
        // File doesn't exist or is not readable
        echo "Error: The uploaded file is not valid or cannot be read.";
    }

    //Activity Logs
    $user = $name;
    $activity = 'Scholar Management';
    $lastUnderscorePosition = strrpos($table_name, '_'); // Find the last underscore position
// Extract the part before the last underscore and replace underscores with spaces
    $finalTableName = str_replace('_', ' ', substr($table_name, 0, $lastUnderscorePosition));
    $description = 'Imported ' . $AddedRecordCount . ' scholars in ' . $finalTableName . ' benefactor.';
    date_default_timezone_set('Asia/Manila');
    $date = date('Y-m-d H:i:s');

    $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
    $query->bind_param("ssss", $user, $activity, $description, $date);

    $result = $query->execute();
    //Activity Logs



}

// Close the database connection
CloseCon($conn);

// Add skipped record count and records data to the response data array
$responseData['skippedRecordCount'] = $skippedRecordCount;
$responseData['recordsData'] = $recordsData;
$responseData['AddedRecordCount'] = $AddedRecordCount;
$responseData['success'] = true; // Add a success flag
// Encode the array as JSON and echo it
header('Content-Type: application/json');
echo json_encode($responseData);

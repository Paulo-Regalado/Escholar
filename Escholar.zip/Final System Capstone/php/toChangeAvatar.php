<?php
session_start();
include_once 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the form is for updating the password

    $studentNumber = $_POST['student_number'];
    $profilePic = $_FILES['avatar'];
    $uploadDirectory = "../Profile_Pictures/";

    // Check if the file was uploaded without errors
    if ($profilePic['error'] === UPLOAD_ERR_OK) {
        $fileExtension = pathinfo($profilePic['name'], PATHINFO_EXTENSION);
        $newFileName = $studentNumber . "_profile_pic.jpg"; // Use student_number as the file name

        $destination = $uploadDirectory . $newFileName;

        // Move the uploaded file to the destination folder
        if (move_uploaded_file($profilePic['tmp_name'], $destination)) {
            // File moved successfully, now update the file name in the database
            $query = $conn->prepare("UPDATE user_account SET profile_pic_file = ? WHERE student_number = ?");
            $query->bind_param('si', $newFileName, $studentNumber);

            if ($query->execute()) {
                // Update successful, show alert and redirect
                echo '<script>';
                echo 'alert("Profile picture updated successfully!");';
                echo 'window.location.href = "http://escholar.eyjeyesdiar.com/";';
                echo '</script>';
            } else {
                echo "Error: " . mysqli_error($conn);
                echo 'Error updating profile picture';
            }
        } else {
            echo "Error: File upload failed";
        }
    } else {
        echo "Error: " . $profilePic['error'];
    }
}
// Rest of your code
?>
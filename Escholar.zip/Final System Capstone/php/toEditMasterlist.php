<?php
include 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input data
    $table_name = $_POST['table-name'];
    $studentNumber = $_POST['student_number'];
    $lastName = $_POST['last_name'];
    $firstName = $_POST['first_name'];
    $middleName = $_POST['middle_name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $campus = $_POST['campus'];
    $college = $_POST['college'];
    $course = $_POST['course'];
    $yearLevel = $_POST['year_level'];
    $status = $_POST['status'];
    $admin = $_POST['user'];

    // Validate required fields
    if (empty($studentNumber) || empty($lastName) || empty($firstName) || empty($email) || empty($contact) || empty($campus) || empty($college) || empty($course) || empty($yearLevel)) {
        echo json_encode([
            'success' => false,
            'message' => '<div class="alert alert-danger alert-dismissible fade show w=100" role="alert">
            <strong>Error:</strong> All fields are required.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>'
        ]);
        exit; // Stop further execution
    }

    // Sanitize input data
    $studentNumber = htmlspecialchars($studentNumber);
    $lastName = ucfirst(strtolower(htmlspecialchars($lastName)));
    $firstName = ucfirst(strtolower(htmlspecialchars($firstName)));
    $middleName = ucfirst(strtolower(htmlspecialchars($middleName)));
    $email = htmlspecialchars($email);
    $contact = htmlspecialchars($contact);
    $campus = htmlspecialchars($campus);
    $college = htmlspecialchars($college);
    $course = htmlspecialchars($course);
    $yearLevel = htmlspecialchars($yearLevel);
    $admin = htmlspecialchars($admin);

    // Prepare and execute the update query
    $updateQuery = $conn->prepare("UPDATE masterlist SET last_name=?, first_name=?, middle_name=?, email=?, contact=?, campus=?, college=?, course=?, year_level=? WHERE student_number=?");
    $updateQuery->bind_param('sssssssssi', $lastName, $firstName, $middleName, $email, $contact, $campus, $college, $course, $yearLevel, $studentNumber);

    // Execute the update query with error handling
    try {
        if ($updateQuery->execute()) {
            // Update successful

            $updateStatus = $conn->prepare("UPDATE " . $table_name . " SET status=? WHERE student_number=?");
            $updateStatus->bind_param('si', $status, $studentNumber);
            if ($updateStatus->execute()) {
                // Display success message
                echo json_encode([
                    'success' => true,
                    'message' => "<div class='alert alert-success alert-dismissible fade show w=100' role='alert'>
                    <strong>" . $studentNumber . "</strong> has been changed.
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                </div>"
                ]);
            }


            // Log activity
            logActivity($conn, $admin, 'Scholar Management', 'Edited ' . $studentNumber . ' from Masterlist.');
        } else {
            // Update failed

            // Display error message
            echo json_encode([
                'success' => false,
                'message' => '<div class="alert alert-danger alert-dismissible fade show w=100" role="alert">
                <strong>Error:</strong> Update failed.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>'
            ]);
        }
    } catch (Exception $e) {
        // Handle exceptions
        echo json_encode([
            'success' => false,
            'message' => '<div class="alert alert-danger alert-dismissible fade show w=100" role="alert">
            <strong>Error:</strong> ' . $e->getMessage() . '
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>'
        ]);
    }
}

// Function to log activity
function logActivity($conn, $user, $activity, $description)
{
    date_default_timezone_set('Asia/Manila');
    $date = date('Y-m-d H:i:s');

    // Prepare and execute the insert query with error handling
    try {
        $insertQuery = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
        $insertQuery->bind_param("ssss", $user, $activity, $description, $date);

        // Execute the insert query
        $insertQuery->execute();
    } catch (Exception $e) {
        // Handle exceptions
        echo json_encode([
            'success' => false,
            'message' => '<div class="alert alert-danger alert-dismissible fade show w=100" role="alert">
            <strong>Error:</strong> ' . $e->getMessage() . '
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>'
        ]);
    }
}

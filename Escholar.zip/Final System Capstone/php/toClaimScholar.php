<?php

include 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $table_name = $_POST['table-name'];
    $approve_studNo = $_POST['approve-studNo'];
    $status = "claim";
    $name = $_POST['user'];


    $query = $conn->prepare("UPDATE " . $table_name . " SET status=? WHERE student_number=?");
    $query->bind_param('si', $status, $approve_studNo);

    if ($query->execute()) {

        echo '<div class="alert alert-success alert-dismissible fade show w=100" role="alert">
                <strong>' . $studentNumber . '</strong> has been changed.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        //Activity Logs
        $user = $name;
        $activity = 'Progress Tracking';
        $description = 'Move ' . $approve_studNo . ' to Scholarship Grant Claim.';
        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d H:i:s');

        $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
        $query->bind_param("ssss", $user, $activity, $description, $date);

        $result = $query->execute();
        //Activity Logs
    } else {
        echo "Error: " . mysqli_error($conn);
        echo 'Error Account';
    }

}
?>
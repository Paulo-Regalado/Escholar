<?php
include_once 'config.php';
$conn = OpenCon();

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['table-name'])) {

    $table_name = $_POST['table-name'];

    // SQL query to count statuses
    $sql = "SELECT 
    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_count,
    SUM(CASE WHEN status = 'processed' THEN 1 ELSE 0 END) as processed_count,
    SUM(CASE WHEN status = 'claim' THEN 1 ELSE 0 END) as claim_count
    FROM $table_name";

    $result = $conn->query($sql);

    $response = array();

    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            $response['approved_count'] = $row["approved_count"];
            $response['processed_count'] = $row["processed_count"];
            $response['claim_count'] = $row["claim_count"];
        }
    } else {
        $response['error'] = "No results";
    }

}



// Close the connection
$conn->close();

// Convert the response array to JSON and print it
echo json_encode($response);

?>
<?php
include_once './config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "SELECT am.id, am.benefactor_name, am.status, am.table_name, m.*
            FROM masterlist m 
            INNER JOIN archived_masterlist am ON m.student_number = am.student_number";

    if ($result = $conn->query($sql)) {
        $data = array();

        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        $result->close();

        echo json_encode($data);
    } else {
        echo "Error in query: " . $conn->error;
    }
}

$conn->close();
?>

<?php
session_start();
include_once 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentNumber = $_POST['student_number'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);


    // Handle file upload
    $profilePic = $_FILES['profile-pic']; // Get the uploaded file data
    $uploadDirectory = "../Profile_Pictures/"; // The directory where you want to save the uploaded files

    // Check if the file was uploaded without errors
    if ($profilePic['error'] === UPLOAD_ERR_OK) {
        $fileExtension = pathinfo($profilePic['name'], PATHINFO_EXTENSION);
        $newFileName = $studentNumber . "_profile_pic.jpg"; // Use student_number as the file name

        $destination = $uploadDirectory . $newFileName;

        // Move the uploaded file to the destination folder
        if (move_uploaded_file($profilePic['tmp_name'], $destination)) {
            // File moved successfully, now insert the file name into the database
            $query = $conn->prepare("INSERT INTO user_account (student_number, password, profile_pic_file) VALUES (?, ?, ?)");
            $query->bind_param('iss', $studentNumber, $password, $newFileName);

            if ($query->execute()) {
                // Activation successful, show alert and redirect
                echo '<script>';
                echo 'alert("Activation successful!");';
                echo 'window.location.href = "http://escholar.eyjeyesdiar.com/";';
                echo '</script>';
            } else {
                echo "Error: " . mysqli_error($conn);
                echo 'Error Account';
            }
        } else {
            echo "Error: File upload failed";
        }
    } else {
        echo "Error: " . $profilePic['error'];
    }
}

// Rest of your code
?>
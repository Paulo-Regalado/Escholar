<?php
include 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query unique values from 'benefactor' and 'archive_benefactor' tables using UNION
$query = "(SELECT from_sy, to_sy, semester FROM benefactor)
          UNION
          (SELECT from_sy, to_sy, semester FROM archived_benefactor)
          ORDER BY from_sy DESC, semester DESC";
;
$result = mysqli_query($conn, $query);

$data = array();

// Fetch and combine unique values from both tables
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// Close the database connection
$conn->close();

header('Content-Type: application/json');
echo json_encode($data);
?>
<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get the count of scholars per campus
$sql = "SELECT campus, COUNT(*) as count FROM masterlist GROUP BY campus";
$result = $conn->query($sql);

// Fetch the result into an associative array
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        'name' => $row['campus'],
        'y' => (int) $row['count']
    ];
}

// Set the content type to JSON
header('Content-Type: application/json');

// Return JSON response with an array of objects
echo json_encode($data);

// Close database connection
$conn->close();
?>
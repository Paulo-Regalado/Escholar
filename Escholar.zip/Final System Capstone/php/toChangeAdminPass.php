<?php
session_start();
include_once 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the form is for updating the password

    $accountNumber = $_POST['account_number'];
    $newPassword = password_hash($_POST['new-pass'], PASSWORD_DEFAULT);

    // Check if the admin exists in the database
    $checkAdmin = $conn->prepare("SELECT account_id FROM admin_account WHERE account_number = ?");
    $checkAdmin->bind_param('s', $accountNumber);
    $checkAdmin->execute();
    $checkAdmin->store_result();

    if ($checkAdmin->num_rows > 0) {
        // Update the password for the admin
        $updatePassword = $conn->prepare("UPDATE admin_account SET password_hash = ? WHERE account_number = ?");
        $updatePassword->bind_param('ss', $newPassword, $accountNumber);

        if ($updatePassword->execute()) {
            // Password update successful, show alert and redirect
            echo '<script>';
            echo 'alert("Password update successful!");';
            echo 'window.location.href = "../Admin/dashboard.php";';  // Update the path if needed
            echo '</script>';
        } else {
            echo "Error: " . mysqli_error($conn);
            echo 'Error updating password';
        }
    } else {
        echo "Error: Admin not found in the database";
    }
} else {
    echo "Error: Invalid request";
}

// Rest of your code
?>

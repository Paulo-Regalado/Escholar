<?php
include 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['student-number']) && isset($_POST['table-name'])) {
    $student_number = $_POST['student-number'];
    $table_name = $_POST['table-name'];

    $query = "SELECT masterlist.* FROM masterlist
        INNER JOIN $table_name
        ON masterlist.student_number = $table_name.student_number
        WHERE masterlist.student_number = $student_number";

    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
    } else {
        echo json_encode(array()); // No results found
    }
}

// Close the database connection
$conn->close();
?>

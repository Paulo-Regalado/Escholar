<?php
session_start();
include_once 'config.php';
$conn = OpenCon();

// Perform a query to retrieve email addresses where year_level is 'graduate' or '4'
$query = "SELECT email FROM masterlist WHERE year_level = 'graduate' OR year_level = '4'";
$result = mysqli_query($conn, $query);

if (!$result) {
    // Handle the query error
    $response = array(
        'success' => false,
        'error' => 'Error in the database query',
    );
} else {
    $emails = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $emails[] = $row['email'];
    }

    // Return the email addresses as a JSON response
    $response = array(
        'success' => true,
        'emails' => $emails,
    );
}

// Set the Content-Type header to indicate JSON response
header('Content-Type: application/json');

// Output the response as JSON
echo json_encode($response);

// Close the database connection
$conn->close();
?>
<?php
include_once 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['user'];

    // Main File Handling
    if (!empty($_FILES['file']['name'])) {
        $fileName = $_FILES['file']['name'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileError = $_FILES['file']['error'];

        if ($fileError === UPLOAD_ERR_OK) {
            // Move the uploaded file to the Gallery folder
            $uploadDirectory = '../Gallery_Files/';
            $filePath = $uploadDirectory . $fileName;

            move_uploaded_file($fileTmpName, $filePath);
        } else {
            // Handle file upload error
            echo json_encode(array("success" => false, "error" => "Error uploading file: " . $fileError));
            exit();
        }
    } else {
        $fileName = null;
    }

    // Get the highest stack_order value
    $queryMaxStackOrder = $conn->query("SELECT MAX(stack_order) AS max_order FROM gallery");
    $maxStackOrder = $queryMaxStackOrder->fetch_assoc()['max_order'];

    // Set the stack_order value to one more than the highest value
    $stackOrder = $maxStackOrder + 1;

    // Insert data into the 'gallery' table
    $queryGallery = $conn->prepare("INSERT INTO gallery (stack_order, file_name) VALUES (?, ?)");
    $queryGallery->bind_param('is', $stackOrder, $fileName);

    // Execute the query and handle errors
    $gallerySuccess = $queryGallery->execute();

    if ($gallerySuccess) {
        // Activity Logs
        $activity = 'Gallery Management';
        $description = 'Added an image to the gallery';
        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d H:i:s');

        $queryLogs = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
        $queryLogs->bind_param("ssss", $user, $activity, $description, $date);

        if ($queryLogs->execute() === FALSE) {
            // Handle the insert query error
            echo json_encode(array("success" => false, "error" => "Error inserting data into activity_logs table: " . $conn->error));
            exit();
        }
        // Activity Logs

        echo json_encode(array("success" => true, "message" => "File added to gallery successfully"));
    } else {
        echo json_encode(array("success" => false, "error" => "Error adding file to gallery: " . $conn->error));
    }

    // Close the prepared statements
    $queryGallery->close();
    $queryLogs->close();
}

// Close the database connection
CloseCon($conn);

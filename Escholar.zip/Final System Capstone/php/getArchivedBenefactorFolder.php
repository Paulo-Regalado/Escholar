<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT DISTINCT `name` FROM `archived_benefactor`";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $names = array();

    while ($row = $result->fetch_assoc()) {
        $names[] = $row['name'];
    }

    echo json_encode($names);
} else {
    // Return an empty array if no data is found
    echo json_encode([]);
}

$conn->close();
?>

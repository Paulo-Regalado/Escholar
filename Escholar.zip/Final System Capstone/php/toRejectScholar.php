<?php

include 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $table_name = $_POST['table-name'];
    $approve_studNo = $_POST['rejected-studNo'];
    $status = "rejected";


    $query = $conn->prepare("UPDATE " . $table_name . " SET status=? WHERE student_number=?");
    $query->bind_param('si', $status, $approve_studNo);

    if ($query->execute()) {

        echo '<div class="alert alert-success alert-dismissible fade show w=100" role="alert">
                <strong>' . $studentNumber . '</strong> has been changed.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
    } else {
        echo "Error: " . mysqli_error($conn);
        echo 'Error Account';
    }

}
?>
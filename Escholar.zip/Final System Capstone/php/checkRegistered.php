<?php
include 'config.php';

$conn = OpenCon();

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['student_number'])) {
    $student_number = mysqli_real_escape_string($conn, $_POST['student_number']); // Sanitize input

    // Query to check if the student number exists in the user_account table
    $user_account_query = "SELECT * FROM user_account WHERE student_number = ?";
    $stmt_user = mysqli_prepare($conn, $user_account_query);

    if (!$stmt_user) {
        echo "Database Error: " . mysqli_error($conn);
        exit;
    }

    mysqli_stmt_bind_param($stmt_user, "s", $student_number);
    mysqli_stmt_execute($stmt_user);
    $user_result = mysqli_stmt_get_result($stmt_user);

    if (!$user_result) {
        echo "Database Error: " . mysqli_error($conn);
        exit;
    }

    if (mysqli_num_rows($user_result) > 0) {
        echo "registered";
    } else {
        echo "not registered";
    }
} else {
    echo "Error: Student number not provided";
}

// Close the database connection
mysqli_close($conn);
?>
<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get the count of graduates per year
$sql = "SELECT year_graduated, COUNT(*) as count FROM graduate_information GROUP BY year_graduated";
$result = $conn->query($sql);

// Fetch the result into an associative array
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        'name' => $row['year_graduated'],
        'y' => (int) $row['count']
    ];
}

// Set the content type to JSON
header('Content-Type: application/json');

// Return JSON response with an array of objects
echo json_encode($data);

// Close database connection
$conn->close();
?>
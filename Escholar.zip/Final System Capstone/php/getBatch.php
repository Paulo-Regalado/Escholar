<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query your database and fetch only the 'batchname' column from the graduate_information table
$sql = "SELECT DISTINCT year_graduated  FROM graduate_information";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row['year_graduated']; // Use 'batchname' instead of 'batch'
    }
    echo json_encode($data);
} else {
    echo json_encode(array()); // No results found in graduate_information table
}

$conn->close();
?>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

if (isset($_POST['email']) && isset($_POST['fname']) && isset($_POST['lname'])) {
    $email = $_POST['email'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];

    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'ofsasscholarshiptracker@gmail.com';
    $mail->Password = 'cnzzoctusxpxlgpa';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('ofsasscholarshiptracker@gmail.com');

    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = 'Scholarship Progress Tracker';
    $mail->Body = '<h3>Hi! ' . $fname . ' ' . $lname . '</h3><br><h4>We are pleased to inform you that your scholarship grant is ready for disbursement. Kindly wait for further details and announcements regarding the distribution schedule and location.
    <br>To ensure you receive the latest updates regarding your scholarship, we encourage you to continue accessing your scholar portal by clicking on the following link:<br> http://escholar.eyjeyesdiar.com/

    <br><br>Please be guided. Thank you!</h4>';

    if ($mail->send()) {
        echo '<script>alert("Sent Successful");</script>';
    } else {
        echo '<script>alert("Sending failed: ' . $mail->ErrorInfo . '");</script>';
    }
}
?>
<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$selectedOption = $_GET['selectedOption'];

list($from_sy, $to_sy, $sem) = explode('-', $selectedOption);
// Query the benefactor table
$query = "SELECT name, table_name FROM benefactor WHERE from_sy = '$from_sy' AND to_sy = '$to_sy' AND semester = '$sem' GROUP BY name";

$result = $conn->query($query);

if (!$result) {
    die('Query failed' . mysqli_error($conn));
}

$benefactors = [];
while ($row = $result->fetch_assoc()) {
    // Assign the table_name from the current row
    $table_name = $row['table_name'];

    // Build a new query to count the approved status in the specified table
    $countQuery = "SELECT COUNT(*) AS approved_count FROM $table_name WHERE  status IN ('approved', 'processed', 'claim')";

    // Execute the count query
    $countResult = $conn->query($countQuery);

    if (!$countResult) {
        die('Count query failed' . mysqli_error($conn));
    }

    // Fetch the count result
    $countRow = $countResult->fetch_assoc();

    // Add the count result to the benefactors array
    $benefactors[] = [
        'name' => $row['name'],
        'y' => (int) $countRow['approved_count'] // Display the approved count in the chart
    ];
}

// If no benefactors found in benefactor table, query archived_benefactor table
if (empty($benefactors)) {
    $queryArchived = "SELECT name, table_name FROM archived_benefactor WHERE from_sy = '$from_sy' AND to_sy = '$to_sy' AND semester = '$sem' GROUP BY name";

    $resultArchived = $conn->query($queryArchived);

    if (!$resultArchived) {
        die('Query failed' . mysqli_error($conn));
    }

    $benefactors = []; // Reset $benefactors array

    while ($rowArchived = $resultArchived->fetch_assoc()) {
        $table_name = $rowArchived['table_name'];

        // Build a new query to count the approved status in the specified table
        $countQueryArchived = "SELECT COUNT(*) AS approved_count FROM $table_name WHERE status IN ('approved', 'processed', 'claim')";

        // Execute the count query
        $countResultArchived = $conn->query($countQueryArchived);

        if (!$countResultArchived) {
            die('Count query failed' . mysqli_error($conn));
        }

        // Fetch the count result
        $countRowArchived = $countResultArchived->fetch_assoc();

        // Add the count result to the benefactors array
        $benefactors[] = [
            'name' => $rowArchived['name'],
            'y' => (int) $countRowArchived['approved_count']
        ];
    }
}


// Set the content type to JSON
header('Content-Type: application/json');

// Return JSON response with an array of objects
echo json_encode($benefactors);

// Close database connection
$conn->close();
?>
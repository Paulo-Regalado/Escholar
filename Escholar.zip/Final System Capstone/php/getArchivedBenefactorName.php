<?php
include_once './config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['name'])) {
    $name = $_POST['name'];

    // Query your database and fetch data from benefactor table for the specific name
    $sql = "SELECT * FROM archived_benefactor WHERE name=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $name); // "s" indicates a string, adjust as needed
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
    } else {
        echo json_encode(array()); // No results found for the provided name
    }
} else {
    echo json_encode(array('error' => 'No name provided'));
}

$conn->close();
?>

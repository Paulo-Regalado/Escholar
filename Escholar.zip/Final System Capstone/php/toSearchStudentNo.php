<?php
include 'config.php';
$conn = OpenCon();


if (isset($_POST['student-number']) && isset($_POST['table-name'])) {
    $student_number = $_POST['student-number'];
    $table_name = $_POST['table-name'];

    try {
        
        $query = "SELECT * FROM ".$table_name." WHERE student_number=" .$student_number ;
        $result = $conn -> query($query);
        
        if($result -> num_rows > 0) {
            echo "existing";
          }
        else {
            echo "not existing";
          }


    } catch (PDOException $e) {
        $response = "Database Error: " . $e->getMessage();
        echo $response;
    }
} else {
    $response = "error";
    echo $response;
}

    // Close the database connection
    $conn->close();

?>

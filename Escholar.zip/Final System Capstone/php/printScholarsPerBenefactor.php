<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['benefactor'])) {
    $benefactor = $_POST['benefactor'];

    // Step 1: Get the table name based on the benefactor variable
    $sql1 = "SELECT table_name FROM benefactor WHERE name = '$benefactor'";
    $result1 = mysqli_query($conn, $sql1);

    if ($row1 = mysqli_fetch_assoc($result1)) {
        $table_name = $row1['table_name'];


        // Step 2: Select student numbers from the retrieved table_name and join with masterlist
        $sql2 = "SELECT m.student_number, m.first_name, m.last_name, m.middle_name, m.email, m.contact, m.campus, m.college, m.course, m.year_level
        FROM masterlist AS m
        WHERE m.student_number IN (SELECT student_number FROM $table_name)";


        $result2 = mysqli_query($conn, $sql2);

        // Define the filename for the CSV file
        $filename = 'scholars_per_benefactor_data.csv';

        // Create and open the CSV file for writing
        $file = fopen($filename, 'w');

        // Add dynamic CSV header
        $header = [
            'Student Number',
            'First Name',
            'Last Name',
            'Middle Name',
            'Email',
            'Contact',
            'Campus',
            'College',
            'Course',
            'Year Level',
            'Benefactor'
            // Add the table name to the header
        ];

        fputcsv($file, $header);

        // Add data rows to the CSV file, including the table_name for each row
        while ($row2 = mysqli_fetch_assoc($result2)) {
            $row2['Benefactor'] = $benefactor;
            fputcsv($file, $row2);
        }

        // Close the CSV file
        fclose($file);

        // Send the CSV file to the client for download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename=' . $filename);
        readfile($filename);

        // Clean up and exit
        unlink($filename); // Delete the temporary CSV file
        mysqli_close($conn);
        exit();
    } else {
        echo 'Benefactor not found.';
    }
} else {
    echo 'Invalid request.';
}

$conn->close();
?>
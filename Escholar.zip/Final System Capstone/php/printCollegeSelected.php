<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['college']) && isset($_POST['selectedOption'])) {

    $college = $_POST['college'];
    $selectedOption = $_POST['selectedOption'];
    list($from_sy, $to_sy, $sem) = explode('-', $selectedOption);

    // Query the benefactor table
    $query = "SELECT name, table_name FROM benefactor WHERE from_sy = '$from_sy' AND to_sy = '$to_sy' AND semester = '$sem'";

    $result = $conn->query($query);

    if (!$result) {
        die('Query failed' . mysqli_error($conn));
    }

    $benefactors = [];
    while ($row = $result->fetch_assoc()) {
        // Assign the table_name from the current row
        $table_name = $row['table_name'];

        // Build a new query to get the student numbers from the specified table
        $studentQuery = "SELECT DISTINCT student_number FROM $table_name";

        // Execute the student query
        $studentResult = $conn->query($studentQuery);

        if (!$studentResult) {
            die('Student query failed' . mysqli_error($conn));
        }

        // Fetch the student numbers
        while ($studentRow = $studentResult->fetch_assoc()) {
            $studentNumber = $studentRow['student_number'];

            // Build a query to join with the masterlist table and get student information
            $masterlistQuery = "SELECT student_number, first_name, last_name, middle_name, email, contact, campus,
            college, course, year_level FROM masterlist WHERE student_number = '$studentNumber' AND college = '$college'";

            // Execute the masterlist query
            $masterlistResult = $conn->query($masterlistQuery);

            if (!$masterlistResult) {
                die('Masterlist query failed' . mysqli_error($conn));
            }

            // Fetch the masterlist result
            while ($masterlistRow = $masterlistResult->fetch_assoc()) {
                $studentNumber = $masterlistRow['student_number'];
                $firstname = $masterlistRow['first_name'];
                $lastname = $masterlistRow['last_name'];
                $middlename = $masterlistRow['middle_name'];
                $email = $masterlistRow['email'];
                $contact = $masterlistRow['contact'];
                $campus = $masterlistRow['campus'];
                $college = $masterlistRow['college'];
                $course = $masterlistRow['course'];
                $yearlevel = $masterlistRow['year_level'];

                // Add data to the benefactors array
                $benefactors[] = [
                    'student_number' => $studentNumber,
                    'first_name' => $firstname,
                    'last_name' => $lastname,
                    'middle_name' => $middlename,
                    'email' => $email,
                    'contact' => $contact,
                    'campus' => $campus,
                    'college' => $college,
                    'course' => $course,
                    'year_level' => $yearlevel,
                ];
            }
        }
    }

    if (empty($benefactors)) {

        // Query the benefactor table
        $query = "SELECT name, table_name FROM archived_benefactor WHERE from_sy = '$from_sy' AND to_sy = '$to_sy' AND semester = '$sem'";

        $result = $conn->query($query);

        if (!$result) {
            die('Query failed' . mysqli_error($conn));
        }

        $benefactors = [];
        while ($row = $result->fetch_assoc()) {
            // Assign the table_name from the current row
            $table_name = $row['table_name'];

            // Build a new query to get the student numbers from the specified table
            $studentQuery = "SELECT DISTINCT student_number FROM $table_name";

            // Execute the student query
            $studentResult = $conn->query($studentQuery);

            if (!$studentResult) {
                die('Student query failed' . mysqli_error($conn));
            }

            // Fetch the student numbers
            while ($studentRow = $studentResult->fetch_assoc()) {
                $studentNumber = $studentRow['student_number'];

                // Build a query to join with the masterlist table and get student information
                $masterlistQuery = "SELECT student_number, first_name, last_name, middle_name, email, contact, campus,
                college, course, year_level FROM masterlist WHERE student_number = '$studentNumber' AND college = '$college'";

                // Execute the masterlist query
                $masterlistResult = $conn->query($masterlistQuery);

                if (!$masterlistResult) {
                    die('Masterlist query failed' . mysqli_error($conn));
                }

                // Fetch the masterlist result
                while ($masterlistRow = $masterlistResult->fetch_assoc()) {
                    $studentNumber = $masterlistRow['student_number'];
                    $firstname = $masterlistRow['first_name'];
                    $lastname = $masterlistRow['last_name'];
                    $middlename = $masterlistRow['middle_name'];
                    $email = $masterlistRow['email'];
                    $contact = $masterlistRow['contact'];
                    $campus = $masterlistRow['campus'];
                    $college = $masterlistRow['college'];
                    $course = $masterlistRow['course'];
                    $yearlevel = $masterlistRow['year_level'];

                    // Add data to the benefactors array
                    $benefactors[] = [
                        'student_number' => $studentNumber,
                        'first_name' => $firstname,
                        'last_name' => $lastname,
                        'middle_name' => $middlename,
                        'email' => $email,
                        'contact' => $contact,
                        'campus' => $campus,
                        'college' => $college,
                        'course' => $course,
                        'year_level' => $yearlevel,
                    ];
                }
            }
        }




    }

    // Define the filename for the CSV file
    $filename = 'benefactors_data.csv';

    // Create and open the CSV file for writing
    $file = fopen($filename, 'w');

    // Add CSV header row
    $header = ['Student Number', 'First Name', 'Last Name', 'Middle Name', 'Email', 'Contact', 'Campus', 'College', 'Course', 'Year Level']; // Add more columns as needed
    fputcsv($file, $header);

    // Add data rows to the CSV file
    foreach ($benefactors as $benefactor) {
        fputcsv($file, $benefactor);
    }

    // Close the CSV file
    fclose($file);

    // Send the CSV file to the client for download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=' . $filename);
    readfile($filename);

    // Clean up and exit
    unlink($filename); // Delete the temporary CSV file
    mysqli_close($conn);
    exit();
} else {
    echo 'Invalid request.';
}

// Close database connection
$conn->close();
?>
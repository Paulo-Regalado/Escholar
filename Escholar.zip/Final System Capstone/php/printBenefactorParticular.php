<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_POST['benefactorStatus'])) {
    $benefactorStatus = $_POST['benefactorStatus'];

    // Initialize the SQL query
    $sql = "";

    // Check if the selected status is "all"
    if ($benefactorStatus === 'all') {
        // If "all" is selected, retrieve all records
        $sql = "SELECT name, particular, slot, amount, semester, from_sy, to_sy 
        FROM benefactor ORDER BY particular";

    } else {
        // Otherwise, select based on the chosen employment status
        $sql = "SELECT name, particular, slot, amount, semester, from_sy, to_sy  FROM benefactor WHERE particular = '$benefactorStatus'";
    }
    $result = mysqli_query($conn, $sql);

    // Define the filename for the CSV file
    $filename = 'benefactor_particulars_data.csv';

    // Create and open the CSV file for writing
    $file = fopen($filename, 'w');

    // Add CSV header row
    $header = [
        'Name',
        'Particular',
        'Slot',
        'Amount',
        'Semester',
        'From Sy',
        'To Sy'

    ]; // Replace with your table column names
    fputcsv($file, $header);

    // Add data rows to the CSV file
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($file, $row);
    }

    // Close the CSV file
    fclose($file);

    // Send the CSV file to the client for download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=' . $filename);
    readfile($filename);

    // Clean up and exit
    unlink($filename); // Delete the temporary CSV file
    mysqli_close($conn);
    exit();
} else {
    echo 'Invalid request.';
}

$conn->close();
?>
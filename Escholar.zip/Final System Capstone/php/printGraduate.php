<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_POST['employmentStatus'])) {
    $employmentStatus = $_POST['employmentStatus'];

    // Initialize the SQL query
    $sql = "";

    // Check if the selected status is "all"
    if ($employmentStatus === 'all') {
        // If "all" is selected, retrieve all records
        $sql = "SELECT student_number, complete_name, birthday, gender, civil_status, current_address, contact, email, course, year_graduated,
         benefactor, campus, employment, org_type, company_name, company_address, position, year_in_company 
        FROM graduate_information ORDER BY employment";

    } else {
        // Otherwise, select based on the chosen employment status
        $sql = "SELECT student_number, complete_name, birthday, gender, civil_status, current_address, contact, email, course, year_graduated,
        benefactor, campus, employment, org_type, company_name, company_address, position, year_in_company FROM graduate_information WHERE employment = '$employmentStatus'";
    }
    $result = mysqli_query($conn, $sql);

    // Define the filename for the CSV file
    $filename = 'graduate_data.csv';

    // Create and open the CSV file for writing
    $file = fopen($filename, 'w');

    // Add CSV header row
    $header = [
        'Student Number',
        'Complete Name',
        'Birthday',
        'Gender',
        'Civil Status',
        'Current Address',
        'Contact',
        'Email',
        'Course',
        'Year Graduated',
        'Benefactor',
        'Campus',
        'Employment Status',
        'Company Name',
        'Company Address',
        'Position',
        'Year in Company'
    ]; // Replace with your table column names
    fputcsv($file, $header);

    // Add data rows to the CSV file
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($file, $row);
    }

    // Close the CSV file
    fclose($file);

    // Send the CSV file to the client for download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=' . $filename);
    readfile($filename);

    // Clean up and exit
    unlink($filename); // Delete the temporary CSV file
    mysqli_close($conn);
    exit();
} else {
    echo 'Invalid request.';
}

$conn->close();
?>
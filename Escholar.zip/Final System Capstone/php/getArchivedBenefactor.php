<?php
include_once './config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query your database and fetch data from benefactor table
$sql = "SELECT * FROM archived_benefactor";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    echo json_encode(array()); // No results found in benefactor table
}

$conn->close();
?>
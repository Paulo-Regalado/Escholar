<?php
include_once './config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $table_name = $_POST["table_name"];
    $student_number = $_POST["student_number"];
    $status = $_POST["status"];
    $admin = $_POST['user'];

    // Remove record from archived_masterlist
    $deleteSql = "DELETE FROM archived_masterlist WHERE id = ?";
    $deleteStmt = $conn->prepare($deleteSql);
    $deleteStmt->bind_param("i", $id);
    $deleteStmt->execute();
    $deleteStmt->close();

    // Restore record to the appropriate masterlist table
    $restoreSql = "INSERT INTO $table_name (student_number, status) VALUES (?, ?)";
    $restoreStmt = $conn->prepare($restoreSql);
    $restoreStmt->bind_param("is", $student_number, $status);
    $restoreStmt->execute();

    //Activity Logs
    $user = $admin;
    $activity = 'Scholar Management';
    $lastUnderscorePosition = strrpos($table_name, '_'); // Find the last underscore position
    // Extract the part before the last underscore and replace underscores with spaces
    $finalTableName = str_replace('_', ' ', substr($table_name, 0, $lastUnderscorePosition));
    $description = 'Restore ' . $student_number . ' from ' . $finalTableName . ' masterlist.';
    date_default_timezone_set('Asia/Manila');
    $date = date('Y-m-d H:i:s');

    $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
    $query->bind_param("ssss", $user, $activity, $description, $date);

    $result = $query->execute();
    //Activity Logs

    $restoreStmt->close();

    // Send success response
    echo json_encode(["success" => true]);
} else {
    // Send error response for invalid request method
    echo json_encode(["success" => false, "error" => "Invalid request method"]);
}

$conn->close();
?>
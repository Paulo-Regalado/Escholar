<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_POST['campusStatus'])) {
    $campusStatus = $_POST['campusStatus'];

    // Initialize the SQL query
    $sql = "";

    // Check if the selected status is "all"
    if ($campusStatus === 'all') {
        // If "all" is selected, retrieve all records
        $sql = "SELECT student_number, last_name, first_name, middle_name, email, contact, campus, college, course, year_level FROM masterlist ORDER BY campus";

    } else {
        // Otherwise, select based on the chosen employment status
        $sql = "SELECT student_number, last_name, first_name, middle_name, email, contact, campus, college, course, year_level FROM masterlist WHERE campus = '$campusStatus'";
    }
    $result = mysqli_query($conn, $sql);

    // Define the filename for the CSV file
    $filename = 'scholars_per_campus_data.csv';

    // Create and open the CSV file for writing
    $file = fopen($filename, 'w');

    // Add CSV header row
    $header = ['Student Number', 'Last Name', 'First Name', 'Middle Name', 'Email', 'Contact', 'Campus', 'College', 'Course', 'Year Level']; // Replace with your table column names
    fputcsv($file, $header);

    // Add data rows to the CSV file
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($file, $row);
    }

    // Close the CSV file
    fclose($file);

    // Send the CSV file to the client for download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=' . $filename);
    readfile($filename);

    // Clean up and exit
    unlink($filename); // Delete the temporary CSV file
    mysqli_close($conn);
    exit();
} else {
    echo 'Invalid request.';
}

$conn->close();
?>
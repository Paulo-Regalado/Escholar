<?php

include_once 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $particular = $_POST['benefactor-particular'];
    $semester = $_POST['benefactor-semester'];
    $name = $_POST['benefactor-name'];
    $slot = $_POST['benefactor-slot'];
    $amount = $_POST['benefactor-amount'];
    $from_sy = $_POST['from_sy'];
    $to_sy = $_POST['to_sy'];
    $admin = $_POST['user'];

    // Generate a unique ID for the benefactor table
    $table_id = uniqid();

    // Modify table name based on benefactor-name and append the unique ID
    $table_name = str_replace(' ', '_', $name) . '_' . $table_id;

    // Create the SQL table with the new structure
    $create_table_sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
        `student_number` int(10) NOT NULL,
        `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL,
        PRIMARY KEY (`student_number`)
    )";

    if ($conn->query($create_table_sql) === TRUE) {
        $query = $conn->prepare("INSERT INTO benefactor(particular, semester, name, slot, amount, from_sy, to_sy, table_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $query->bind_param('sssiiiis', $particular, $semester, $name, $slot, $amount, $from_sy, $to_sy, $table_name);

        if ($query->execute()) {
            echo '<div class="alert alert-success alert-dismissible fade show w=100" role="alert">
                    Successfully added <strong>' . $name . '</strong>.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                 </div>';

            //Activity Logs
            $user = $admin;
            $activity = 'Benefactor Management';
            $lastUnderscorePosition = strrpos($table_name, '_'); // Find the last underscore position
            // Extract the part before the last underscore and replace underscores with spaces
            $finalTableName = str_replace('_', ' ', substr($table_name, 0, $lastUnderscorePosition));
            $description = 'Added ' . $finalTableName . ' in benefactor.';
            date_default_timezone_set('Asia/Manila');
            $date = date('Y-m-d H:i:s');

            $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
            $query->bind_param("ssss", $user, $activity, $description, $date);

            $result = $query->execute();
            //Activity Logs
        } else {
            echo "Error: " . mysqli_error($conn);
            echo 'Error Account';
        }
    } else {
        echo "Error creating table: " . $conn->error;
    }

    // header("Location: adminAdd.php");
}

?>
<?php
include 'config.php';
$conn = OpenCon();

// Set the Content-Type header to indicate JSON response
// header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $particular = $_POST['particular'];
    $semester = $_POST['semester'];
    $name = $_POST['name'];
    $slot = $_POST['slot'];
    $amount = $_POST['amount'];
    $from_sy = $_POST['from_sy'];
    $to_sy = $_POST['to_sy'];
    $admin = $_POST['user'];


    $query = $conn->prepare("UPDATE benefactor SET particular=?, semester=?, name=?, slot=?, amount=?, from_sy=?, to_sy=? WHERE id=?");
    $query->bind_param('sssiiiii', $particular, $semester, $name, $slot, $amount, $from_sy, $to_sy, $id);


    if ($query->execute()) {

        echo 'Edit Succesful';

        //Activity Logs
        $user = $admin;
        $activity = 'Benfactor Management';
        $description = 'Edited ' . $name . ' from Benefactor.';
        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d H:i:s');

        $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
        $query->bind_param("ssss", $user, $activity, $description, $date);

        $result = $query->execute();
        //Activity Logs

    } else {
        echo "Error: " . mysqli_error($conn);
        echo 'Error Account';
    }

}
?>
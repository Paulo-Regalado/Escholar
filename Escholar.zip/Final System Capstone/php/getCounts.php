<?php
include_once 'config.php';
$conn = OpenCon();

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to count distinct benefactor, graduate, and masterlist records
$benefactorQuery = "SELECT COUNT(DISTINCT id) as benefactor_count FROM benefactor";
$graduateQuery = "SELECT COUNT(DISTINCT student_number) as graduate_count FROM graduate_information";
$masterlistQuery = "SELECT table_name FROM benefactor";
$adminQuery = "SELECT COUNT(DISTINCT account_number) as admin_count FROM admin_account";

$response = array();

$benefactorResult = $conn->query($benefactorQuery);
if ($benefactorResult === false) {
    $response['error'] = "Benefactor query failed: " . $conn->error;
} elseif ($benefactorResult->num_rows > 0) {
    $row = $benefactorResult->fetch_assoc();
    $response['benefactor_count'] = $row["benefactor_count"];
} else {
    $response['error'] = "No benefactor results";
}

$graduateResult = $conn->query($graduateQuery);
if ($graduateResult === false) {
    $response['error'] = "Graduate query failed: " . $conn->error;
} elseif ($graduateResult->num_rows > 0) {
    $row = $graduateResult->fetch_assoc();
    $response['graduate_count'] = $row["graduate_count"];
} else {
    $response['error'] = "No graduate results";
}

$masterlistResult = $conn->query($masterlistQuery);
if ($masterlistResult === false) {
    $response['error'] = "Benefactor query failed: " . $conn->error;
} else {
    $totalCount = 0;

    while ($masterlistRow = $masterlistResult->fetch_assoc()) {
        $tableName = $masterlistRow["table_name"];

        // Step 2: Count the number of distinct student numbers in each dynamically obtained table
        $countQuery = "SELECT COUNT(DISTINCT student_number) as count FROM $tableName";
        $countResult = $conn->query($countQuery);

        if ($countResult === false) {
            $response['error'] = "Count query failed: " . $conn->error;
            break;
        } elseif ($countResult->num_rows > 0) {
            $countRow = $countResult->fetch_assoc();
            $totalCount += $countRow["count"];
        }
    }

    // Step 3: Set the total count in the response
    $response['masterlist_count'] = $totalCount;
}

$adminResult = $conn->query($adminQuery);
if ($adminResult === false) {
    $response['error'] = "Admin query failed: " . $conn->error;
} elseif ($adminResult->num_rows > 0) {
    $row = $adminResult->fetch_assoc();
    $response['admin_count'] = $row["admin_count"];
} else {
    $response['error'] = "No admin results";
}

// Close the connection
$conn->close();

// Convert the response array to JSON and print it
echo json_encode($response);
?>
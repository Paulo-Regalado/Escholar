<?php
include_once 'config.php';
$conn = OpenCon();
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the table name and selected student numbers
    $table_name = $_POST["table-name"];
    $selectedStudentNumbers = $_POST["approve-studNo"];
    $name = $_POST['user'];
    $dataCount = $_POST['selectedCount'];


    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Define the SQL query to update the status to "processed" for selected student numbers
    $sql = "UPDATE $table_name SET status = 'claim' WHERE student_number IN (";
    $placeholders = implode(",", array_fill(0, count($selectedStudentNumbers), "?"));
    $sql .= $placeholders . ")";

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $types = str_repeat("s", count($selectedStudentNumbers)); // Assuming student_number is a string
    $stmt->bind_param($types, ...$selectedStudentNumbers);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Success: Rows updated to 'processed' status.";
    } else {
        echo "Error: " . $stmt->error;
    }

    //Activity Logs
    $user = $name;
    $activity = 'Progress Tracker';
    $description = 'Move ' . $dataCount . ' records to Scholarship Grant Claim.';
    date_default_timezone_set('Asia/Manila');
    $date = date('Y-m-d H:i:s');

    $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
    $query->bind_param("ssss", $user, $activity, $description, $date);

    $result = $query->execute();
    //Activity Logs


    // Close the statement and database connection
    $stmt->close();
    $conn->close();
} else {
    // Handle non-POST requests
    echo "Invalid request method.";
}
$conn->close();
?>
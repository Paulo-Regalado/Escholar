<?php
session_start();
include_once 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the form is for updating the password

    $studentNumber = $_POST['student_number'];
    $newPassword = password_hash($_POST['new-pass'], PASSWORD_DEFAULT);

    // Check if the student exists in the database
    $checkStudent = $conn->prepare("SELECT student_number FROM user_account WHERE student_number = ?");
    $checkStudent->bind_param('i', $studentNumber);
    $checkStudent->execute();
    $checkStudent->store_result();

    if ($checkStudent->num_rows > 0) {
        // Update the password for the student
        $updatePassword = $conn->prepare("UPDATE user_account SET password = ? WHERE student_number = ?");
        $updatePassword->bind_param('si', $newPassword, $studentNumber);

        if ($updatePassword->execute()) {
            // Password update successful, show alert and redirect
            echo '<script>';
            echo 'alert("Password update successful!");';
            echo 'window.location.href = "../User/dashboard.php";';
            echo '</script>';
        } else {
            echo "Error: " . mysqli_error($conn);
            echo 'Error updating password';
        }
    } else {
        echo "Error: Student not found in the database";
    }
} else {
    echo "Error: Invalid request";
}

// Rest of your code
?>
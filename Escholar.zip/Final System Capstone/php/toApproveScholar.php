<?php

include 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $table_name = $_POST['table-name'];
    $approve_studNo = $_POST['approve-studNo'];
    $status = "approved";
    $name = $_POST['user'];


    $query = $conn->prepare("UPDATE " . $table_name . " SET status=? WHERE student_number=?");
    $query->bind_param('si', $status, $approve_studNo);

    if ($query->execute()) {

        // echo '<div class="alert alert-success alert-dismissible fade show w=100" role="alert">
        //         <strong>' . $approve_studNo . '</strong> has been changed.
        //         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        //     </div>';

        //Activity Logs
        $user = $name;
        $activity = 'Progress Tracking';
        $lastUnderscorePosition = strrpos($table_name, '_'); // Find the last underscore position
        // Extract the part before the last underscore and replace underscores with spaces
        $finalTableName = str_replace('_', ' ', substr($table_name, 0, $lastUnderscorePosition));
        $description = 'Approved ' . $approve_studNo . ' from ' . $finalTableName;
        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d H:i:s');

        $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
        $query->bind_param("ssss", $user, $activity, $description, $date);

        $result = $query->execute();
        //Activity Logs
    } else {
        echo "Error: " . mysqli_error($conn);
        echo 'Error Account';
    }

}
?>
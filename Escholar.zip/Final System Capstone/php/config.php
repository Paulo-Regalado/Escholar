<?php
function OpenCon()
{
    $dbhost = "localhost";
    $dbuser = "u156823415_escholar";
    $dbpass = "Escholar_2023";
    $db = "u156823415_escholar";


    $conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die("Connect failed: %s\n" . $conn->error);

    return $conn;
}

function CloseCon($conn)
{
    $conn->close();
}
?>
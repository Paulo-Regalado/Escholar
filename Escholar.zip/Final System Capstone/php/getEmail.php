<?php
session_start();
include_once 'config.php';
$conn = OpenCon();

// Retrieve student_number from the POST request
$student_number = $_POST['student_number'];

// Query to get the email associated with the student_number
$sql = "SELECT email FROM masterlist WHERE student_number = '$student_number'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Student number found, fetch the email
    $row = $result->fetch_assoc();
    $email = $row['email'];

    // Send the email back as a response
    echo $email;
} else {
    // Student number not found, return an empty string or an error message
    echo "";
}

// Close the database connection
$conn->close();
?>
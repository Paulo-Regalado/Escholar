<?php
include 'config.php';

$conn = OpenCon();

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Retrieve the values sent via POST
    $id = $_POST['account_id'];
    // $user = $_POST['user'];

    // Validate input (You should perform more validation as needed)

    // Prepare the DELETE query for the archived_announcement table
    $delete_query = "DELETE FROM admin_account WHERE account_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $id);

    // Execute the statement for deleting from archived_announcement table
    if (!$stmt->execute()) {
        // If there was an error in the delete operation for archived_announcement tabless
        $response = array('success' => false, 'error' => 'Error deleting account');
    } else {
        $response = array('success' => true);
    }

    // Close the prepared statement and database connection
    $stmt->close();
    $conn->close();

    // Send the JSON response back to the AJAX call
    echo json_encode($response);
} else {
    // If the request method is not POST, return an error
    echo json_encode(array('success' => false, 'error' => 'Invalid request method'));
}
?>

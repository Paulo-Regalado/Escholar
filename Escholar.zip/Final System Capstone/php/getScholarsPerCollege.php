<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query the benefactor table
$query = "SELECT table_name FROM benefactor";

$result = $conn->query($query);

if (!$result) {
    die('Query failed' . mysqli_error($conn));
}

$benefactors = [];

// Initialize an associative array to store unique colleges and their counts
$uniqueColleges = [];

while ($row = $result->fetch_assoc()) {
    // Assign the table_name from the current row
    $table_name = $row['table_name'];

    // Build a new query to get the student numbers from the specified table
    $studentQuery = "SELECT DISTINCT student_number FROM $table_name";

    // Execute the student query
    $studentResult = $conn->query($studentQuery);

    if (!$studentResult) {
        die('Student query failed' . mysqli_error($conn));
    }

    // Fetch the student numbers
    while ($studentRow = $studentResult->fetch_assoc()) {
        $studentNumber = $studentRow['student_number'];

        // Build a query to join with the masterlist table and get the college information
        $collegeQuery = "SELECT DISTINCT college FROM masterlist WHERE student_number = '$studentNumber'";

        // Execute the college query
        $collegeResult = $conn->query($collegeQuery);

        if (!$collegeResult) {
            die('College query failed' . mysqli_error($conn));
        }

        // Fetch the college result
        while ($collegeRow = $collegeResult->fetch_assoc()) {
            $college = $collegeRow['college'];

            // Count the occurrences of each college
            $uniqueColleges[$college] = isset($uniqueColleges[$college]) ? $uniqueColleges[$college] + 1 : 1;
        }
    }
}

// Add the count result to the benefactors array
foreach ($uniqueColleges as $college => $count) {
    $benefactors[] = [
        'name' => $college,
        'y' => $count // Display the count of each college in the chart
    ];
}

// Set the content type to JSON
header('Content-Type: application/json');

// Return JSON response with an array of objects
echo json_encode($benefactors);

// Close database connection
$conn->close();
?>
<?php
include_once 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $url = $_POST['url'];
    $name = $_POST['user'];

    // Check if the URL is empty or contains only whitespace
    $url = trim($url);
    $url = empty($url) ? null : $url;

    // Main File Handling
    if (!empty($_FILES['file']['name'])) {
        $fileName = $_FILES['file']['name'];
        $fileType = $_FILES['file']['type'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileError = $_FILES['file']['error'];

        if ($fileError === UPLOAD_ERR_OK) {
            // Move the uploaded file to the Announcement_Files folder
            $uploadDirectory = '../Announcement_Files/';
            $filePath = $uploadDirectory . $fileName;

            move_uploaded_file($fileTmpName, $filePath);
        } else {
            // Handle file upload error
            echo "<div class='alert alert-danger' role='alert'>Error uploading main file: " . $fileError . "</div>";
            exit();
        }
    } else {
        $fileName = null;
        $fileType = null;
    }

    // Supporting Document Handling
    if (!empty($_FILES['supporting-file']['name'])) {
        $supportingFileName = $_FILES['supporting-file']['name'];
        $supportingFileType = $_FILES['supporting-file']['type'];
        $supportingFileTmpName = $_FILES['supporting-file']['tmp_name'];
        $supportingFileError = $_FILES['supporting-file']['error'];

        if ($supportingFileError === UPLOAD_ERR_OK) {
            // Move the uploaded supporting file to the Announcement_Files folder
            $uploadSupportingDirectory = '../Announcement_Files/';
            $supportingFilePath = $uploadSupportingDirectory . $supportingFileName;

            move_uploaded_file($supportingFileTmpName, $supportingFilePath);
        } else {
            // Handle supporting file upload error
            echo "<div class='alert alert-danger' role='alert'>Error uploading supporting file: " . $supportingFileError . "</div>";
            exit();
        }
    } else {
        $supportingFileName = null;
        $supportingFileType = null;
    }

    date_default_timezone_set('Asia/Manila');
    $timestamp = date('Y-m-d');

    // Update your SQL query to include supporting document fields
    $queryAnnouncement = $conn->prepare("INSERT INTO announcement (title, description, url, file_name, file_type, supporting_name, supporting_type, date_created) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $queryAnnouncement->bind_param('ssssssss', $title, $description, $url, $fileName, $fileType, $supportingFileName, $supportingFileType, $timestamp);

    // Execute the query and handle errors
    $announcementSuccess = $queryAnnouncement->execute();

    if ($announcementSuccess) {
        echo "<div class='alert alert-success' role='alert'>Announcement has been added successfully</div>";

        // Activity Logs
        $user = $name;
        $activity = 'Announcement Management';
        $description = 'Posted an announcement about ' . $title;
        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d H:i:s');

        $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
        $query->bind_param("ssss", $user, $activity, $description, $date);

        if ($query->execute() === FALSE) {
            // Handle the insert query error
            echo json_encode(array("success" => false, "error" => "Error inserting data into activity_logs table: " . $conn->error));
            exit();
        }
        // Activity Logs
    } else {
        echo "<div class='alert alert-danger' role='alert'>Error: " . $conn->error . "</div>";
        echo 'Error Adding Announcement';
    }

    // Close the prepared statement
    $queryAnnouncement->close();
}

// Close the database connection
CloseCon($conn);
?>

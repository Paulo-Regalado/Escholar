<?php
include 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Get the student number from the AJAX request
$studentNumber = $_POST['student-number'];

// Query to get all dynamic table names from benefactor where particular = 'GOVERNMENT'
$tableNamesQuery = "SELECT table_name FROM benefactor WHERE particular = 'GOVERNMENT'";
$resultTableNames = $conn->query($tableNamesQuery);

// Check if the query was successful
if ($resultTableNames === false) {
    echo json_encode(['exist' => false]);
} else {
    $exist = false;

    // Loop through each table name
    while ($rowTableName = $resultTableNames->fetch_assoc()) {
        $benefactorTableName = $rowTableName['table_name'];

        // Query to check if the student number exists in the dynamic benefactor table excluding 'rejected' status
        $sql = "SELECT COUNT(*) AS count FROM $benefactorTableName 
                WHERE student_number = ? AND status != 'rejected'";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);

        // Bind the parameter
        $stmt->bind_param('i', $studentNumber);

        // Execute the query
        $stmt->execute();

        // Bind the result
        $stmt->bind_result($count);

        // Fetch the result
        $stmt->fetch();

        // Check if the student number exists in any benefactor table
        if ($count > 0) {
            $exist = true;
            break; // Exit the loop if the student number is found in any table
        }

        // Close the statement for the current table
        $stmt->close();
    }

    // Echo the result
    echo json_encode(['exist' => $exist]);
}

// Close the connection
$conn->close();
?>
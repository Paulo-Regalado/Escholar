<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all data from the database (including password_hash)
$sql = "SELECT * FROM admin_account";
$result = $conn->query($sql);

if ($result === false) {
    die("Error: " . $conn->error);
}

// Store the results in an array
$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Close the connection
$conn->close();

// Return data as JSON
header('Content-Type: application/json');
echo json_encode($data);
?>

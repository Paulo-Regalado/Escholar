<?php
session_start();
include_once '../php/config.php';
$conn = OpenCon();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form data
    $student_number = $_POST['student_number'];
    $gwa = $_POST['gwa'];
    $unit = $_POST['unit'];

    // File upload handling
    $cor_file_tmp = $_FILES["cor_file"]["tmp_name"];
    $cog_file_tmp = $_FILES["cog_file"]["tmp_name"];
    $id_file_tmp = $_FILES["id_file"]["tmp_name"];

    // Generate unique IDs for file names
    $cor_file_name = $student_number . '_COR' . '.pdf';
    $cog_file_name = $student_number . '_COG' . '.pdf';
    $id_file_name = $student_number . '_ID' . '.pdf';

    // Validate file uploads
    $upload_dir = '../Uploaded_Files/';

    // Ensure that the "uploads" directory exists and is writable
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    if (
        move_uploaded_file($cor_file_tmp, $upload_dir . $cor_file_name) &&
        move_uploaded_file($cog_file_tmp, $upload_dir . $cog_file_name) &&
        move_uploaded_file($id_file_tmp, $upload_dir . $id_file_name)
    ) {

        // Prepare an SQL query to insert the data into a table
        $sql = "INSERT INTO monitoring_form (student_number, gwa, units, cor_file_name, cog_file_name, id_file_name) VALUES (?, ?, ?, ?, ?,?)";

        // Prepare and bind the statement
        $stmt = $conn->prepare($sql);
        // Bind parameters to the prepared statement
        $stmt->bind_param("isssss", $student_number, $gwa, $unit, $cor_file_name, $cog_file_name, $id_file_name);

        // Execute the statement
        if ($stmt->execute()) {
            // Data inserted successfully

            // Get table names from benefactor table
            $getTableNamesSql = "SELECT table_name FROM benefactor";
            $getTableNamesResult = $conn->query($getTableNamesSql);

            if ($getTableNamesResult) {
                while ($row = $getTableNamesResult->fetch_assoc()) {
                    $tableName = $row['table_name'];

                    // Update status in each table
                    $updateStatusSql = "UPDATE $tableName SET status = 'pending' WHERE student_number = ?";
                    $updateStatusStmt = $conn->prepare($updateStatusSql);
                    $updateStatusStmt->bind_param("i", $student_number);

                    if ($updateStatusStmt->execute()) {
                        echo "Form data has been successfully inserted into the database, and status updated to pending in table $tableName.";
                    } else {
                        echo "Error updating status in table $tableName: " . $updateStatusStmt->error;
                    }

                    $updateStatusStmt->close();
                }
            } else {
                echo "Error fetching table names: " . $conn->error;
            }

            $getTableNamesResult->close();

        } else {
            // Error during insertion
            echo "Error inserting data into the database: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        // File upload error
        echo "Error uploading files.";
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
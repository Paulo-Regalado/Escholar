<?php
include_once 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentNumber = $_POST['student-number'];
    $lastName = $_POST['last-name'];
    $firstName = $_POST['first-name'];
    $middleName = $_POST['middle-name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $campus = $_POST['campus'];
    $college = $_POST['college'];
    $course = $_POST['course'];
    $yearLevel = $_POST['year-level'];
    $gwa = (float) $_POST['gwa'];
    $units = $_POST['units'];
    $name = $_POST['user'];

    // Additional Server-Side Validation Checks
    if (empty($studentNumber) || empty($lastName) || empty($firstName) || empty($email) || empty($contact) || empty($campus) || empty($college) || empty($course) || empty($yearLevel) || empty($gwa) || empty($units)) {
        echo "<div class='alert alert-danger' role='alert'>Please fill out all required fields.</div>";
        exit(); // Stop further processing
    }

    if (strlen($studentNumber) !== 10) {
        echo "<div class='alert alert-danger' role='alert'>Please enter a correct student number.</div>";
        exit();
    }

    if (!preg_match('/^[a-zA-Z ]+$/', $lastName)) {
        echo "<div class='alert alert-danger m-0' role='alert'>Last name should only contain letters.</div>";
        exit();
    }

    if (!preg_match('/^[a-zA-Z ]+$/', $firstName)) {
        echo "<div class='alert alert-danger m-0' role='alert'>First name should only contain letters.</div>";
        exit();
    }

    if (!preg_match('/^[a-zA-Z ]*$/', $middleName)) {
        echo "<div class='alert alert-danger m-0' role='alert'>Middle name should only contain letters.</div>";
        exit();
    }


    if (!preg_match('/^[0-9]{11}$/', $contact)) {
        echo "<div class='alert alert-danger m-0' role='alert'>Please enter a valid contact number in the format 09XXXXXXXXX.</div>";
        exit();
    }

    if (!is_numeric($gwa) || $gwa < 1 || $gwa > 5) {
        echo "<div class='alert alert-danger m-0' role='alert'>Please enter a valid GWA between 1.00 and 5.00</div>";
        exit();
    }

    if (!is_numeric($units) || $units < 1 || $units > 100) {
        echo "<div class='alert alert-danger m-0' role='alert'>Please enter a valid whole number for the unit between 1 and 100.</div>";
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<div class='alert alert-danger m-0' role='alert'>Please enter a valid email address.</div>";
        exit();
    }

    // Check if the student number exists in masterlist
    $checkQuery = $conn->prepare("SELECT student_number FROM masterlist WHERE student_number = ?");
    $checkQuery->bind_param('i', $studentNumber);
    $checkQuery->execute();
    $checkQuery->store_result();

    if ($checkQuery->num_rows > 0) {
        // Student number already exists in masterlist, insert into benefactor table only
        $table_name = $_POST['table-name'];
        $status = "approved";

        $queryBenefactor = $conn->prepare("INSERT INTO $table_name(student_number, status) VALUES (?, ?)");
        $queryBenefactor->bind_param('is', $studentNumber, $status);

        // Execute query and handle errors
        $benefactorSuccess = $queryBenefactor->execute();


        // ADD HERE

        if ($benefactorSuccess) {

            // Check if there's no existing record for the student_number
            $checkExistingQuery = $conn->prepare("SELECT COUNT(*) FROM monitoring_form WHERE student_number = ?");
            $checkExistingQuery->bind_param('i', $studentNumber);
            $checkExistingQuery->execute();
            $checkExistingQuery->bind_result($existingRecordCount);
            $checkExistingQuery->fetch();
            $checkExistingQuery->close();

            // Only insert a new record if there's no existing record
            if ($existingRecordCount == 0) {
                $fileField = null;
                $queryMonitoringForm = $conn->prepare("INSERT INTO monitoring_form (student_number, gwa, units, cor_file_name, cog_file_name, id_file_name) VALUES (?, ?, ?, ?, ?, ?)");
                $queryMonitoringForm->bind_param('idisss', $studentNumber, $gwa, $units, $fileField, $fileField, $fileField);

                // Execute the query and handle errors
                $monitoringFormSuccess = $queryMonitoringForm->execute();
            }

            //Activity Logs
            $user = $name;
            $activity = 'Scholar Management';
            $lastUnderscorePosition = strrpos($table_name, '_'); // Find the last underscore position
            // Extract the part before the last underscore and replace underscores with spaces
            $finalTableName = str_replace('_', ' ', substr($table_name, 0, $lastUnderscorePosition));
            $description = 'Added ' . $studentNumber . ' in ' . $finalTableName . ' benefactor.';
            date_default_timezone_set('Asia/Manila');
            $date = date('Y-m-d H:i:s');

            $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
            $query->bind_param("ssss", $user, $activity, $description, $date);

            $result = $query->execute();
            if ($result) {
                // echo "Activity log inserted successfully.";
            } else {
                echo "Error inserting activity log: " . $conn->error;
            }
            //Activity Logs

            echo "<div class='alert alert-success' role='alert'>" . $studentNumber . " has been added successfully to Benefactor table</div>";
        } else {
            echo "<div class='alert alert-danger' role='alert'>Error: " . $conn->error . "</div>";
        }



        // Close prepared statement
        $queryBenefactor->close();
    } else {
        // Student number doesn't exist in masterlist, proceed with inserting into both tables
        $table_name = $_POST['table-name'];

        $queryMasterlist = $conn->prepare("INSERT INTO masterlist(student_number, last_name, first_name, middle_name, email, contact, campus, college, course, year_level, gwa, units) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $queryMasterlist->bind_param('isssssssssdi', $studentNumber, $lastName, $firstName, $middleName, $email, $contact, $campus, $college, $course, $yearLevel, $gwa, $units);

        $status = "approved";
        $queryBenefactor = $conn->prepare("INSERT INTO $table_name(student_number, status) VALUES (?, ?)");
        $queryBenefactor->bind_param('is', $studentNumber, $status);


        // Check if there's no existing record for the student_number
        $checkExistingQuery = $conn->prepare("SELECT COUNT(*) FROM monitoring_form WHERE student_number = ?");
        $checkExistingQuery->bind_param('i', $studentNumber);
        $checkExistingQuery->execute();
        $checkExistingQuery->bind_result($existingRecordCount);
        $checkExistingQuery->fetch();
        $checkExistingQuery->close();

        // Only insert a new record if there's no existing record
        if ($existingRecordCount == 0) {
            $fileField = null;
            $queryMonitoringForm = $conn->prepare("INSERT INTO monitoring_form (student_number, gwa, units, cor_file_name, cog_file_name, id_file_name) VALUES (?, ?, ?, ?, ?, ?)");
            $queryMonitoringForm->bind_param('idisss', $studentNumber, $gwa, $units, $fileField, $fileField, $fileField);

            // Execute the query and handle errors
            $monitoringFormSuccess = $queryMonitoringForm->execute();
        }

        // Execute queries and handle errors
        $masterlistSuccess = $queryMasterlist->execute();
        $benefactorSuccess = $queryBenefactor->execute();

        // ADD HERE

        if ($masterlistSuccess && $benefactorSuccess) {
            //Activity Logs
            $user = $name;
            $activity = 'Scholar Management';
            $lastUnderscorePosition = strrpos($table_name, '_'); // Find the last underscore position
            // Extract the part before the last underscore and replace underscores with spaces
            $finalTableName = str_replace('_', ' ', substr($table_name, 0, $lastUnderscorePosition));
            $description = 'Added ' . $studentNumber . ' in ' . $finalTableName . ' benefactor.';
            date_default_timezone_set('Asia/Manila');
            $date = date('Y-m-d H:i:s');

            $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
            $query->bind_param("ssss", $user, $activity, $description, $date);

            $result = $query->execute();
            if ($result) {
                // echo "Activity log inserted successfully.";
            } else {
                echo "Error inserting activity log: " . $conn->error;
            }
            //Activity Logs


            echo "<div class='alert alert-success' role='alert'>" . $studentNumber . " has been added successfully.</div>";
        } else {
            echo "<div class='alert alert-danger' role='alert'>Error: " . $conn->error . "</div>";
        }



        // Close prepared statements
        $queryMasterlist->close();
        $queryBenefactor->close();
    }

    // Close the database connection
    $checkQuery->close();
}


CloseCon($conn);

?>
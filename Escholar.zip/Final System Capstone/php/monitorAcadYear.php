<?php
include_once 'config.php';

// Establish database connection
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

try {
    // Fetch data from the benefactor table
    $sql = "SELECT * FROM benefactor";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error executing query: " . $conn->error);
    }

    $data = array();

    if ($result->num_rows > 0) {


        $update_year_level_sql = "UPDATE masterlist SET year_level =
        CASE
            WHEN year_level = '1st' THEN '2nd'
            WHEN year_level = '2nd' THEN '3rd'
            WHEN year_level = '3rd' THEN '4th'
            WHEN year_level = '4th' THEN 'graduate'
            ELSE 'graduate' END";

        if ($conn->query($update_year_level_sql) === FALSE) {
            throw new Exception("Error updating records in masterlist: " . $conn->error);
        }

        while ($row = $result->fetch_assoc()) {
            // Extract benefactor data
            $id = $row['id'];
            $particular = $row['particular'];
            $semester = $row['semester'];
            $name = $row['name'];
            $slot = $row['slot'];
            $amount = $row['amount'];
            $name_from_sy = $row['from_sy'];
            $name_to_sy = $row['to_sy'];
            $scholar_table = $row['table_name'];

            // Fetch data from dynamic table
            $fetch_data_sql = "SELECT student_number, status FROM $scholar_table";
            $fetch_data_result = $conn->query($fetch_data_sql);

            if ($fetch_data_result === false) {
                throw new Exception("Error fetching data.");
            }

            // Generate a unique table name
            $table_id = uniqid();
            $table_name = str_replace(' ', '_', $name) . '_' . $table_id;

            // Prepare and execute the INSERT query for archived benefactor
            $query = $conn->prepare("INSERT INTO archived_benefactor(particular, semester, name, slot, amount, from_sy, to_sy, table_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $query->bind_param('sssiiiis', $particular, $semester, $name, $slot, $amount, $name_from_sy, $name_to_sy, $scholar_table);

            if ($query->execute()) {
                // Create the table if it doesn't exist
                $create_table_sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
                    `student_number` int(10) NOT NULL,
                    `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL,
                    PRIMARY KEY (`student_number`)
                )";

                $stmtCreateTable = $conn->prepare($create_table_sql);

                if ($stmtCreateTable->execute()) {
                    // Prepare and execute the INSERT query for benefactor
                    $query = $conn->prepare("INSERT INTO benefactor(particular, semester, name, slot, amount, from_sy, to_sy, table_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

                    if ($semester == "1ST") {
                        $new_semester = "2ND";
                        $query->bind_param('sssiiiis', $particular, $new_semester, $name, $slot, $amount, $name_from_sy, $name_to_sy, $table_name);
                    } else {
                        $new_semester = "1ST";
                        $new_from_sy = $name_from_sy + 1;
                        $new_to_sy = $name_to_sy + 1;
                        $query->bind_param('sssiiiis', $particular, $new_semester, $name, $slot, $amount, $new_from_sy, $new_to_sy, $table_name);
                    }


                    // year_level = 4

                    if ($query->execute()) {
                        // Update year level in the masterlist table
                        // Insert data into the dynamically created table
                        while ($student_row = $fetch_data_result->fetch_assoc()) {
                            $student_number = $student_row['student_number'];
                            $status = $student_row['status'];

                            // Fetch year_level from the masterlist table
                            $year_level_query = "SELECT year_level FROM masterlist WHERE student_number = ?";
                            $stmtYearLevel = $conn->prepare($year_level_query);
                            $stmtYearLevel->bind_param('i', $student_number);
                            $stmtYearLevel->execute();
                            $stmtYearLevel->bind_result($year_level);

                            // Fetch the year_level value
                            $stmtYearLevel->fetch();
                            $stmtYearLevel->close();

                            // Check if status is not 'rejected' or 'waiting' and year_level is not 'graduate'
                            if ($status != 'rejected' && $status != 'waiting' && $year_level != 'graduate') {
                                $status_waiting = "waiting";
                                $insert_data_sql = "INSERT INTO $table_name (student_number, status) VALUES (?, ?)";
                                $stmtInsertData = $conn->prepare($insert_data_sql);
                                $stmtInsertData->bind_param('is', $student_number, $status_waiting);
                                $stmtInsertData->execute();

                                $data[] = $student_row;
                            }
                        }
                    } else {
                        throw new Exception("Error inserting benefactor.");
                    }
                }
            }

            // Prepare and execute the DELETE query for benefactor record
            $deleteQuery = "DELETE FROM benefactor WHERE id = ?";
            $stmtDelete = $conn->prepare($deleteQuery);
            $stmtDelete->bind_param('i', $id);

            if ($stmtDelete->execute()) {
                // Select all student numbers from masterlist where year level is not 'graduate'
                $selectNonGraduateStudents = "SELECT student_number FROM masterlist WHERE year_level != 'graduate'";
                $resultNonGraduate = $conn->query($selectNonGraduateStudents);  // Use a different variable

                if ($resultNonGraduate === FALSE) {
                    throw new Exception("Error selecting non-graduate students: " . $conn->error);
                }

                // Iterate through the result set and delete records in monitoring_form table
                while ($nonGraduateRow = $resultNonGraduate->fetch_assoc()) {
                    $studentNumber = $nonGraduateRow['student_number'];

                    // Delete records from monitoring_form for non-graduate students
                    $delete_monitoring_form_sql = "DELETE FROM monitoring_form WHERE student_number = ?";
                    $stmtDeleteMonitoringForm = $conn->prepare($delete_monitoring_form_sql);
                    $stmtDeleteMonitoringForm->bind_param('i', $studentNumber);

                    if ($stmtDeleteMonitoringForm->execute() === FALSE) {
                        throw new Exception("Error deleting records from monitoring_form: " . $conn->error);
                    }

                    $stmtDeleteMonitoringForm->close();  // Close the statement after execution
                }

                $stmtDelete->close();  // Close the first statement after fetching from the second statement
            }
        }



        // Activity Logs
        $user = 'Admin';
        $activity = 'Academic Management';
        $description = 'Updated the system for the new academic year to ' . $new_from_sy . ' to ' . $new_to_sy;
        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d H:i:s');

        $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
        $query->bind_param("ssss", $user, $activity, $description, $date);

        if ($query->execute() === FALSE) {
            throw new Exception("Error inserting data into activity_logs table: " . $conn->error);
        }

        // Return the data in JSON format
        echo json_encode(array("success" => true, "data" => $data));
    } else {
        // No results found
        echo json_encode(array("success" => true, "data" => array()));
    }
} catch (Exception $e) {
    // Handle exceptions
    echo json_encode(array("success" => false, "error" => $e->getMessage()));
} finally {
    // Close the database connection
    $conn->close();
}
?>
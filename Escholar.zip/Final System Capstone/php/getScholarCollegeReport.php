<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$selectedOption = $_GET['selectedOption'];

list($from_sy, $to_sy, $sem) = explode('-', $selectedOption);
$benefactors = [];

// Function to process the query and update $benefactors array
function processBenefactorQuery($query, $conn, &$benefactors)
{
    $result = $conn->query($query);

    if (!$result) {
        die('Query failed' . mysqli_error($conn));
    }

    $uniqueColleges = [];

    while ($row = $result->fetch_assoc()) {
        $table_name = $row['table_name'];
        $studentQuery = "SELECT DISTINCT student_number FROM $table_name";
        $studentResult = $conn->query($studentQuery);

        if (!$studentResult) {
            die('Student query failed' . mysqli_error($conn));
        }

        while ($studentRow = $studentResult->fetch_assoc()) {
            $studentNumber = $studentRow['student_number'];
            $collegeQuery = "SELECT DISTINCT college FROM masterlist WHERE student_number = '$studentNumber'";
            $collegeResult = $conn->query($collegeQuery);

            if (!$collegeResult) {
                die('College query failed' . mysqli_error($conn));
            }

            while ($collegeRow = $collegeResult->fetch_assoc()) {
                $college = $collegeRow['college'];
                $uniqueColleges[$college] = isset($uniqueColleges[$college]) ? $uniqueColleges[$college] + 1 : 1;
            }
        }
    }

    foreach ($uniqueColleges as $college => $count) {
        $benefactors[] = [
            'name' => $college,
            'y' => $count
        ];
    }
}

// Query the benefactor table
$query = "SELECT name, table_name FROM benefactor WHERE from_sy = '$from_sy' AND to_sy = '$to_sy' AND semester = '$sem' GROUP BY name";
processBenefactorQuery($query, $conn, $benefactors);

// If no benefactors found in benefactor table, query archived_benefactor table
if (empty($benefactors)) {
    $queryArchived = "SELECT name, table_name FROM archived_benefactor WHERE from_sy = '$from_sy' AND to_sy = '$to_sy' AND semester = '$sem' GROUP BY name";
    processBenefactorQuery($queryArchived, $conn, $benefactors);
}

// Set the content type to JSON
header('Content-Type: application/json');

// Return JSON response with an array of objects
echo json_encode($benefactors);

// Close database connection
$conn->close();
?>
<?php
include_once 'config.php';

// Establish database connection
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

try {
    // Fetch data from the benefactor table
    $sql = "SELECT * FROM benefactor";
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error executing query: " . $conn->error);
    }

    $data = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Extract benefactor data
            $id = $row['id'];
            $particular = $row['particular'];
            $semester = $row['semester'];
            $name = $row['name'];
            $slot = $row['slot'];
            $amount = $row['amount'];
            $name_from_sy = $row['from_sy'];
            $name_to_sy = $row['to_sy'];
            $scholar_table = $row['table_name'];

            // Fetch data from dynamic table
            $fetch_data_sql = "SELECT student_number, status FROM $scholar_table";
            $fetch_data_result = $conn->query($fetch_data_sql);

            if ($fetch_data_result === false) {
                throw new Exception("Error fetching data.");
            }

            // Generate a unique table name
            $table_id = uniqid();
            $table_name = str_replace(' ', '_', $name) . '_' . $table_id;

            // Prepare and execute the INSERT query for archived benefactor
            $query = $conn->prepare("INSERT INTO archived_benefactor(particular, semester, name, slot, amount, from_sy, to_sy, table_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $query->bind_param('sssiiiis', $particular, $semester, $name, $slot, $amount, $name_from_sy, $name_to_sy, $scholar_table);

            if ($query->execute()) {
                // Create the table if it doesn't exist
                $create_table_sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
                    `student_number` int(10) NOT NULL,
                    `status` enum('waiting','pending','approved','rejected','processed','claim') NOT NULL,
                    PRIMARY KEY (`student_number`)
                )";

                $stmtCreateTable = $conn->prepare($create_table_sql);

                if ($stmtCreateTable->execute()) {
                    // Insert data into the dynamically created table
                    while ($student_row = $fetch_data_result->fetch_assoc()) {
                        $student_number = $student_row['student_number'];
                        $status = $student_row['status'];

                        // Check if status is not 'rejected' or 'waiting'
                        if ($status != 'rejected' && $status != 'waiting') {
                            $status_waiting = "waiting";
                            $insert_data_sql = "INSERT INTO $table_name (student_number, status) VALUES (?, ?)";
                            $stmtInsertData = $conn->prepare($insert_data_sql);
                            $stmtInsertData->bind_param('is', $student_number, $status_waiting);
                            $stmtInsertData->execute();

                            $data[] = $student_row;
                        }
                    }

                    // Prepare and execute the INSERT query for benefactor
                    $query = $conn->prepare("INSERT INTO benefactor(particular, semester, name, slot, amount, from_sy, to_sy, table_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

                    if ($semester == "1ST") {
                        $new_semester = "2ND";
                        $query->bind_param('sssiiiis', $particular, $new_semester, $name, $slot, $amount, $name_from_sy, $name_to_sy, $table_name);
                    } else {
                        $new_semester = "1ST";
                        $new_from_sy = $name_from_sy + 1;
                        $new_to_sy = $name_to_sy + 1;
                        $query->bind_param('sssiiiis', $particular, $new_semester, $name, $slot, $amount, $new_from_sy, $new_to_sy, $table_name);
                    }

                    $query->execute();
                }
            }

            // Prepare and execute the DELETE query for benefactor record
            $deleteQuery = "DELETE FROM benefactor WHERE id = ?";
            $stmtDelete = $conn->prepare($deleteQuery);
            $stmtDelete->bind_param('i', $id);

            if ($stmtDelete->execute()) {
                // Delete records from monitoring_form
                $delete_monitoring_form_sql = "DELETE FROM monitoring_form";
                if ($conn->query($delete_monitoring_form_sql) === FALSE) {
                    throw new Exception("Error deleting records from monitoring_form: " . $conn->error);
                }
            }
        }

        // Insert into activity_logs
        $user = 'Admin';
        $activity = 'Academic Management';
        $description = 'Updated the system for the new semester';
        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d H:i:s');

        $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
        $query->bind_param("ssss", $user, $activity, $description, $date);

        if ($query->execute() === FALSE) {
            throw new Exception("Error inserting data into activity_logs table: " . $conn->error);
        }

        // Return the data in JSON format
        echo json_encode(array("success" => true, "data" => $data));
    } else {
        // No results found
        echo json_encode(array("success" => true, "data" => array()));
    }
} catch (Exception $e) {
    // Handle exceptions
    echo json_encode(array("success" => false, "error" => $e->getMessage()));
} finally {
    // Close the database connection
    $conn->close();
}
?>

<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

if (isset($_POST['emails'])) {
    $email = $_POST['emails'];


    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'ofsasscholarshiptracker@gmail.com';
    $mail->Password = 'cnzzoctusxpxlgpa';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('ofsasscholarshiptracker@gmail.com');

    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = 'Update New Semester';
    $mail->Body = '<h4>Hello Scholars! </h4><br><h4>As we embark on the new semester, your dedication to your academic journey is commendable, and we are here to support you every step of the way.
    To ensure the continued success of our scholarship program and to monitor your academic progress, we kindly request that you submit your Certificate of Registration (COR) and Certificate of Grades (COG) for the Academic Year 2023 - 2024 2nd Semester on your scholar portal. 
    To access your scholar portal, please click on the following link: http://escholar.eyjeyesdiar.com/
    <br>Your prompt attention to this matter is greatly appreciated. Failure to submit these documents may result in the possibility of being removed from the list of scholarship recipients.
    <br><br>Please be guided. Thank you!</h4>';

    if ($mail->send()) {
        echo '<script>alert("Sent Successful");</script>';
    } else {
        echo '<script>alert("Sending failed: ' . $mail->ErrorInfo . '");</script>';
    }
}
?>
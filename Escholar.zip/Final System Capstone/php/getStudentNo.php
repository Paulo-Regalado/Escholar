<?php
include 'config.php';

$conn = OpenCon();

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['student_number'])) {
    $student_number = mysqli_real_escape_string($conn, $_POST['student_number']); // Sanitize input

    // Query to get all table names from the "benefactor" table
    $benefactor_query = "SELECT table_name FROM benefactor";
    $benefactor_result = mysqli_query($conn, $benefactor_query);

    if (!$benefactor_result) {
        echo "Database Error: " . mysqli_error($conn);
        exit;
    }

    $found = false; // Flag to check if the student number was found in any table

    while ($row = mysqli_fetch_assoc($benefactor_result)) {
        $table_name = $row['table_name'];

        // Query to check if the student number exists in the dynamically determined table
        $check_query = "SELECT * FROM $table_name WHERE student_number = ? AND status IN ('approved', 'processed', 'claim') LIMIT 1";
        $stmt = mysqli_prepare($conn, $check_query);

        if (!$stmt) {
            echo "Database Error: " . mysqli_error($conn);
            exit;
        }

        mysqli_stmt_bind_param($stmt, "s", $student_number);
        mysqli_stmt_execute($stmt);
        $check_result = mysqli_stmt_get_result($stmt);

        if (!$check_result) {
            echo "Database Error: " . mysqli_error($conn);
            exit;
        }

        if (mysqli_num_rows($check_result) > 0) {
            echo "existing and approved";
            $found = true;
            break; // Stop the loop after finding the first existing result
        }
    }

    // Check if the student number exists in the user_account table
    $user_account_query = "SELECT * FROM user_account WHERE student_number = ?";
    $stmt_user = mysqli_prepare($conn, $user_account_query);

    if (!$stmt_user) {
        echo "Database Error: " . mysqli_error($conn);
        exit;
    }

    mysqli_stmt_bind_param($stmt_user, "s", $student_number);
    mysqli_stmt_execute($stmt_user);
    $user_result = mysqli_stmt_get_result($stmt_user);

    if (!$user_result) {
        echo "Database Error: " . mysqli_error($conn);
        exit;
    }

    if (mysqli_num_rows($user_result) > 0) {
        echo " already register";
        $found = true;
    }

    if (!$found) {
        echo "not existing";
    }
} else {
    echo "Error: Student number not provided";
}

// Close the database connection
mysqli_close($conn);
?>
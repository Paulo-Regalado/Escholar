<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query your database and fetch data from benefactor table
$sql = "SELECT * FROM benefactor";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $benefactorData = $row;
        $tableName = $row['table_name'];

        // Query to count the data in the corresponding table_name table
        $countSql = "SELECT COUNT(*) AS count FROM $tableName WHERE status = 'pending'";
        $countResult = $conn->query($countSql);

        if ($countResult->num_rows > 0) {
            $countRow = $countResult->fetch_assoc();
            $benefactorData['table_count'] = $countRow['count'];
        } else {
            $benefactorData['table_count'] = 0; // Table not found or empty
        }

        $data[] = $benefactorData;
    }
    echo json_encode($data);
} else {
    echo json_encode(array()); // No results found in benefactor table
}

$conn->close();
?>
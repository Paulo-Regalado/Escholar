<?php
include_once 'config.php';

// Establish a database connection
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $admin = $_POST['user'];

    // Prepare and execute the SELECT query
    $stmtSelect = $conn->prepare("SELECT * FROM archived_announcement WHERE id = ?");
    $stmtSelect->bind_param('i', $id);
    $stmtSelect->execute();

    // Get result set
    $result = $stmtSelect->get_result();
    $archiveAnnouncementData = $result->fetch_assoc();

    // Prepare and execute the INSERT query
    $insertQuery = "INSERT INTO announcement (title, description, url, file_name, file_type, date_created)
                    VALUES (?, ?, ?, ?, ?, ?)";
    $stmtInsert = $conn->prepare($insertQuery);

    // Explicitly bind parameters
    $stmtInsert->bind_param(
        'ssssss',
        $archiveAnnouncementData['title'],
        $archiveAnnouncementData['description'],
        $archiveAnnouncementData['url'],
        $archiveAnnouncementData['file_name'],
        $archiveAnnouncementData['file_type'],
        $archiveAnnouncementData['date_created']
    );

    $stmtInsert->execute();

    // Prepare and execute the DELETE query
    $deleteQuery = "DELETE FROM archived_announcement WHERE id = ?";
    $stmtDelete = $conn->prepare($deleteQuery);
    $stmtDelete->bind_param('i', $id);
    $stmtDelete->execute();

    //Activity Logs
    $user = $admin;
    $activity = 'Benefactor Management';
    $finalTableName = $archiveAnnouncementData['title'];
    $description = 'Restore ' . $finalTableName . ' in announcement.';
    date_default_timezone_set('Asia/Manila');
    $date = date('Y-m-d H:i:s');

    $query = $conn->prepare("INSERT INTO activity_logs(admin_username, activity_type, description, date) VALUES (?, ?, ?, ?)");
    $query->bind_param("ssss", $user, $activity, $description, $date);

    $result = $query->execute();
    //Activity Logs


    // Close connections
    $stmtSelect->close();
    $stmtInsert->close();
    $stmtDelete->close();

    // Close MySQLi connection
    CloseCon($conn);

    // Return a response to the client (success or error)
    echo json_encode(['success' => true]);
} else {
    // Handle invalid request method
    echo json_encode(['error' => 'Invalid request method']);
    CloseCon($conn); // Close connection in case of an error
}
?>
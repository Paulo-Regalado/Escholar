<?php
include_once 'config.php';

// Validate and sanitize inputs
function sanitizeInput($input)
{
    return htmlspecialchars(trim($input));
}

$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from the AJAX request and sanitize inputs
$lastName = sanitizeInput($_POST['lastname']);
$firstName = sanitizeInput($_POST['firstname']);
$middleName = sanitizeInput($_POST['middlename']);
$username = sanitizeInput($_POST['account-username']);
$password = password_hash(sanitizeInput($_POST['account-password']), PASSWORD_DEFAULT);

// Server-side validations
if (!preg_match("/^[a-zA-Z]+$/", $lastName)) {
    die(json_encode(['success' => false, 'message' => 'Last name should only contain letters']));
} elseif (!preg_match("/^[a-zA-Z ]+$/", $firstName)) {
    die(json_encode(['success' => false, 'message' => 'First name should only contain letters']));
} elseif (strlen($username) != 10) {
    die(json_encode(['success' => false, 'message' => 'Account Number must be 10 digits']));
} elseif (!ctype_digit($username)) {
    die(json_encode(['success' => false, 'message' => 'Username should only contain numbers']));
} elseif (preg_match('/\s/', $username)) {
    die(json_encode(['success' => false, 'message' => 'Username should not contain empty spaces']));
} elseif (strlen($password) < 8 || !preg_match("/[a-zA-Z]/", $password) || !preg_match("/\d/", $password)) {
    die(json_encode(['success' => false, 'message' => 'Password must be at least 8 characters long and include both letters and numbers']));
} else {
    // Validate if the username is already taken
    $checkUsernameQuery = "SELECT * FROM admin_account WHERE account_number = ?";
    $stmt = $conn->prepare($checkUsernameQuery);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        die(json_encode(['success' => false, 'message' => 'Username already taken']));
    } else {
        // Insert the new account into the database using a prepared statement
        $insertQuery = "INSERT INTO admin_account (last_name, first_name, middle_name, account_number, password_hash)
                        VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("sssss", $lastName, $firstName, $middleName, $username, $password);

        // Use transactions to ensure data consistency
        $conn->begin_transaction();

        try {
            if ($stmt->execute()) {
                // Commit the transaction if the insertion is successful
                $conn->commit();
                die(json_encode(['success' => true, 'message' => 'Account added successfully']));
            } else {
                // Rollback the transaction in case of an insertion error
                $conn->rollback();
                die(json_encode(['success' => false, 'message' => 'Error adding account: ' . $stmt->error]));
            }
        } catch (Exception $e) {
            // Rollback the transaction on any exception
            $conn->rollback();
            die(json_encode(['success' => false, 'message' => 'Error adding account: ' . $e->getMessage()]));
        }
    }
}

// Close the database connection
$conn->close();
?>
<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define the table name
$table_name = "activity_logs";

// Query your database and fetch data
$sql = "SELECT admin_username, activity_type, description, date FROM $table_name"; // Include the 'timestamp' column

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    // Return the data in JSON format
    echo json_encode(array("data" => $data));
} else {
    // No results found
    echo json_encode(array("data" => array()));
}

$conn->close();
?>
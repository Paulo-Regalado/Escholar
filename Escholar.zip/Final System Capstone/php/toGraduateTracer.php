<?php
// session_start();
include_once 'config.php';
$conn = OpenCon();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form data
// Retrieve form data
    $student_number = $_POST['student_number'];
    $full_name = $_POST['full_name'];
    $birthday = $_POST['birthday'];
    $gender = $_POST['gender'];
    $civil_status = $_POST['civil_status'];
    $current_address = $_POST['current_address'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $course = $_POST['course'];
    $year_graduated = $_POST['year_graduated'];
    $benefactor = $_POST['benefactor'];
    $campus = $_POST['campus'];
    $employment = $_POST['employment'];
    $org_type = $_POST['org_type'];
    $company_name = $_POST['company_name'];
    $comp_address = $_POST['company_address'];
    $position = $_POST['position'];
    $year_in_company = $_POST['year_in_company'];
    $reasons = $_POST['reasons'];

    // File upload handling
    $gradpic_file_tmp = $_FILES["grad_pic"]["tmp_name"];
    $gradpic_file_ext = pathinfo($_FILES["grad_pic"]["name"], PATHINFO_EXTENSION);

    // Set the desired file name
    $gradpic_file_name = $student_number . '_gradpic' . '.' . $gradpic_file_ext;

    // Validate file uploads
    $upload_dir = '../User/Graduate_Pic';

    // Ensure that the "uploads" directory exists and is writable
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Move uploaded file to destination directory
    if (move_uploaded_file($gradpic_file_tmp, $upload_dir . '/' . $gradpic_file_name)) {

        // Check if a record with the same student_number exists
        $check_sql = "SELECT student_number FROM graduate_information WHERE student_number = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $student_number);
        $check_stmt->execute();
        $check_stmt->store_result();
        $record_count = $check_stmt->num_rows;

        if ($record_count > 0) {
            // If a record with the same student_number exists, update it
            $update_sql = "UPDATE graduate_information SET grad_pic = ?, complete_name = ?, birthday = ?, gender = ?, civil_status = ?, current_address = ?, contact = ?, email = ?, course = ?, year_graduated = ?, benefactor = ?, campus = ?, employment = ?, org_type = ?, company_name = ?, company_address = ?, position = ?, year_in_company = ?, reasons = ? WHERE student_number = ?";

            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("sssssssssisssssssisi", $gradpic_file_name, $full_name, $birthday, $gender, $civil_status, $current_address, $contact, $email, $course, $year_graduated, $benefactor, $campus, $employment, $org_type, $company_name, $comp_address, $position, $year_in_company, $reasons, $student_number);

            if ($update_stmt->execute()) {
                // Record updated successfully
                // echo "<script>alert('Record has been updated in the database.'); window.location.href = '..User/dashboard.php';</script>";
            } else {
                // Error during update
                echo "Error updating the record in the database: " . $update_stmt->error;
            }
        } else {
            // If no record with the same student_number exists, insert a new record
            $insert_sql = "INSERT INTO graduate_information (grad_pic, student_number, complete_name, birthday, gender, civil_status, current_address, contact, email, course, year_graduated, benefactor, campus, employment, org_type, company_name, company_address, position, year_in_company, reasons) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("sisssssississsssssis", $gradpic_file_name, $student_number, $full_name, $birthday, $gender, $civil_status, $current_address, $contact, $email, $course, $year_graduated, $benefactor, $campus, $employment, $org_type, $company_name, $comp_address, $position, $year_in_company, $reasons);

            if ($insert_stmt->execute()) {
                // Record inserted successfully
                // echo "<script>alert('Form data has been successfully inserted into the database.'); window.location.href = '..User/dashboard.php';</script>";
            } else {
                // Error during insertion
                echo "Error inserting data into the database: " . $insert_stmt->error;
            }
        }

        // Close the statement
        $stmt->close();
    } else {
        // File upload error
        echo "Error uploading gradpic file.";
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
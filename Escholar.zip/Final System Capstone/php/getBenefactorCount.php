<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get the total number of graduates for each employment status
$sql = "SELECT particular, COUNT(*) as total_count FROM benefactor GROUP BY particular";
$result = $conn->query($sql);

// Fetch the result into an associative array
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        'name' => $row['particular'],
        'y' => (int) $row['total_count']
    ];
}

// Set the content type to JSON
header('Content-Type: application/json');

// Return JSON response with an array of objects
echo json_encode($data);

// Close database connection
$conn->close();
?>
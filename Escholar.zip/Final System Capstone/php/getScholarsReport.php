<?php
include_once 'config.php';
$conn = OpenCon();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name, table_name FROM benefactor";
$result = $conn->query($sql);

$data = array();

while ($row = $result->fetch_assoc()) {
    // Use a single query to get the count for each table
    $count_sql = "SELECT COUNT(*) as count FROM " . $row['table_name'];
    $count_result = $conn->query($count_sql);
    $count_row = $count_result->fetch_assoc();

    // Add data to the array in the desired structure
    $data[] = array(
        'name' => $row['name'],
        'y' => (int)$count_row['count'] // Explicitly cast count to an integer
    );
}

// Set the content type to JSON
header('Content-Type: application/json');

// Return JSON response using json_encode
echo json_encode($data);

// Close database connection
$conn->close();
?>

<?php
include_once 'config.php';
$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare and execute a SQL query to retrieve announcement data by ID
    $queryAnnouncement = $conn->prepare("SELECT * FROM announcement WHERE id = ?");
    $queryAnnouncement->bind_param('i', $id);

    if ($queryAnnouncement->execute()) {
        $result = $queryAnnouncement->get_result();

        if ($result->num_rows === 1) {
            // Fetch the announcement data
            $announcementData = $result->fetch_assoc();

            // Return the announcement data as JSON response
            header('Content-Type: application/json');
            echo json_encode($announcementData);
        } else {
            // If no data is found for the given ID, return an error message
            http_response_code(404);
            echo json_encode(array('error' => 'Announcement not found.'));
        }
    } else {
        // Handle database query error
        http_response_code(500);
        echo json_encode(array('error' => 'Database query error: ' . $conn->error));
    }

    // Close the prepared statement
    $queryAnnouncement->close();
} else {
    // If ID parameter is not provided or method is not GET, return a bad request error
    http_response_code(400);
    echo json_encode(array('error' => 'Bad request.'));
}

// Close the database connection
CloseCon($conn);
?>